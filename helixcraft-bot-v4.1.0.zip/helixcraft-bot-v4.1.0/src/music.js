const { spawn } = require('child_process');
const {
  joinVoiceChannel,
  createAudioPlayer,
  createAudioResource,
  AudioPlayerStatus,
  VoiceConnectionStatus,
  entersState,
  StreamType,
  NoSubscriberBehavior,
} = require('@discordjs/voice');

const states = new Map();

function stateFor(guildId) {
  if (!states.has(guildId)) {
    const player = createAudioPlayer({
      behaviors: { noSubscriber: NoSubscriberBehavior.Pause },
    });
    const state = {
      guildId,
      player,
      connection: null,
      queue: [],
      current: null,
      volume: 0.5,
      process: null,
      textChannelId: null,
      voiceChannelId: null,
    };

    player.on(AudioPlayerStatus.Idle, () => {
      cleanupProcess(state);
      state.current = null;
      playNext(state).catch(error => console.error('Music next error:', error));
    });

    player.on('error', error => {
      console.error('Music player error:', error);
      cleanupProcess(state);
      state.current = null;
      playNext(state).catch(console.error);
    });

    states.set(guildId, state);
  }
  return states.get(guildId);
}

function cleanupProcess(state) {
  if (state.process && !state.process.killed) {
    state.process.kill('SIGKILL');
  }
  state.process = null;
}

function hasBinary(binary) {
  return new Promise(resolve => {
    const proc = spawn('sh', ['-lc', `command -v ${binary}`]);
    proc.on('close', code => resolve(code === 0));
    proc.on('error', () => resolve(false));
  });
}

async function dependencyStatus() {
  return {
    ytdlp: await hasBinary('yt-dlp'),
    ffmpeg: await hasBinary('ffmpeg'),
  };
}

function queryMetadata(query) {
  return new Promise(resolve => {
    const args = [
      '--no-playlist',
      '--print', '%(title)s',
      '--print', '%(webpage_url)s',
      '--print', '%(duration_string)s',
      query,
    ];
    const proc = spawn('yt-dlp', args);
    let stdout = '';
    let stderr = '';
    proc.stdout.on('data', chunk => { stdout += chunk; });
    proc.stderr.on('data', chunk => { stderr += chunk; });
    proc.on('close', code => {
      if (code !== 0) {
        return resolve({
          title: query,
          url: query,
          duration: 'unknown',
          metadataError: stderr.trim(),
        });
      }
      const lines = stdout.trim().split(/\r?\n/);
      resolve({
        title: lines[0] || query,
        url: lines[1] || query,
        duration: lines[2] || 'unknown',
      });
    });
    proc.on('error', () => resolve({ title: query, url: query, duration: 'unknown' }));
  });
}

async function connect(guild, voiceChannel) {
  const state = stateFor(guild.id);

  if (state.connection && state.voiceChannelId === voiceChannel.id) {
    return state;
  }

  if (state.connection) {
    state.connection.destroy();
  }

  state.connection = joinVoiceChannel({
    channelId: voiceChannel.id,
    guildId: guild.id,
    adapterCreator: guild.voiceAdapterCreator,
    selfDeaf: true,
  });
  state.voiceChannelId = voiceChannel.id;
  state.connection.subscribe(state.player);

  await entersState(state.connection, VoiceConnectionStatus.Ready, 20_000);
  return state;
}

async function enqueue({ guild, voiceChannel, textChannel, query, requestedBy }) {
  const status = await dependencyStatus();
  if (!status.ytdlp || !status.ffmpeg) {
    throw new Error('Music dependencies missing. Install ffmpeg and yt-dlp on the CT.');
  }

  const state = await connect(guild, voiceChannel);
  state.textChannelId = textChannel?.id || state.textChannelId;

  const metadata = await queryMetadata(query);
  const track = {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    query,
    title: metadata.title,
    url: metadata.url,
    duration: metadata.duration,
    requestedBy,
    queuedAt: Date.now(),
  };

  state.queue.push(track);
  if (!state.current && state.player.state.status === AudioPlayerStatus.Idle) {
    await playNext(state);
  }
  return track;
}

async function playNext(state) {
  if (!state.connection) return;
  const track = state.queue.shift();
  if (!track) return;

  state.current = track;

  const proc = spawn('yt-dlp', [
    '--no-playlist',
    '-f', 'bestaudio/best',
    '-o', '-',
    '--quiet',
    '--no-warnings',
    track.url || track.query,
  ], { stdio: ['ignore', 'pipe', 'pipe'] });

  state.process = proc;
  let errorText = '';
  proc.stderr.on('data', chunk => { errorText += chunk.toString(); });
  proc.on('close', code => {
    if (code !== 0 && state.current?.id === track.id) {
      console.error(`yt-dlp exited ${code}: ${errorText.trim()}`);
    }
  });

  const resource = createAudioResource(proc.stdout, {
    inputType: StreamType.Arbitrary,
    inlineVolume: true,
    metadata: track,
  });
  resource.volume?.setVolume(state.volume);
  state.player.play(resource);
}

function pause(guildId) {
  return stateFor(guildId).player.pause();
}

function resume(guildId) {
  return stateFor(guildId).player.unpause();
}

function skip(guildId) {
  const state = stateFor(guildId);
  cleanupProcess(state);
  return state.player.stop(true);
}

function stop(guildId) {
  const state = stateFor(guildId);
  state.queue = [];
  state.current = null;
  cleanupProcess(state);
  state.player.stop(true);
  if (state.connection) state.connection.destroy();
  state.connection = null;
  state.voiceChannelId = null;
}

function setVolume(guildId, percent) {
  const state = stateFor(guildId);
  state.volume = Math.max(0, Math.min(2, Number(percent) / 100));
  const resource = state.player.state.resource;
  resource?.volume?.setVolume(state.volume);
  return Math.round(state.volume * 100);
}

function snapshot(guildId) {
  const state = stateFor(guildId);
  return {
    guildId,
    current: state.current,
    queue: [...state.queue],
    volume: Math.round(state.volume * 100),
    status: state.player.state.status,
    voiceChannelId: state.voiceChannelId,
    textChannelId: state.textChannelId,
  };
}

async function handleCommand(interaction) {
  const command = interaction.commandName;
  const guildId = interaction.guildId;

  if (command === 'play') {
    const voice = interaction.member.voice.channel;
    if (!voice) throw new Error('Join a voice channel first.');
    await interaction.deferReply();
    const track = await enqueue({
      guild: interaction.guild,
      voiceChannel: voice,
      textChannel: interaction.channel,
      query: interaction.options.getString('query'),
      requestedBy: interaction.user.id,
    });
    return interaction.editReply(`🎵 Queued **${track.title}**.`);
  }

  if (command === 'pause') {
    pause(guildId);
    return interaction.reply('⏸️ Music paused.');
  }
  if (command === 'resume') {
    resume(guildId);
    return interaction.reply('▶️ Music resumed.');
  }
  if (command === 'skip') {
    skip(guildId);
    return interaction.reply('⏭️ Skipped.');
  }
  if (command === 'stop') {
    stop(guildId);
    return interaction.reply('⏹️ Music stopped and queue cleared.');
  }
  if (command === 'volume') {
    const value = setVolume(guildId, interaction.options.getInteger('percent'));
    return interaction.reply(`🔊 Volume set to ${value}%.`);
  }
  if (command === 'queue') {
    const state = snapshot(guildId);
    const lines = [];
    if (state.current) lines.push(`**Now:** ${state.current.title}`);
    if (state.queue.length) {
      lines.push('', ...state.queue.slice(0, 15).map((track, index) => `${index + 1}. ${track.title}`));
    }
    return interaction.reply({
      content: lines.join('\n') || 'The queue is empty.',
      ephemeral: true,
    });
  }
  if (command === 'nowplaying') {
    const state = snapshot(guildId);
    return interaction.reply(
      state.current
        ? `🎧 **${state.current.title}**\nDuration: ${state.current.duration}\nRequested by: <@${state.current.requestedBy}>`
        : 'Nothing is playing.'
    );
  }
}

module.exports = {
  enqueue,
  pause,
  resume,
  skip,
  stop,
  setVolume,
  snapshot,
  dependencyStatus,
  handleCommand,
};
