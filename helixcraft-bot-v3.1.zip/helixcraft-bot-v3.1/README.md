# Helixcraft Bot v3

This project combines the Discord bot and dashboard in one Node.js process.

## Included

- Persistent warnings with IDs and points
- Automatic timeout after configurable warning threshold
- Temporary bans, softbans, slowmode
- Ticket panel, claim/unclaim, HTML transcripts, categories, logs and inactivity auto-close
- Join/leave, message edit/delete, role, nickname, voice, channel and emoji logging
- Giveaways with role requirements, bonus-role entries, account/member-age checks, pause/resume, end and reroll
- Welcome placeholders, autorole, sticky messages, temporary voice channels, suggestions
- Server backup snapshots for roles, channels and bot configuration
- Verify and self-role panels
- Discord OAuth2 dashboard for settings, warnings, tickets, giveaways, events and embeds

## Upgrade safely

```bash
cd /root
cp -a helixcraft-bot helixcraft-bot-backup-$(date +%F-%H%M)
unzip helixcraft-bot-v3.zip
cp /root/helixcraft-bot/.env /root/helixcraft-bot-v3/.env
cd /root/helixcraft-bot-v3
npm install
npm run check
npm start
```

After testing, replace the old directory:

```bash
cd /root
mv helixcraft-bot helixcraft-bot-old
mv helixcraft-bot-v3 helixcraft-bot
cd helixcraft-bot
npm start
```

## `.env`

Add these dashboard values to the existing token/client/guild settings:

```env
CLIENT_SECRET=your_discord_application_secret
DASHBOARD_SECRET=use_output_of_openssl_rand_hex_32
DASHBOARD_URL=http://YOUR_CT_IP:3000
DASHBOARD_HOST=0.0.0.0
DASHBOARD_PORT=3000
```

In Discord Developer Portal > OAuth2 > Redirects add exactly:

```text
http://YOUR_CT_IP:3000/callback
```

## Discord permissions and intents

Enable Server Members Intent and Message Content Intent. The bot needs Manage Roles, Manage Channels, Manage Events, Manage Messages, Moderate Members, Ban Members, View Audit Log, Read Message History, Send Messages and Embed Links. Place its role above roles it assigns.

## Notes

- Backups are snapshots and exports; automatic destructive restore is deliberately not included.
- Ticket transcripts are stored in `transcripts/` and uploaded to the configured ticket log channel.
- JSON storage is suitable for one self-hosted server. For large multi-server usage, migrate storage to PostgreSQL.

## v3.1 dashboard improvements

- Clear sidebar navigation and separate configuration sections.
- Existing values are now correctly preselected in every dropdown.
- Each settings area saves independently, preventing unrelated settings from being overwritten.
- Success confirmations appear after every save.
- Better validation and user-friendly error messages.
- Improved embed builder with validation and send confirmation.
- Dashboard URLs now verify that the signed-in user can actually manage the selected server.
- Discord server lists are cached for two minutes to reduce API rate limits.
- Responsive layout for mobile and desktop.

### Updating from v3

Keep your existing `.env` and `data` directory. Replace the application files, then run:

```bash
cd /root/helixcraft-bot
npm install
npm run check
npm start
```
