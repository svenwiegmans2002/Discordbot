const express = require('express');
const session = require('express-session');
const { guildConfig, setGuildConfig, read } = require('./store');
const { embed, BRAND } = require('./utils');

const API = 'https://discord.com/api/v10';

async function api(path, token, method = 'GET', body) {
  const response = await fetch(API + path, {
    method,
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: body ? JSON.stringify(body) : undefined,
  });

  if (!response.ok) {
    const message = await response.text();
    const error = new Error(`Discord API ${response.status}: ${message}`);
    error.status = response.status;
    throw error;
  }

  return response.status === 204 ? null : response.json();
}

function escapeHtml(value = '') {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function selected(current, value) {
  return String(current ?? '') === String(value ?? '') ? ' selected' : '';
}

function checked(value) {
  return value ? ' checked' : '';
}

function optionList(items, current, label, includeNone = true) {
  const none = includeNone ? `<option value=""${selected(current, '')}>Not configured</option>` : '';
  return none + items.map(item => (
    `<option value="${item.id}"${selected(current, item.id)}>${escapeHtml(label(item))}</option>`
  )).join('');
}

function navItem(href, label, active, icon = '') {
  return `<a class="nav-item${active === href ? ' active' : ''}" href="${href}"><span>${icon}</span>${label}</a>`;
}

function layout({ title, body, user, guild, active = '', notice = '', error = '' }) {
  const guildId = guild?.id;
  const sidebar = guildId ? `
    <div class="guild-label">${escapeHtml(guild.name)}</div>
    ${navItem(`/g/${guildId}`, 'Overview', active, '⌂')}
    <div class="nav-heading">Settings</div>
    ${navItem(`/g/${guildId}/settings/general`, 'General & Welcome', active, '⚙')}
    ${navItem(`/g/${guildId}/settings/tickets`, 'Tickets', active, '🎫')}
    ${navItem(`/g/${guildId}/settings/moderation`, 'Moderation', active, '🛡')}
    ${navItem(`/g/${guildId}/settings/server`, 'Server features', active, '🧩')}
    <div class="nav-heading">Management</div>
    ${navItem(`/g/${guildId}/warnings`, 'Warnings', active, '⚠')}
    ${navItem(`/g/${guildId}/tickets`, 'Ticket records', active, '▣')}
    ${navItem(`/g/${guildId}/giveaways`, 'Giveaways', active, '🎉')}
    ${navItem(`/g/${guildId}/events`, 'Events', active, '📅')}
    ${navItem(`/g/${guildId}/embed`, 'Embed builder', active, '✎')}
  ` : navItem('/servers', 'Servers', active, '▦');

  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>${escapeHtml(title)} · Helixcraft</title>
  <style>
    :root{--bg:#080d18;--panel:#11192a;--panel2:#162138;--border:#273654;--text:#eef3ff;--muted:#9ba9c3;--brand:#5865f2;--green:#3ba55d;--red:#ed4245;--orange:#f0a202}
    *{box-sizing:border-box}body{margin:0;background:linear-gradient(135deg,#0b1222,#070b13 65%);color:var(--text);font-family:Inter,ui-sans-serif,system-ui,-apple-system,Segoe UI,sans-serif;min-height:100vh}
    a{color:inherit;text-decoration:none}.shell{display:grid;grid-template-columns:260px minmax(0,1fr);min-height:100vh}.sidebar{background:rgba(12,18,31,.97);border-right:1px solid var(--border);padding:22px 16px;position:sticky;top:0;height:100vh;overflow-y:auto}.brand{font-size:19px;font-weight:900;padding:0 10px 20px}.brand small{display:block;color:var(--muted);font-size:11px;margin-top:4px;font-weight:600}.guild-label{margin:6px 10px 14px;color:#fff;font-weight:800;overflow:hidden;text-overflow:ellipsis}.nav-heading{color:#71809b;text-transform:uppercase;letter-spacing:.09em;font-size:11px;font-weight:800;margin:20px 12px 7px}.nav-item{display:flex;gap:10px;align-items:center;padding:10px 12px;border-radius:10px;color:#c8d2e8;margin:3px 0;font-size:14px;font-weight:650}.nav-item:hover{background:#18233a}.nav-item.active{background:rgba(88,101,242,.2);color:#fff;border:1px solid rgba(88,101,242,.35)}
    .content-wrap{min-width:0}.topbar{height:64px;border-bottom:1px solid var(--border);background:rgba(8,13,24,.82);backdrop-filter:blur(14px);display:flex;align-items:center;justify-content:flex-end;padding:0 28px;position:sticky;top:0;z-index:5}.user{display:flex;gap:12px;align-items:center;color:var(--muted);font-size:14px}.logout{color:#dce4ff;font-weight:700}.main{max-width:1180px;margin:0 auto;padding:32px}.page-head{display:flex;align-items:flex-end;justify-content:space-between;gap:20px;margin-bottom:24px}.page-head h1{margin:0;font-size:30px}.page-head p{margin:7px 0 0;color:var(--muted)}
    .grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:16px}.stat,.card,.form-card{background:rgba(17,25,42,.95);border:1px solid var(--border);border-radius:16px;box-shadow:0 16px 40px rgba(0,0,0,.18)}.stat{padding:20px}.stat strong{font-size:32px;display:block}.stat span{color:var(--muted);font-size:13px}.card{padding:20px}.card h2,.form-card h2{margin:0 0 7px}.card p{color:var(--muted);line-height:1.6}.form-card{padding:22px;margin-bottom:18px}.section-title{display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid var(--border);padding-bottom:14px;margin-bottom:18px}.section-title p{margin:4px 0 0;color:var(--muted);font-size:13px}
    .fields{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}.field.full{grid-column:1/-1}.field label{display:block;font-weight:750;font-size:13px;margin-bottom:7px}.hint{display:block;color:var(--muted);font-size:12px;margin-top:6px;line-height:1.45}input,select,textarea{width:100%;border:1px solid #334565;background:#090f1c;color:#fff;padding:11px 12px;border-radius:10px;font:inherit;outline:none}input:focus,select:focus,textarea:focus{border-color:var(--brand);box-shadow:0 0 0 3px rgba(88,101,242,.14)}textarea{min-height:120px;resize:vertical}.actions{display:flex;align-items:center;justify-content:flex-end;gap:12px;border-top:1px solid var(--border);padding-top:18px;margin-top:20px}.button,button{border:0;border-radius:10px;background:var(--brand);color:#fff;padding:11px 17px;font-weight:800;cursor:pointer;font:inherit}.button.secondary{background:#1a263e;border:1px solid var(--border)}button:hover,.button:hover{filter:brightness(1.08)}
    .notice,.error{border-radius:12px;padding:13px 15px;margin-bottom:18px;font-weight:650}.notice{background:rgba(59,165,93,.14);border:1px solid rgba(59,165,93,.45);color:#baf2ca}.error{background:rgba(237,66,69,.13);border:1px solid rgba(237,66,69,.45);color:#ffc2c3}.empty{color:var(--muted);padding:28px;text-align:center}.table-wrap{overflow:auto;border:1px solid var(--border);border-radius:14px;background:var(--panel)}table{width:100%;border-collapse:collapse;font-size:13px}th,td{padding:12px 13px;text-align:left;border-bottom:1px solid var(--border);white-space:nowrap}th{background:#121c30;color:#aebbd1;position:sticky;top:0}td{max-width:420px;overflow:hidden;text-overflow:ellipsis}.badge{display:inline-flex;border-radius:999px;padding:4px 9px;background:#1b2842;color:#cad7f1;font-size:11px;font-weight:800}.quick-links{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:14px;margin-top:20px}.quick-link{padding:18px;background:var(--panel);border:1px solid var(--border);border-radius:14px}.quick-link b{display:block;margin-bottom:6px}.quick-link span{color:var(--muted);font-size:13px}.login{max-width:600px;margin:10vh auto;padding:42px;text-align:center}.login h1{font-size:40px;margin:0}.login p{color:var(--muted);font-size:17px;line-height:1.6}.checkbox-row{display:flex;align-items:flex-start;gap:10px;padding:12px;border:1px solid var(--border);border-radius:10px;background:#0c1322}.checkbox-row input{width:auto;margin-top:2px}.checkbox-row label{margin:0}.danger-note{color:#f6c45f;font-size:12px}
    @media(max-width:800px){.shell{grid-template-columns:1fr}.sidebar{position:static;height:auto;border-right:0;border-bottom:1px solid var(--border)}.content-wrap{min-width:0}.main{padding:22px 15px}.fields{grid-template-columns:1fr}.topbar{position:static}.page-head{align-items:flex-start;flex-direction:column}}
  </style>
</head>
<body>
<div class="shell">
  <aside class="sidebar">
    <div class="brand">Helixcraft Dashboard<small>Bot administration</small></div>
    ${sidebar}
  </aside>
  <section class="content-wrap">
    <header class="topbar"><div class="user">${user ? `${escapeHtml(user.username)} <a class="logout" href="/logout">Log out</a>` : '<a class="logout" href="/login">Log in</a>'}</div></header>
    <main class="main">
      ${notice ? `<div class="notice">✓ ${escapeHtml(notice)}</div>` : ''}
      ${error ? `<div class="error">${escapeHtml(error)}</div>` : ''}
      ${body}
    </main>
  </section>
</div>
</body>
</html>`;
}

function pageHead(title, description, action = '') {
  return `<div class="page-head"><div><h1>${escapeHtml(title)}</h1><p>${escapeHtml(description)}</p></div>${action}</div>`;
}

function protect(req, res, next) {
  if (!req.session.token) return res.redirect('/login');
  next();
}

async function getManageableGuilds(req, client, force = false) {
  const now = Date.now();
  if (!force && req.session.guildCache && now - req.session.guildCacheTime < 120000) {
    return req.session.guildCache;
  }

  const userGuilds = await api('/users/@me/guilds', req.session.token);
  const botGuilds = new Set(client.guilds.cache.keys());
  const manageable = userGuilds.filter(guild => {
    const permissions = BigInt(guild.permissions || '0');
    return botGuilds.has(guild.id) && ((permissions & 8n) !== 0n || (permissions & 32n) !== 0n);
  });

  req.session.guildCache = manageable;
  req.session.guildCacheTime = now;
  return manageable;
}

function parseNullableString(value) {
  const trimmed = String(value ?? '').trim();
  return trimmed === '' ? null : trimmed;
}

function parseInteger(value, fallback, min = 0, max = Number.MAX_SAFE_INTEGER) {
  const parsed = Number.parseInt(value, 10);
  if (!Number.isFinite(parsed)) return fallback;
  return Math.min(max, Math.max(min, parsed));
}

function table(rows, preferredColumns = null) {
  if (!rows.length) return '<div class="card empty">No records found.</div>';
  const keys = preferredColumns || Object.keys(rows[0]);
  return `<div class="table-wrap"><table><thead><tr>${keys.map(key => `<th>${escapeHtml(key)}</th>`).join('')}</tr></thead><tbody>${rows.map(row => `<tr>${keys.map(key => {
    const value = typeof row[key] === 'object' && row[key] !== null ? JSON.stringify(row[key]) : row[key] ?? '';
    return `<td title="${escapeHtml(value)}">${escapeHtml(value)}</td>`;
  }).join('')}</tr>`).join('')}</tbody></table></div>`;
}

async function startDashboard(client) {
  const app = express();
  app.disable('x-powered-by');
  app.use(express.urlencoded({ extended: true, limit: '200kb' }));
  app.use(express.json({ limit: '200kb' }));
  app.use(session({
    secret: process.env.DASHBOARD_SECRET || 'change-me-immediately',
    resave: false,
    saveUninitialized: false,
    cookie: {
      maxAge: 86400000,
      httpOnly: true,
      sameSite: 'lax',
      secure: String(process.env.DASHBOARD_URL || '').startsWith('https://'),
    },
  }));

  app.get('/', (req, res) => {
    const body = `<div class="card login"><h1>Helixcraft</h1><p>Manage your Discord server settings, tickets, moderation, giveaways and events from one clear dashboard.</p><a class="button" href="/login">Log in with Discord</a></div>`;
    res.send(layout({ title: 'Dashboard', body, user: req.session.user, active: '/' }));
  });

  app.get('/login', (req, res) => {
    const dashboardUrl = String(process.env.DASHBOARD_URL || '').replace(/\/$/, '');
    if (!dashboardUrl) return res.status(500).send('DASHBOARD_URL is missing in .env');
    const redirectUri = encodeURIComponent(`${dashboardUrl}/callback`);
    res.redirect(`https://discord.com/oauth2/authorize?client_id=${process.env.CLIENT_ID}&response_type=code&redirect_uri=${redirectUri}&scope=identify%20guilds`);
  });

  app.get('/callback', async (req, res) => {
    try {
      const dashboardUrl = String(process.env.DASHBOARD_URL || '').replace(/\/$/, '');
      const body = new URLSearchParams({
        client_id: process.env.CLIENT_ID,
        client_secret: process.env.CLIENT_SECRET,
        grant_type: 'authorization_code',
        code: req.query.code,
        redirect_uri: `${dashboardUrl}/callback`,
      });

      const response = await fetch(`${API}/oauth2/token`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body,
      });

      if (!response.ok) throw new Error(await response.text());
      const token = await response.json();
      req.session.token = token.access_token;
      req.session.user = await api('/users/@me', token.access_token);
      delete req.session.guildCache;
      res.redirect('/servers');
    } catch (error) {
      res.status(500).send(layout({ title: 'Login failed', body: `<div class="error">${escapeHtml(error.message)}</div>` }));
    }
  });

  app.get('/logout', (req, res) => req.session.destroy(() => res.redirect('/')));

  app.get('/servers', protect, async (req, res) => {
    try {
      const guilds = await getManageableGuilds(req, client);
      const cards = guilds.length
        ? guilds.map(guild => `<a class="card" href="/g/${guild.id}"><h2>${escapeHtml(guild.name)}</h2><p>Open settings and management tools.</p><span class="badge">Manage server</span></a>`).join('')
        : '<div class="card empty">No servers found where you have Manage Server or Administrator and the bot is installed.</div>';
      const body = `${pageHead('Your servers', 'Choose a server to configure Helixcraft.')}<div class="grid">${cards}</div>`;
      res.send(layout({ title: 'Servers', body, user: req.session.user, active: '/servers' }));
    } catch (error) {
      const status = error.status === 429 ? 429 : 500;
      const message = error.status === 429 ? 'Discord rate limit reached. Wait a moment and reload the page.' : error.message;
      res.status(status).send(layout({ title: 'Error', body: '', user: req.session.user, active: '/servers', error: message }));
    }
  });

  app.use('/g/:gid', protect, async (req, res, next) => {
    try {
      const manageable = await getManageableGuilds(req, client);
      if (!manageable.some(guild => guild.id === req.params.gid)) {
        return res.status(403).send(layout({ title: 'No access', body: '', user: req.session.user, error: 'You do not have permission to manage this server.' }));
      }
      const guild = client.guilds.cache.get(req.params.gid);
      if (!guild) return res.status(404).send('Guild unavailable');
      req.guild = guild;
      next();
    } catch (error) {
      res.status(500).send(layout({ title: 'Error', body: '', user: req.session.user, error: error.message }));
    }
  });

  app.get('/g/:gid', (req, res) => {
    const guild = req.guild;
    const warnings = read('warnings')[guild.id] || {};
    const tickets = Object.values(read('tickets')).filter(ticket => ticket.guildId === guild.id);
    const giveaways = Object.values(read('giveaways')).filter(giveaway => giveaway.guildId === guild.id);
    const openTickets = tickets.filter(ticket => ticket.status !== 'closed').length;
    const activeGiveaways = giveaways.filter(giveaway => !giveaway.ended).length;
    const warningCount = Object.values(warnings).flat().length;

    const body = `${pageHead(guild.name, 'Overview of your server and bot data.')}
      <div class="grid">
        <div class="stat"><strong>${guild.memberCount}</strong><span>Members</span></div>
        <div class="stat"><strong>${warningCount}</strong><span>Warnings</span></div>
        <div class="stat"><strong>${openTickets}</strong><span>Open tickets</span></div>
        <div class="stat"><strong>${activeGiveaways}</strong><span>Active giveaways</span></div>
      </div>
      <div class="quick-links">
        <a class="quick-link" href="/g/${guild.id}/settings/general"><b>General settings</b><span>Welcome, autorole and logging.</span></a>
        <a class="quick-link" href="/g/${guild.id}/settings/tickets"><b>Ticket settings</b><span>Category, support role and auto-close.</span></a>
        <a class="quick-link" href="/g/${guild.id}/settings/moderation"><b>Moderation settings</b><span>Warning thresholds and timeout rules.</span></a>
        <a class="quick-link" href="/g/${guild.id}/embed"><b>Embed builder</b><span>Send a styled message to any text channel.</span></a>
      </div>`;

    res.send(layout({ title: guild.name, body, user: req.session.user, guild, active: `/g/${guild.id}` }));
  });

  app.get('/g/:gid/config', (req, res) => res.redirect(`/g/${req.guild.id}/settings/general`));

  app.get('/g/:gid/settings/general', (req, res) => {
    const guild = req.guild;
    const config = guildConfig(guild.id);
    const textChannels = [...guild.channels.cache.values()].filter(channel => channel.isTextBased() && channel.type !== 4);
    const roles = [...guild.roles.cache.values()].filter(role => role.id !== guild.id).sort((a, b) => b.position - a.position);

    const body = `${pageHead('General & welcome', 'Configure welcome messages, autoroles and logging.')}
      <form class="form-card" method="post" action="/g/${guild.id}/settings/general">
        <div class="section-title"><div><h2>Welcome system</h2><p>Choose where and how new members are greeted.</p></div></div>
        <div class="fields">
          <div class="field"><label>Welcome channel</label><select name="welcomeChannelId">${optionList(textChannels, config.welcomeChannelId, channel => `#${channel.name}`)}</select></div>
          <div class="field"><label>Automatic role</label><select name="autoroleId">${optionList(roles, config.autoroleId, role => role.name)}</select><span class="hint">The bot role must be above the selected role.</span></div>
          <div class="field full"><label>Welcome message</label><textarea name="welcomeMessage">${escapeHtml(config.welcomeMessage || '')}</textarea><span class="hint">Available placeholders: {member}, {server}, {count}</span></div>
        </div>
        <div class="section-title"><div><h2>Logging</h2><p>Set the channel used for bot and server logs.</p></div></div>
        <div class="fields"><div class="field"><label>Log channel</label><select name="logChannelId">${optionList(textChannels, config.logChannelId, channel => `#${channel.name}`)}</select></div></div>
        <div class="actions"><a class="button secondary" href="/g/${guild.id}">Cancel</a><button type="submit">Save general settings</button></div>
      </form>`;

    res.send(layout({ title: 'General settings', body, user: req.session.user, guild, active: `/g/${guild.id}/settings/general`, notice: req.query.saved === '1' ? 'General settings saved successfully.' : '' }));
  });

  app.post('/g/:gid/settings/general', (req, res) => {
    const current = guildConfig(req.guild.id);
    setGuildConfig(req.guild.id, {
      welcomeChannelId: parseNullableString(req.body.welcomeChannelId),
      welcomeMessage: parseNullableString(req.body.welcomeMessage) || current.welcomeMessage,
      autoroleId: parseNullableString(req.body.autoroleId),
      logChannelId: parseNullableString(req.body.logChannelId),
    });
    res.redirect(`/g/${req.guild.id}/settings/general?saved=1`);
  });

  app.get('/g/:gid/settings/tickets', (req, res) => {
    const guild = req.guild;
    const config = guildConfig(guild.id);
    const textChannels = [...guild.channels.cache.values()].filter(channel => channel.isTextBased() && channel.type !== 4);
    const categories = [...guild.channels.cache.values()].filter(channel => channel.type === 4);
    const roles = [...guild.roles.cache.values()].filter(role => role.id !== guild.id).sort((a, b) => b.position - a.position);

    const body = `${pageHead('Ticket settings', 'Configure where tickets are created, who can access them and when inactive tickets close.')}
      <form class="form-card" method="post" action="/g/${guild.id}/settings/tickets">
        <div class="section-title"><div><h2>Ticket routing</h2><p>Keep support channels and transcripts organized.</p></div></div>
        <div class="fields">
          <div class="field"><label>Ticket category</label><select name="ticketCategoryId">${optionList(categories, config.ticketCategoryId, category => category.name)}</select></div>
          <div class="field"><label>Support role</label><select name="ticketSupportRoleId">${optionList(roles, config.ticketSupportRoleId, role => role.name)}</select></div>
          <div class="field"><label>Ticket log channel</label><select name="ticketLogChannelId">${optionList(textChannels, config.ticketLogChannelId, channel => `#${channel.name}`)}</select></div>
          <div class="field"><label>Auto-close after inactivity</label><input type="number" min="0" max="720" name="ticketAutoCloseHours" value="${escapeHtml(config.ticketAutoCloseHours ?? 72)}"><span class="hint">Hours. Use 0 to disable automatic closing.</span></div>
        </div>
        <div class="actions"><a class="button secondary" href="/g/${guild.id}">Cancel</a><button type="submit">Save ticket settings</button></div>
      </form>`;

    res.send(layout({ title: 'Ticket settings', body, user: req.session.user, guild, active: `/g/${guild.id}/settings/tickets`, notice: req.query.saved === '1' ? 'Ticket settings saved successfully.' : '' }));
  });

  app.post('/g/:gid/settings/tickets', (req, res) => {
    const current = guildConfig(req.guild.id);
    setGuildConfig(req.guild.id, {
      ticketCategoryId: parseNullableString(req.body.ticketCategoryId),
      ticketSupportRoleId: parseNullableString(req.body.ticketSupportRoleId),
      ticketLogChannelId: parseNullableString(req.body.ticketLogChannelId),
      ticketAutoCloseHours: parseInteger(req.body.ticketAutoCloseHours, current.ticketAutoCloseHours ?? 72, 0, 720),
    });
    res.redirect(`/g/${req.guild.id}/settings/tickets?saved=1`);
  });

  app.get('/g/:gid/settings/moderation', (req, res) => {
    const guild = req.guild;
    const config = guildConfig(guild.id);
    const body = `${pageHead('Moderation settings', 'Configure automatic actions after repeated warnings.')}
      <form class="form-card" method="post" action="/g/${guild.id}/settings/moderation">
        <div class="section-title"><div><h2>Warning escalation</h2><p>The bot can automatically timeout users after a warning threshold.</p></div></div>
        <div class="fields">
          <div class="field"><label>Warnings before timeout</label><input type="number" min="0" max="100" name="warnTimeoutThreshold" value="${escapeHtml(config.warnTimeoutThreshold ?? 3)}"><span class="hint">Use 0 to disable automatic escalation.</span></div>
          <div class="field"><label>Timeout duration in minutes</label><input type="number" min="1" max="40320" name="warnTimeoutMinutes" value="${escapeHtml(config.warnTimeoutMinutes ?? 60)}"></div>
        </div>
        <div class="actions"><a class="button secondary" href="/g/${guild.id}">Cancel</a><button type="submit">Save moderation settings</button></div>
      </form>`;
    res.send(layout({ title: 'Moderation settings', body, user: req.session.user, guild, active: `/g/${guild.id}/settings/moderation`, notice: req.query.saved === '1' ? 'Moderation settings saved successfully.' : '' }));
  });

  app.post('/g/:gid/settings/moderation', (req, res) => {
    const current = guildConfig(req.guild.id);
    setGuildConfig(req.guild.id, {
      warnTimeoutThreshold: parseInteger(req.body.warnTimeoutThreshold, current.warnTimeoutThreshold ?? 3, 0, 100),
      warnTimeoutMinutes: parseInteger(req.body.warnTimeoutMinutes, current.warnTimeoutMinutes ?? 60, 1, 40320),
    });
    res.redirect(`/g/${req.guild.id}/settings/moderation?saved=1`);
  });

  app.get('/g/:gid/settings/server', (req, res) => {
    const guild = req.guild;
    const config = guildConfig(guild.id);
    const textChannels = [...guild.channels.cache.values()].filter(channel => channel.isTextBased() && channel.type !== 4);
    const voiceChannels = [...guild.channels.cache.values()].filter(channel => channel.type === 2);
    const categories = [...guild.channels.cache.values()].filter(channel => channel.type === 4);

    const body = `${pageHead('Server features', 'Configure suggestions and temporary voice channels.')}
      <form class="form-card" method="post" action="/g/${guild.id}/settings/server">
        <div class="section-title"><div><h2>Suggestions</h2><p>Choose the destination for member suggestions.</p></div></div>
        <div class="fields"><div class="field"><label>Suggestion channel</label><select name="suggestionChannelId">${optionList(textChannels, config.suggestionChannelId, channel => `#${channel.name}`)}</select></div></div>
        <div class="section-title"><div><h2>Temporary voice channels</h2><p>Create private voice channels when members join a lobby.</p></div></div>
        <div class="fields">
          <div class="field"><label>Voice lobby</label><select name="tempVoiceLobbyId">${optionList(voiceChannels, config.tempVoiceLobbyId, channel => channel.name)}</select></div>
          <div class="field"><label>Voice category</label><select name="tempVoiceCategoryId">${optionList(categories, config.tempVoiceCategoryId, category => category.name)}</select></div>
        </div>
        <div class="actions"><a class="button secondary" href="/g/${guild.id}">Cancel</a><button type="submit">Save server features</button></div>
      </form>`;
    res.send(layout({ title: 'Server features', body, user: req.session.user, guild, active: `/g/${guild.id}/settings/server`, notice: req.query.saved === '1' ? 'Server features saved successfully.' : '' }));
  });

  app.post('/g/:gid/settings/server', (req, res) => {
    setGuildConfig(req.guild.id, {
      suggestionChannelId: parseNullableString(req.body.suggestionChannelId),
      tempVoiceLobbyId: parseNullableString(req.body.tempVoiceLobbyId),
      tempVoiceCategoryId: parseNullableString(req.body.tempVoiceCategoryId),
    });
    res.redirect(`/g/${req.guild.id}/settings/server?saved=1`);
  });

  app.get('/g/:gid/warnings', (req, res) => {
    const all = read('warnings')[req.guild.id] || {};
    const rows = Object.entries(all).flatMap(([userId, entries]) => entries.map(item => ({ userId, ...item })));
    const body = `${pageHead('Warnings', 'Persistent warning history for this server.')}${table(rows)}`;
    res.send(layout({ title: 'Warnings', body, user: req.session.user, guild: req.guild, active: `/g/${req.guild.id}/warnings` }));
  });

  app.get('/g/:gid/tickets', (req, res) => {
    const rows = Object.entries(read('tickets')).filter(([, ticket]) => ticket.guildId === req.guild.id).map(([channelId, ticket]) => ({ channelId, ...ticket }));
    const body = `${pageHead('Ticket records', 'Review current and historical ticket metadata.')}${table(rows)}`;
    res.send(layout({ title: 'Tickets', body, user: req.session.user, guild: req.guild, active: `/g/${req.guild.id}/tickets` }));
  });

  app.get('/g/:gid/giveaways', (req, res) => {
    const rows = Object.values(read('giveaways')).filter(giveaway => giveaway.guildId === req.guild.id);
    const body = `${pageHead('Giveaways', 'Review active and completed giveaways.')}${table(rows)}`;
    res.send(layout({ title: 'Giveaways', body, user: req.session.user, guild: req.guild, active: `/g/${req.guild.id}/giveaways` }));
  });

  app.get('/g/:gid/events', async (req, res) => {
    try {
      const events = await req.guild.scheduledEvents.fetch();
      const rows = events.map(event => ({
        id: event.id,
        name: event.name,
        status: event.status,
        start: event.scheduledStartTimestamp ? new Date(event.scheduledStartTimestamp).toLocaleString() : '',
      }));
      const body = `${pageHead('Events', 'Scheduled Discord server events.')}${table(rows)}`;
      res.send(layout({ title: 'Events', body, user: req.session.user, guild: req.guild, active: `/g/${req.guild.id}/events` }));
    } catch (error) {
      res.status(500).send(layout({ title: 'Events', body: '', user: req.session.user, guild: req.guild, active: `/g/${req.guild.id}/events`, error: error.message }));
    }
  });

  app.get('/g/:gid/embed', (req, res) => {
    const guild = req.guild;
    const channels = [...guild.channels.cache.values()].filter(channel => channel.isTextBased() && channel.type !== 4);
    const body = `${pageHead('Embed builder', 'Send a branded embed to a Discord channel.')}
      <form class="form-card" method="post" action="/g/${guild.id}/embed">
        <div class="fields">
          <div class="field"><label>Destination channel</label><select name="channelId" required>${optionList(channels, null, channel => `#${channel.name}`, false)}</select></div>
          <div class="field"><label>Color</label><input name="color" value="5865F2" pattern="^#?[0-9A-Fa-f]{6}$"><span class="hint">Six-digit hexadecimal value.</span></div>
          <div class="field full"><label>Title</label><input name="title" maxlength="256" required></div>
          <div class="field full"><label>Description</label><textarea name="description" maxlength="4096" required></textarea></div>
        </div>
        <div class="actions"><button type="submit">Send embed</button></div>
      </form>`;
    res.send(layout({ title: 'Embed builder', body, user: req.session.user, guild, active: `/g/${guild.id}/embed`, notice: req.query.sent === '1' ? 'Embed sent successfully.' : '', error: req.query.error ? decodeURIComponent(req.query.error) : '' }));
  });

  app.post('/g/:gid/embed', async (req, res) => {
    try {
      const channel = req.guild.channels.cache.get(req.body.channelId);
      if (!channel || !channel.isTextBased()) throw new Error('Selected channel is unavailable or not a text channel.');
      const normalized = String(req.body.color || '').replace('#', '');
      const color = /^[0-9a-f]{6}$/i.test(normalized) ? Number.parseInt(normalized, 16) : BRAND.color;
      const title = String(req.body.title || '').trim().slice(0, 256);
      const description = String(req.body.description || '').trim().slice(0, 4096);
      if (!title || !description) throw new Error('Title and description are required.');
      await channel.send({ embeds: [embed(title, description, color)] });
      res.redirect(`/g/${req.guild.id}/embed?sent=1`);
    } catch (error) {
      res.redirect(`/g/${req.guild.id}/embed?error=${encodeURIComponent(error.message)}`);
    }
  });

  app.use((error, req, res, next) => {
    console.error('Dashboard error:', error);
    if (res.headersSent) return next(error);
    res.status(500).send(layout({ title: 'Dashboard error', body: '', user: req.session?.user, guild: req.guild, error: error.message || 'Unknown error' }));
  });

  const port = Number(process.env.DASHBOARD_PORT || 3000);
  const host = process.env.DASHBOARD_HOST || '0.0.0.0';
  app.listen(port, host, () => console.log(`Dashboard listening on http://${host}:${port}`));
}

module.exports = { startDashboard };
