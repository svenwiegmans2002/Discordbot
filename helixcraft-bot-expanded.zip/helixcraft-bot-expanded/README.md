# Helixcraft Bot Expanded

Adds verify panels, bot messages, self-role panels, Discord scheduled events, giveaways and persistent warnings.

## Replace current bot

```bash
cd /root
cp -a helixcraft-bot helixcraft-bot-backup
```

Copy `index.js`, `package.json` and `data/` into `/root/helixcraft-bot`, while keeping your existing `.env`.

```bash
cd /root/helixcraft-bot
rm -rf node_modules package-lock.json
npm install
npm start
```

The bot role must be above roles it assigns. Required permissions include Manage Roles, Manage Events, Manage Messages, Manage Channels and Embed Links.
