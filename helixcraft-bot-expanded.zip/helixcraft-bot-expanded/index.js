require("dotenv").config();

const fs = require("fs");
const path = require("path");
const crypto = require("crypto");
const {
  Client,
  GatewayIntentBits,
  Partials,
  REST,
  Routes,
  SlashCommandBuilder,
  PermissionFlagsBits,
  EmbedBuilder,
  ChannelType,
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  GuildScheduledEventEntityType,
  GuildScheduledEventPrivacyLevel,
} = require("discord.js");

const TOKEN = process.env.BOT_TOKEN;
const CLIENT_ID = process.env.CLIENT_ID;
const GUILD_ID = process.env.GUILD_ID;
if (!TOKEN || !CLIENT_ID || !GUILD_ID) {
  console.error("Missing BOT_TOKEN, CLIENT_ID or GUILD_ID in .env");
  process.exit(1);
}

const DATA_DIR = path.join(__dirname, "data");
const WARNINGS_FILE = path.join(DATA_DIR, "warnings.json");
const GIVEAWAYS_FILE = path.join(DATA_DIR, "giveaways.json");
fs.mkdirSync(DATA_DIR, { recursive: true });

function loadJson(file, fallback = {}) {
  try {
    if (!fs.existsSync(file)) fs.writeFileSync(file, JSON.stringify(fallback, null, 2));
    return JSON.parse(fs.readFileSync(file, "utf8"));
  } catch (error) {
    console.error(`Failed to read ${file}:`, error);
    return fallback;
  }
}
function saveJson(file, data) {
  const tmp = `${file}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(data, null, 2));
  fs.renameSync(tmp, file);
}

let warnings = loadJson(WARNINGS_FILE, {});
let giveaways = loadJson(GIVEAWAYS_FILE, {});

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildModeration,
    GatewayIntentBits.GuildMessageReactions,
  ],
  partials: [Partials.Channel, Partials.Message, Partials.Reaction],
});

const BRAND = { color: 0x5865f2, success: 0x57f287, warning: 0xfee75c, error: 0xed4245 };
function makeEmbed(title, description, color = BRAND.color) {
  return new EmbedBuilder().setTitle(title).setDescription(description).setColor(color)
    .setFooter({ text: "Helixcraft Management System" }).setTimestamp();
}
function parseDuration(value) {
  const match = /^(\d+)(s|m|h|d)$/i.exec(value.trim());
  if (!match) throw new Error("Use 30s, 10m, 2h or 3d.");
  const unit = { s: 1000, m: 60000, h: 3600000, d: 86400000 }[match[2].toLowerCase()];
  return Number(match[1]) * unit;
}
function parseDate(value) {
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) throw new Error("Invalid date. Example: 2026-08-10 20:00");
  return date;
}
function giveawayRow(id, disabled = false) {
  return new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`giveaway_join:${id}`).setLabel("Enter giveaway")
      .setEmoji("🎉").setStyle(ButtonStyle.Success).setDisabled(disabled)
  );
}
async function getLogChannel(guild) {
  return guild.channels.cache.find(c => c.name === "📊・logs" && c.isTextBased()) || null;
}
async function logAction(guild, title, description, color = BRAND.color) {
  const channel = await getLogChannel(guild);
  if (channel) await channel.send({ embeds: [makeEmbed(title, description, color)] }).catch(() => {});
}

const commands = [
  new SlashCommandBuilder().setName("ping").setDescription("Check bot latency."),
  new SlashCommandBuilder().setName("help").setDescription("Show bot commands."),
  new SlashCommandBuilder().setName("say").setDescription("Send a message as the bot.")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addStringOption(o => o.setName("message").setDescription("Message").setRequired(true))
    .addChannelOption(o => o.setName("channel").setDescription("Target channel")),
  new SlashCommandBuilder().setName("embed").setDescription("Send an embed as the bot.")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addStringOption(o => o.setName("title").setDescription("Title").setRequired(true))
    .addStringOption(o => o.setName("description").setDescription("Description").setRequired(true))
    .addStringOption(o => o.setName("color").setDescription("Hex color, e.g. 5865F2"))
    .addChannelOption(o => o.setName("channel").setDescription("Target channel")),
  new SlashCommandBuilder().setName("verify-panel").setDescription("Create verification panel.")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
    .addRoleOption(o => o.setName("role").setDescription("Verified role").setRequired(true))
    .addStringOption(o => o.setName("title").setDescription("Panel title"))
    .addStringOption(o => o.setName("description").setDescription("Panel description")),
  new SlashCommandBuilder().setName("role-panel").setDescription("Create a self-role panel.")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles)
    .addStringOption(o => o.setName("title").setDescription("Panel title").setRequired(true))
    .addStringOption(o => o.setName("description").setDescription("Panel description").setRequired(true))
    .addRoleOption(o => o.setName("role1").setDescription("Role 1").setRequired(true))
    .addRoleOption(o => o.setName("role2").setDescription("Role 2"))
    .addRoleOption(o => o.setName("role3").setDescription("Role 3"))
    .addRoleOption(o => o.setName("role4").setDescription("Role 4"))
    .addRoleOption(o => o.setName("role5").setDescription("Role 5")),
  new SlashCommandBuilder().setName("event").setDescription("Manage scheduled events.")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageEvents)
    .addSubcommand(s => s.setName("create").setDescription("Create event")
      .addStringOption(o => o.setName("name").setDescription("Event name").setRequired(true))
      .addStringOption(o => o.setName("start").setDescription("2026-08-10 20:00").setRequired(true))
      .addStringOption(o => o.setName("end").setDescription("2026-08-10 22:00").setRequired(true))
      .addStringOption(o => o.setName("location").setDescription("Location").setRequired(true))
      .addStringOption(o => o.setName("description").setDescription("Description")))
    .addSubcommand(s => s.setName("list").setDescription("List events"))
    .addSubcommand(s => s.setName("delete").setDescription("Delete event")
      .addStringOption(o => o.setName("event_id").setDescription("Event ID").setRequired(true))),
  new SlashCommandBuilder().setName("giveaway").setDescription("Manage giveaways.")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
    .addSubcommand(s => s.setName("start").setDescription("Start giveaway")
      .addStringOption(o => o.setName("prize").setDescription("Prize").setRequired(true))
      .addStringOption(o => o.setName("duration").setDescription("30s, 10m, 2h, 3d").setRequired(true))
      .addIntegerOption(o => o.setName("winners").setDescription("Winner count").setMinValue(1).setMaxValue(20).setRequired(true))
      .addChannelOption(o => o.setName("channel").setDescription("Target channel")))
    .addSubcommand(s => s.setName("list").setDescription("List active giveaways"))
    .addSubcommand(s => s.setName("end").setDescription("End giveaway")
      .addStringOption(o => o.setName("giveaway_id").setDescription("Giveaway ID").setRequired(true)))
    .addSubcommand(s => s.setName("reroll").setDescription("Reroll giveaway")
      .addStringOption(o => o.setName("giveaway_id").setDescription("Giveaway ID").setRequired(true))),
  new SlashCommandBuilder().setName("warn").setDescription("Warn a user.")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addUserOption(o => o.setName("user").setDescription("User").setRequired(true))
    .addStringOption(o => o.setName("reason").setDescription("Reason").setRequired(true)),
  new SlashCommandBuilder().setName("warnings").setDescription("View warnings.")
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addUserOption(o => o.setName("user").setDescription("User").setRequired(true)),
  new SlashCommandBuilder().setName("ticket-panel").setDescription("Create ticket panel.")
    .setDefaultMemberPermissions(PermissionFlagsBits.Administrator),
].map(c => c.toJSON());

async function deployCommands() {
  const rest = new REST({ version: "10" }).setToken(TOKEN);
  await rest.put(Routes.applicationGuildCommands(CLIENT_ID, GUILD_ID), { body: commands });
  console.log("Slash commands deployed.");
}

function pickWinners(giveaway) {
  const pool = [...new Set(giveaway.entries || [])];
  const winners = [];
  while (winners.length < Math.min(giveaway.winnerCount, pool.length)) {
    winners.push(pool.splice(crypto.randomInt(pool.length), 1)[0]);
  }
  return winners;
}
async function finishGiveaway(id, reroll = false) {
  const giveaway = giveaways[id];
  if (!giveaway) throw new Error("Giveaway not found.");
  const channel = await client.channels.fetch(giveaway.channelId);
  const winners = pickWinners(giveaway);
  if (!reroll) {
    giveaway.ended = true;
    giveaway.winnerIds = winners;
    saveJson(GIVEAWAYS_FILE, giveaways);
    const message = await channel.messages.fetch(giveaway.messageId).catch(() => null);
    if (message) await message.edit({
      embeds: [makeEmbed("🎉 Giveaway ended", `**Prize:** ${giveaway.prize}\n**Winner(s):** ${winners.length ? winners.map(x => `<@${x}>`).join(", ") : "No entries"}`)],
      components: [giveawayRow(id, true)],
    });
  }
  await channel.send({ content: winners.length ? `🎉 ${winners.map(x => `<@${x}>`).join(", ")} won **${giveaway.prize}**!` : `No valid entries for **${giveaway.prize}**.` });
  return winners;
}
async function checkGiveaways() {
  for (const [id, giveaway] of Object.entries(giveaways)) {
    if (!giveaway.ended && giveaway.endsAt <= Date.now()) {
      await finishGiveaway(id).catch(error => console.error(error));
    }
  }
}

client.once("clientReady", async () => {
  console.log(`Logged in as ${client.user.tag}`);
  await deployCommands().catch(console.error);
  await checkGiveaways();
  setInterval(checkGiveaways, 15000);
});

client.on("interactionCreate", async interaction => {
  try {
    if (interaction.isButton()) {
      if (interaction.customId.startsWith("verify:")) {
        const role = interaction.guild.roles.cache.get(interaction.customId.split(":")[1]);
        if (!role) return interaction.reply({ content: "Role no longer exists.", ephemeral: true });
        if (role.position >= interaction.guild.members.me.roles.highest.position) return interaction.reply({ content: "Move my bot role above the verify role.", ephemeral: true });
        if (interaction.member.roles.cache.has(role.id)) return interaction.reply({ content: "You are already verified.", ephemeral: true });
        await interaction.member.roles.add(role);
        return interaction.reply({ content: `Verified. You received ${role}.`, ephemeral: true });
      }
      if (interaction.customId.startsWith("role_toggle:")) {
        const role = interaction.guild.roles.cache.get(interaction.customId.split(":")[1]);
        if (!role) return interaction.reply({ content: "Role no longer exists.", ephemeral: true });
        if (role.position >= interaction.guild.members.me.roles.highest.position) return interaction.reply({ content: "Move my bot role above this role.", ephemeral: true });
        if (interaction.member.roles.cache.has(role.id)) {
          await interaction.member.roles.remove(role);
          return interaction.reply({ content: `Removed ${role}.`, ephemeral: true });
        }
        await interaction.member.roles.add(role);
        return interaction.reply({ content: `Added ${role}.`, ephemeral: true });
      }
      if (interaction.customId.startsWith("giveaway_join:")) {
        const id = interaction.customId.split(":")[1];
        const giveaway = giveaways[id];
        if (!giveaway || giveaway.ended) return interaction.reply({ content: "This giveaway has ended.", ephemeral: true });
        giveaway.entries ||= [];
        const i = giveaway.entries.indexOf(interaction.user.id);
        if (i >= 0) {
          giveaway.entries.splice(i, 1);
          saveJson(GIVEAWAYS_FILE, giveaways);
          return interaction.reply({ content: "You left the giveaway.", ephemeral: true });
        }
        giveaway.entries.push(interaction.user.id);
        saveJson(GIVEAWAYS_FILE, giveaways);
        return interaction.reply({ content: `You entered **${giveaway.prize}**.`, ephemeral: true });
      }
      if (interaction.customId === "create_ticket") {
        const safe = interaction.user.username.toLowerCase().replace(/[^a-z0-9-]/g, "").slice(0, 30);
        const existing = interaction.guild.channels.cache.find(c => c.name === `ticket-${safe}`);
        if (existing) return interaction.reply({ content: `You already have a ticket: ${existing}`, ephemeral: true });
        const channel = await interaction.guild.channels.create({
          name: `ticket-${safe}`,
          type: ChannelType.GuildText,
          permissionOverwrites: [
            { id: interaction.guild.id, deny: [PermissionFlagsBits.ViewChannel] },
            { id: interaction.user.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ReadMessageHistory] },
            { id: interaction.guild.members.me.id, allow: [PermissionFlagsBits.ViewChannel, PermissionFlagsBits.SendMessages, PermissionFlagsBits.ManageChannels] },
          ],
        });
        await channel.send({ content: `${interaction.user}`, embeds: [makeEmbed("🎫 Support Ticket", "Explain your issue clearly. Staff will help you soon.")] });
        return interaction.reply({ content: `Ticket created: ${channel}`, ephemeral: true });
      }
      return;
    }

    if (!interaction.isChatInputCommand()) return;
    const cmd = interaction.commandName;

    if (cmd === "ping") return interaction.reply({ content: `Pong: ${client.ws.ping}ms`, ephemeral: true });
    if (cmd === "help") return interaction.reply({ embeds: [makeEmbed("Helixcraft commands", "`/verify-panel`, `/role-panel`, `/say`, `/embed`, `/event`, `/giveaway`, `/warn`, `/warnings`, `/ticket-panel`")], ephemeral: true });

    if (cmd === "say") {
      const channel = interaction.options.getChannel("channel") || interaction.channel;
      if (!channel.isTextBased()) return interaction.reply({ content: "Choose a text channel.", ephemeral: true });
      await channel.send(interaction.options.getString("message"));
      return interaction.reply({ content: `Sent in ${channel}.`, ephemeral: true });
    }
    if (cmd === "embed") {
      const channel = interaction.options.getChannel("channel") || interaction.channel;
      if (!channel.isTextBased()) return interaction.reply({ content: "Choose a text channel.", ephemeral: true });
      const raw = (interaction.options.getString("color") || "5865F2").replace("#", "");
      const color = /^[0-9a-f]{6}$/i.test(raw) ? parseInt(raw, 16) : BRAND.color;
      await channel.send({ embeds: [makeEmbed(interaction.options.getString("title"), interaction.options.getString("description"), color)] });
      return interaction.reply({ content: `Embed sent in ${channel}.`, ephemeral: true });
    }
    if (cmd === "verify-panel") {
      const role = interaction.options.getRole("role");
      if (role.position >= interaction.guild.members.me.roles.highest.position) return interaction.reply({ content: "Move my bot role above the verify role.", ephemeral: true });
      const row = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId(`verify:${role.id}`).setLabel("Verify").setEmoji("✅").setStyle(ButtonStyle.Success));
      await interaction.channel.send({ embeds: [makeEmbed(interaction.options.getString("title") || "✅ Verify yourself", interaction.options.getString("description") || "Click below to verify and access the server.", BRAND.success)], components: [row] });
      return interaction.reply({ content: "Verification panel created.", ephemeral: true });
    }
    if (cmd === "role-panel") {
      const roles = [1,2,3,4,5].map(i => interaction.options.getRole(`role${i}`)).filter(Boolean);
      const invalid = roles.find(r => r.position >= interaction.guild.members.me.roles.highest.position);
      if (invalid) return interaction.reply({ content: `Move my bot role above ${invalid}.`, ephemeral: true });
      const row = new ActionRowBuilder().addComponents(roles.map(r => new ButtonBuilder().setCustomId(`role_toggle:${r.id}`).setLabel(r.name).setStyle(ButtonStyle.Secondary)));
      await interaction.channel.send({ embeds: [makeEmbed(interaction.options.getString("title"), `${interaction.options.getString("description")}\n\nClick a button to add or remove a role.`)], components: [row] });
      return interaction.reply({ content: "Role panel created.", ephemeral: true });
    }
    if (cmd === "event") {
      const sub = interaction.options.getSubcommand();
      if (sub === "create") {
        const start = parseDate(interaction.options.getString("start"));
        const end = parseDate(interaction.options.getString("end"));
        if (start <= new Date() || end <= start) return interaction.reply({ content: "Start must be future and end must be after start.", ephemeral: true });
        const event = await interaction.guild.scheduledEvents.create({
          name: interaction.options.getString("name"),
          description: interaction.options.getString("description") || "Helixcraft event",
          scheduledStartTime: start,
          scheduledEndTime: end,
          privacyLevel: GuildScheduledEventPrivacyLevel.GuildOnly,
          entityType: GuildScheduledEventEntityType.External,
          entityMetadata: { location: interaction.options.getString("location") },
        });
        return interaction.reply({ content: `Event created: **${event.name}** (ID: \`${event.id}\`)` });
      }
      if (sub === "list") {
        const events = await interaction.guild.scheduledEvents.fetch();
        const text = events.size ? events.map(e => `**${e.name}** — \`${e.id}\` — <t:${Math.floor(e.scheduledStartTimestamp/1000)}:F>`).join("\n") : "No scheduled events.";
        return interaction.reply({ embeds: [makeEmbed("Scheduled events", text)], ephemeral: true });
      }
      const event = await interaction.guild.scheduledEvents.fetch(interaction.options.getString("event_id"));
      await event.delete();
      return interaction.reply({ content: `Deleted **${event.name}**.`, ephemeral: true });
    }
    if (cmd === "giveaway") {
      const sub = interaction.options.getSubcommand();
      if (sub === "start") {
        const channel = interaction.options.getChannel("channel") || interaction.channel;
        if (!channel.isTextBased()) return interaction.reply({ content: "Choose a text channel.", ephemeral: true });
        const id = crypto.randomBytes(4).toString("hex");
        const prize = interaction.options.getString("prize");
        const endsAt = Date.now() + parseDuration(interaction.options.getString("duration"));
        const winnerCount = interaction.options.getInteger("winners");
        const message = await channel.send({ embeds: [makeEmbed("🎉 Giveaway", `**Prize:** ${prize}\n**Winners:** ${winnerCount}\n**Ends:** <t:${Math.floor(endsAt/1000)}:R>\n**ID:** \`${id}\``, BRAND.success)], components: [giveawayRow(id)] });
        giveaways[id] = { id, guildId: interaction.guildId, channelId: channel.id, messageId: message.id, prize, winnerCount, endsAt, ended: false, entries: [] };
        saveJson(GIVEAWAYS_FILE, giveaways);
        return interaction.reply({ content: `Giveaway started in ${channel}. ID: \`${id}\``, ephemeral: true });
      }
      if (sub === "list") {
        const active = Object.values(giveaways).filter(g => g.guildId === interaction.guildId && !g.ended);
        const text = active.length ? active.map(g => `**${g.prize}** — \`${g.id}\` — ${g.entries.length} entries — <t:${Math.floor(g.endsAt/1000)}:R>`).join("\n") : "No active giveaways.";
        return interaction.reply({ embeds: [makeEmbed("Active giveaways", text)], ephemeral: true });
      }
      const id = interaction.options.getString("giveaway_id");
      const giveaway = giveaways[id];
      if (!giveaway || giveaway.guildId !== interaction.guildId) return interaction.reply({ content: "Giveaway not found.", ephemeral: true });
      if (sub === "end") {
        if (giveaway.ended) return interaction.reply({ content: "Already ended.", ephemeral: true });
        await interaction.deferReply({ ephemeral: true });
        const winners = await finishGiveaway(id);
        return interaction.editReply(winners.length ? `Winner(s): ${winners.map(x => `<@${x}>`).join(", ")}` : "Ended without entries.");
      }
      if (!giveaway.ended) return interaction.reply({ content: "End it before rerolling.", ephemeral: true });
      await interaction.deferReply({ ephemeral: true });
      const winners = await finishGiveaway(id, true);
      return interaction.editReply(winners.length ? `New winner(s): ${winners.map(x => `<@${x}>`).join(", ")}` : "No entries.");
    }
    if (cmd === "warn") {
      const user = interaction.options.getUser("user");
      const guildWarnings = warnings[interaction.guildId] ||= {};
      const list = guildWarnings[user.id] ||= [];
      list.push({ reason: interaction.options.getString("reason"), moderatorId: interaction.user.id, date: new Date().toISOString() });
      saveJson(WARNINGS_FILE, warnings);
      return interaction.reply({ content: `${user} warned.`, ephemeral: true });
    }
    if (cmd === "warnings") {
      const user = interaction.options.getUser("user");
      const list = warnings[interaction.guildId]?.[user.id] || [];
      const text = list.length ? list.map((w,i) => `**${i+1}.** ${w.reason} — <@${w.moderatorId}>`).join("\n") : "No warnings.";
      return interaction.reply({ embeds: [makeEmbed(`Warnings for ${user.tag}`, text, BRAND.warning)], ephemeral: true });
    }
    if (cmd === "ticket-panel") {
      const row = new ActionRowBuilder().addComponents(new ButtonBuilder().setCustomId("create_ticket").setLabel("Create Ticket").setEmoji("🎫").setStyle(ButtonStyle.Primary));
      return interaction.reply({ embeds: [makeEmbed("🎫 Helixcraft Support", "Click below to create a private support ticket.")], components: [row] });
    }
  } catch (error) {
    console.error(error);
    const payload = { content: `Something went wrong: ${error.message}`, ephemeral: true };
    if (interaction.replied || interaction.deferred) return interaction.followUp(payload).catch(() => {});
    return interaction.reply(payload).catch(() => {});
  }
});

client.login(TOKEN);
