# Helixcraft Bot v5.2.1 — Ticket System

## Nieuwe ticketflow

1. Gebruiker kiest een categorie uit een dropdown.
2. Een formulier opent met:
   - Subject
   - Detailed explanation
   - Expected solution
   - Optional extra information
3. De bot maakt een privé ticketkanaal.
4. Support kan:
   - claimen;
   - unclaimen;
   - prioriteit instellen;
   - staff notes toevoegen;
   - sluiten.

## Prioriteiten

- 🟢 Low
- 🔵 Normal
- 🟠 High
- 🔴 Urgent

## Transcriptfix

- transcriptmap wordt automatisch aangemaakt;
- maximaal 5.000 berichten;
- tekst, embeds en attachments worden opgenomen;
- transcript wordt als HTML naar het ticketlogkanaal gestuurd;
- als het logkanaal ontbreekt, blijft het transcript lokaal opgeslagen;
- ticketstatus wordt teruggezet als transcriptgeneratie mislukt;
- dubbele sluitacties worden geblokkeerd.

## Installeren

```bash
cd /root/helixcraft-bot-v5.2.1-ticket-system-fix
chmod +x apply-v5.2.1-ticket-fix.sh
./apply-v5.2.1-ticket-fix.sh
```

Maak daarna een nieuw ticketpanel:

```text
/ticket-panel-v2
```

Verwijder het oude panelbericht uit Discord, omdat bestaande berichten niet
automatisch nieuwe dropdowns en componenten krijgen.
