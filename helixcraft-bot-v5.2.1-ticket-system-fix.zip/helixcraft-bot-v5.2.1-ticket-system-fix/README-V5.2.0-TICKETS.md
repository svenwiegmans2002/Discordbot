# Helixcraft Bot v5.2.0 — Advanced Ticket Forms

## Nieuwe ticketflow

1. Een gebruiker kiest een categorie uit een dropdownmenu.
2. Discord opent een formulier met:
   - Subject
   - Detailed explanation
   - Expected solution
   - Optional extra information
3. De bot maakt een privé ticketkanaal.
4. Support kan het ticket claimen of unclaimen.
5. Support kan prioriteit instellen:
   - 🟢 Low
   - 🔵 Normal
   - 🟠 High
   - 🔴 Urgent
6. De ticketembed wordt automatisch bijgewerkt.

## Bestaande functies behouden

- `/ticket close` met transcript
- `/ticket-note`
- `/ticket-priority`
- Auto-close
- Ticketlogs
- Supportrol
- Ticketcategorieën uit de serverconfiguratie

## Installeren

```bash
cd /root/helixcraft-bot-v5.2.0-ticket-forms
chmod +x apply-v5.2.0-ticket-fix.sh
./apply-v5.2.0-ticket-fix.sh
```

Maak daarna een nieuw ticketpanel:

```text
/ticket-panel-v2
```

Oude panelberichten worden niet automatisch aangepast; verwijder die in Discord.
