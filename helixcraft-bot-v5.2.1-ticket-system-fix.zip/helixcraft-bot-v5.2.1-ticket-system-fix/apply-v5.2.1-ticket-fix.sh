#!/usr/bin/env bash
set -Eeuo pipefail

SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ACTIVE_DIR="/root/helixcraft-bot"
STAMP="$(date +%Y%m%d-%H%M%S)"

for file in src/bot.js src/v4.js src/utils.js src/commands-v4.js; do
  if [ -f "$ACTIVE_DIR/$file" ]; then
    cp "$ACTIVE_DIR/$file" "/root/$(basename "$file").backup-$STAMP"
  fi
  cp "$SOURCE_DIR/$file" "$ACTIVE_DIR/$file"
done

cp "$SOURCE_DIR/package.json" "$ACTIVE_DIR/package.json"

mkdir -p "$ACTIVE_DIR/transcripts"

cd "$ACTIVE_DIR"
npm install --no-audit --no-fund
node --check src/bot.js
node --check src/v4.js
node --check src/utils.js
node --check src/commands-v4.js

if systemctl list-unit-files | grep -q '^helixcraft-bot.service'; then
  systemctl restart helixcraft-bot
  sleep 3
  systemctl --no-pager --full status helixcraft-bot || true
else
  pkill -f "/root/helixcraft-bot/index.js" 2>/dev/null || true
  echo "Patch applied. Start with: cd /root/helixcraft-bot && npm start"
fi

echo
echo "v5.2.1 ticket system applied."
echo "Create a new panel with /ticket-panel-v2."
echo "Old ticket panels must be removed manually."
