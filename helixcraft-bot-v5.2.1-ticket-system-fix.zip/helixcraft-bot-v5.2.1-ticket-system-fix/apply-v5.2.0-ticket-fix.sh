#!/usr/bin/env bash
set -Eeuo pipefail

SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ACTIVE_DIR="/root/helixcraft-bot"
STAMP="$(date +%Y%m%d-%H%M%S)"

if [ ! -f "$ACTIVE_DIR/src/v4.js" ]; then
  echo "Actieve v4.js niet gevonden: $ACTIVE_DIR/src/v4.js"
  exit 1
fi

cp "$ACTIVE_DIR/src/v4.js" "/root/v4.js.backup-$STAMP"
cp "$SOURCE_DIR/src/v4.js" "$ACTIVE_DIR/src/v4.js"

cd "$ACTIVE_DIR"
node --check src/v4.js

if systemctl list-unit-files | grep -q '^helixcraft-bot.service'; then
  systemctl restart helixcraft-bot
  sleep 3
  systemctl --no-pager --full status helixcraft-bot || true
else
  pkill -f "/root/helixcraft-bot/index.js" 2>/dev/null || true
  echo "Patch toegepast. Start met: cd /root/helixcraft-bot && npm start"
fi

echo
echo "v5.2.0 ticketsysteem toegepast."
echo "Maak daarna een nieuw panel met /ticket-panel-v2."
echo "Oude ticketpanels blijven oud; verwijder die handmatig uit Discord."
