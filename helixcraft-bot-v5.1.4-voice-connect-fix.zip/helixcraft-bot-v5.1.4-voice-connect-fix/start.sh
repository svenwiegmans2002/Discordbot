#!/usr/bin/env bash
set -e
cd /root/helixcraft-bot
exec node index.js
