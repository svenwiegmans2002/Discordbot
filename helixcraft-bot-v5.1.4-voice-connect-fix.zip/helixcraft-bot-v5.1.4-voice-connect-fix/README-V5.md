# Helixcraft Bot v5

## Added
- Realtime dashboard via Server-Sent Events (3-second updates)
- CPU, RAM, process memory, Discord activity and optional Minecraft player count
- 30-day activity metrics and SVG graphs
- Global search across settings, audits, tickets, warnings, giveaways and Message Studio data
- Filterable/exportable Audit Log V5
- Message Studio V5: drafts, templates, editing sent messages, duplication through templates/drafts, A/B labels, three embeds, role buttons, ticket buttons and dropdowns
- Music: Spotify playlist/album/track metadata expansion, lyrics, loop track/queue, shuffle, autoplay, equalizer presets, cover art metadata and live progress

## CT dependencies
```bash
apt update
apt install -y ffmpeg python3-pip
python3 -m pip install -U yt-dlp --break-system-packages
```

## Optional Spotify support
Create Spotify developer credentials and add:
```env
SPOTIFY_CLIENT_ID=...
SPOTIFY_CLIENT_SECRET=...
```
Spotify is used for playlist/track metadata only. The bot resolves playable audio using yt-dlp-supported sources.

## Optional Minecraft status
```env
MINECRAFT_HOST=play.example.net
MINECRAFT_PORT=25565
```

## New commands
`/loop`, `/shuffle`, `/autoplay`, `/equalizer`, `/lyrics`

## Dashboard pages
- `/g/SERVER_ID/v5`
- `/g/SERVER_ID/studio-v5`
- `/g/SERVER_ID/analytics-v5`
- `/g/SERVER_ID/search-v5`
- `/g/SERVER_ID/audit-v5`
