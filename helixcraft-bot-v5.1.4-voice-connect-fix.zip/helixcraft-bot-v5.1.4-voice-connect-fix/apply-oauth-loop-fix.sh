#!/usr/bin/env bash
set -Eeuo pipefail

SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ACTIVE_DIR="/root/helixcraft-bot"
BACKUP="/root/dashboard.js.backup-$(date +%Y%m%d-%H%M%S)"

cp "$ACTIVE_DIR/src/dashboard.js" "$BACKUP"
cp "$SOURCE_DIR/src/dashboard.js" "$ACTIVE_DIR/src/dashboard.js"
cp "$SOURCE_DIR/package.json" "$ACTIVE_DIR/package.json"

cd "$ACTIVE_DIR"

if ! grep -q '^SESSION_SECRET=' .env; then
  echo "SESSION_SECRET=$(openssl rand -hex 32)" >> .env
fi

node --check src/dashboard.js
npm install --no-audit --no-fund

if systemctl list-unit-files | grep -q '^helixcraft-bot.service'; then
  systemctl restart helixcraft-bot
  sleep 3
  systemctl --no-pager --full status helixcraft-bot || true
else
  pkill -f "/root/helixcraft-bot/index.js" 2>/dev/null || true
  echo "Patch installed. Start with: cd /root/helixcraft-bot && npm start"
fi

echo
echo "OAuth loop fix applied."
echo "Backup: $BACKUP"
echo "Delete cookies for bot.helixcraft-hosting.net or use an incognito window."
