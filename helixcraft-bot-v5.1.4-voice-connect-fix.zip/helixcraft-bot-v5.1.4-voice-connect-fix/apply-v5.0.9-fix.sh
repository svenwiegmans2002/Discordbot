#!/usr/bin/env bash
set -Eeuo pipefail

SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ACTIVE_DIR="/root/helixcraft-bot"

if [ ! -d "$ACTIVE_DIR" ]; then
  echo "Active bot directory not found: $ACTIVE_DIR"
  exit 1
fi

cp "$SOURCE_DIR/src/music.js" "$ACTIVE_DIR/src/music.js"

cd "$ACTIVE_DIR"
node --check src/music.js
node -e "require('./src/music.js'); console.log('Spotify URL parser self-test passed.')"

if systemctl list-unit-files | grep -q '^helixcraft-bot.service'; then
  systemctl restart helixcraft-bot
  sleep 3
  systemctl --no-pager --full status helixcraft-bot || true
else
  pkill -f "/root/helixcraft-bot/index.js" 2>/dev/null || true
  echo "Patch applied. Start with: cd /root/helixcraft-bot && npm start"
fi

echo
echo "Spotify URL detection fix applied."
