# Helixcraft Bot v5.0.4 — Automatic Voice Rebuild

This version keeps all v5 features and rebuilds only the Discord voice
connection layer.

## Included fixes

- `@discordjs/voice` upgraded to 0.19.2.
- `libsodium-wrappers` and `opusscript` included.
- Existing voice connections are destroyed before reconnecting.
- The configured dashboard voice channel remains authoritative.
- Temporary voice creation remains disabled.
- Voice connection is attempted automatically up to three times.
- The second attempt changes the self-deaf mode as a compatibility fallback.
- Precise channel permissions are checked in code.
- Voice state transitions and the full Discord voice dependency report are
  logged automatically.
- Dashboard exposes `/g/<guild-id>/music/diagnostic`.
- A one-command installer backs up the active bot, preserves `.env` and data,
  installs dependencies, validates code, replaces the active folder and starts
  a persistent systemd service.

## Install without editing files

Upload the zip to GitHub, download and extract it, then run:

```bash
cd /root/helixcraft-bot-v5.0.4-voice-rebuild
chmod +x install-and-replace.sh
./install-and-replace.sh
```

The script performs the update and starts the bot automatically.

## Logs

```bash
journalctl -u helixcraft-bot -f
```
