#!/usr/bin/env bash
set -Eeuo pipefail

SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ACTIVE_DIR="/root/helixcraft-bot"

if [ ! -d "$ACTIVE_DIR" ]; then
  echo "Active bot directory not found: $ACTIVE_DIR"
  exit 1
fi

cp "$SOURCE_DIR/src/music.js" "$ACTIVE_DIR/src/music.js"

# Remove persisted queue/settings files that may contain old ytsearch1 entries.
rm -f "$ACTIVE_DIR/data/musicQueue.json" \
      "$ACTIVE_DIR/data/musicState.json" \
      "$ACTIVE_DIR/data/musicHistory.json.tmp" 2>/dev/null || true

cd "$ACTIVE_DIR"
node --check src/music.js

if systemctl list-unit-files | grep -q '^helixcraft-bot.service'; then
  systemctl restart helixcraft-bot
  sleep 3
  systemctl --no-pager --full status helixcraft-bot || true
else
  pkill -f "/root/helixcraft-bot/index.js" 2>/dev/null || true
  echo "Patch applied. Start with: cd /root/helixcraft-bot && npm start"
fi

echo
echo "Applied v5.0.8. The code no longer constructs or sends ytsearch1: URLs."
