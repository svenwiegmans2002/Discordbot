#!/usr/bin/env bash
set -Eeuo pipefail

SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ACTIVE_DIR="/root/helixcraft-bot"

cp "$SOURCE_DIR/src/music.js" "$ACTIVE_DIR/src/music.js"
cp "$SOURCE_DIR/src/spotifyOAuth.js" "$ACTIVE_DIR/src/spotifyOAuth.js"
cp "$SOURCE_DIR/src/dashboard.js" "$ACTIVE_DIR/src/dashboard.js"
cp "$SOURCE_DIR/package.json" "$ACTIVE_DIR/package.json"
mkdir -p "$ACTIVE_DIR/data"
[ -f "$ACTIVE_DIR/data/spotifyTokens.json" ] || echo '{}' > "$ACTIVE_DIR/data/spotifyTokens.json"

cd "$ACTIVE_DIR"
npm install --no-audit --no-fund
node --check src/music.js
node --check src/spotifyOAuth.js
node --check src/dashboard.js

if systemctl list-unit-files | grep -q '^helixcraft-bot.service'; then
  systemctl restart helixcraft-bot
  sleep 3
  systemctl --no-pager --full status helixcraft-bot || true
else
  pkill -f "/root/helixcraft-bot/index.js" 2>/dev/null || true
  echo "Patch installed. Start with: cd /root/helixcraft-bot && npm start"
fi
