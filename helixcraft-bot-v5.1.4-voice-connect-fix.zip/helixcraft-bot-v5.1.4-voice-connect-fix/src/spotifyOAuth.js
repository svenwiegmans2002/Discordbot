const crypto = require('node:crypto');
const store = require('./store');

const TOKEN_STORE = 'spotifyTokens';

function redirectUri() {
  return (
    process.env.SPOTIFY_REDIRECT_URI ||
    `${process.env.DASHBOARD_URL || 'http://127.0.0.1:3000'}/spotify/callback`
  );
}

function configured() {
  return Boolean(
    process.env.SPOTIFY_CLIENT_ID &&
    process.env.SPOTIFY_CLIENT_SECRET &&
    redirectUri()
  );
}

function authUrl(state) {
  if (!configured()) throw new Error('Spotify OAuth is not configured.');

  const params = new URLSearchParams({
    client_id: process.env.SPOTIFY_CLIENT_ID,
    response_type: 'code',
    redirect_uri: redirectUri(),
    state,
    scope: 'playlist-read-private playlist-read-collaborative',
    show_dialog: 'true',
  });

  return `https://accounts.spotify.com/authorize?${params}`;
}

async function tokenRequest(body) {
  const basic = Buffer.from(
    `${process.env.SPOTIFY_CLIENT_ID}:${process.env.SPOTIFY_CLIENT_SECRET}`
  ).toString('base64');

  const response = await fetch('https://accounts.spotify.com/api/token', {
    method: 'POST',
    headers: {
      Authorization: `Basic ${basic}`,
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: new URLSearchParams(body),
    signal: AbortSignal.timeout(20_000),
  });

  const text = await response.text();

  if (!response.ok) {
    throw new Error(`Spotify token error ${response.status}: ${text.slice(0, 500)}`);
  }

  return JSON.parse(text);
}

async function exchangeCode(guildId, code) {
  const payload = await tokenRequest({
    grant_type: 'authorization_code',
    code,
    redirect_uri: redirectUri(),
  });

  const now = Date.now();

  store.mutate(TOKEN_STORE, all => {
    all[guildId] = {
      accessToken: payload.access_token,
      refreshToken: payload.refresh_token,
      expiresAt: now + Math.max(60, payload.expires_in - 60) * 1000,
      scope: payload.scope || '',
      tokenType: payload.token_type || 'Bearer',
      connectedAt: now,
    };
  });

  return payload;
}

async function accessToken(guildId) {
  const all = store.read(TOKEN_STORE);
  const record = all[guildId];

  if (!record?.refreshToken) {
    throw new Error(
      'Spotify is not connected for this server. Open Dashboard → Music Manager → Connect Spotify.'
    );
  }

  if (record.accessToken && Date.now() < Number(record.expiresAt || 0)) {
    return record.accessToken;
  }

  const payload = await tokenRequest({
    grant_type: 'refresh_token',
    refresh_token: record.refreshToken,
  });

  store.mutate(TOKEN_STORE, tokens => {
    const current = tokens[guildId] || record;
    tokens[guildId] = {
      ...current,
      accessToken: payload.access_token,
      refreshToken: payload.refresh_token || current.refreshToken,
      expiresAt: Date.now() + Math.max(60, payload.expires_in - 60) * 1000,
      scope: payload.scope || current.scope || '',
      tokenType: payload.token_type || 'Bearer',
    };
  });

  return payload.access_token;
}

function status(guildId) {
  const record = store.read(TOKEN_STORE)[guildId];
  return {
    connected: Boolean(record?.refreshToken),
    connectedAt: record?.connectedAt || null,
    scope: record?.scope || '',
  };
}

function disconnect(guildId) {
  store.mutate(TOKEN_STORE, all => {
    delete all[guildId];
  });
}

function stateToken(guildId) {
  return `${guildId}.${crypto.randomBytes(18).toString('hex')}`;
}

module.exports = {
  authUrl,
  exchangeCode,
  accessToken,
  status,
  disconnect,
  stateToken,
  redirectUri,
  configured,
};
