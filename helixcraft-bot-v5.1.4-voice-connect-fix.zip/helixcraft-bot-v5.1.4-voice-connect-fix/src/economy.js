const store=require('./store');
function get(gid,uid){const all=store.read('economy');all[gid]||={};all[gid][uid]||={wallet:0,bank:0,lastDaily:0,lastWork:0,lastCrime:0,won:0,lost:0};return {all,row:all[gid][uid]}}
function inventory(gid,uid){const all=store.read('inventory');all[gid]||={};all[gid][uid]||=[];return {all,row:all[gid][uid]}}
function save(all){store.write('economy',all)}
module.exports={get,inventory,save};
