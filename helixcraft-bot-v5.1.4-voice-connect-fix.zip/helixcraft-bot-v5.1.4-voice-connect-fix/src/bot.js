const fs=require('fs'); const path=require('path'); const crypto=require('crypto');
const {Client,GatewayIntentBits,Partials,REST,Routes,PermissionFlagsBits,ChannelType,ActionRowBuilder,ButtonBuilder,ButtonStyle,AuditLogEvent}=require('discord.js');
const commands=require('./commands');
const {v4Commands}=require('./commands-v4');
const {installV4}=require('./v4'); const music=require('./music'); const messageStudio=require('./messageStudio'); const studioV5=require('./messageStudioV5'); const stats=require('./stats'); const store=require('./store'); const {BRAND,embed,parseDuration,id,log,canManageRole,transcript}=require('./utils');
let client;
function buttonRow(customId,label,style=ButtonStyle.Primary,emoji){const b=new ButtonBuilder().setCustomId(customId).setLabel(label).setStyle(style);if(emoji)b.setEmoji(emoji);return new ActionRowBuilder().addComponents(b)}
function giveawayRow(gid,disabled=false){return buttonRow(`gw:join:${gid}`,'Enter / Leave',ButtonStyle.Success,'🎉').setComponents(buttonRow(`gw:join:${gid}`,'Enter / Leave',ButtonStyle.Success,'🎉').components.map(x=>x.setDisabled(disabled)))}
async function deploy(){
 const merged=[...commands,...v4Commands];
 const names=new Set();
 const duplicates=[];
 for(const command of merged){
  if(names.has(command.name)) duplicates.push(command.name);
  names.add(command.name);
 }
 if(duplicates.length){
  throw new Error(`Duplicate slash command names: ${[...new Set(duplicates)].join(', ')}`);
 }
 const rest=new REST({version:'10'}).setToken(process.env.BOT_TOKEN);
 await rest.put(
  Routes.applicationGuildCommands(process.env.CLIENT_ID,process.env.GUILD_ID),
  {body:merged}
 );
 console.log(`Slash commands deployed (${merged.length} unique commands).`);
}
async function finishGiveaway(gid,reroll=false){const all=store.read('giveaways');const g=all[gid];if(!g)throw new Error('Giveaway not found');const ch=await client.channels.fetch(g.channelId);const pool=[];for(const uid of [...new Set(g.entries||[])]){pool.push(uid);if(g.bonusEntries?.includes(uid))pool.push(uid)}const winners=[];while(pool.length&&winners.length<g.winners){const uid=pool.splice(crypto.randomInt(pool.length),1)[0];if(!winners.includes(uid))winners.push(uid)}if(!reroll){g.ended=true;g.paused=false;g.winnerIds=winners;store.write('giveaways',all);const msg=await ch.messages.fetch(g.messageId).catch(()=>null);if(msg)await msg.edit({embeds:[embed('🎉 Giveaway ended',`**Prize:** ${g.prize}\n**Winner(s):** ${winners.length?winners.map(x=>`<@${x}>`).join(', '):'No entries'}\n**ID:** \`${gid}\``,BRAND.warning)],components:[]}).catch(()=>{})}await ch.send({content:winners.length?`🏆 ${winners.map(x=>`<@${x}>`).join(', ')} won **${g.prize}**!`:`No valid entries for **${g.prize}**.`});return winners}
async function scheduler(){await messageStudio.processScheduledMessages(client);const now=Date.now();const ps=store.read('punishments');let changed=false;for(const p of ps){if(!p.done&&p.until<=now){const guild=client.guilds.cache.get(p.guildId);if(p.type==='tempban'&&guild)await guild.members.unban(p.userId,'Temporary ban expired').catch(()=>{});p.done=true;changed=true}}if(changed)store.write('punishments',ps);const gs=store.read('giveaways');for(const [gid,g] of Object.entries(gs)){if(!g.ended&&!g.paused&&g.endsAt<=now)await finishGiveaway(gid).catch(console.error)}const tickets=store.read('tickets');for(const [cid,t] of Object.entries(tickets)){if(t.status==='open'&&t.autoCloseAt&&t.autoCloseAt<=now){const ch=await client.channels.fetch(cid).catch(()=>null);if(ch){await closeTicket(ch,null,'Auto-closed due to inactivity').catch(()=>{})}}}}
async function closeTicket(channel,actor,reason='Closed'){const tickets=store.read('tickets');const t=tickets[channel.id];if(!t)throw new Error('This is not a tracked ticket');const html=await transcript(channel);const file=path.join(__dirname,'..','transcripts',`ticket-${channel.id}.html`);fs.writeFileSync(file,html);t.status='closed';t.closedAt=Date.now();t.closedBy=actor?.id||client.user.id;t.reason=reason;store.write('tickets',tickets);const cfg=store.guildConfig(channel.guild.id);const logCh=cfg.ticketLogChannelId&&channel.guild.channels.cache.get(cfg.ticketLogChannelId);if(logCh?.isTextBased())await logCh.send({content:`Ticket **${channel.name}** closed by ${actor||'system'}.`,files:[file]});await channel.delete(reason).catch(()=>{})}
async function startBot(){client=new Client({intents:[GatewayIntentBits.Guilds,GatewayIntentBits.GuildMembers,GatewayIntentBits.GuildMessages,GatewayIntentBits.MessageContent,GatewayIntentBits.GuildModeration,GatewayIntentBits.GuildVoiceStates,GatewayIntentBits.GuildMessageReactions,GatewayIntentBits.GuildEmojisAndStickers],partials:[Partials.Channel,Partials.Message,Partials.Reaction]});
installV4(client);
client.once('clientReady',async()=>{
console.log('[VOICE DEPENDENCIES]\n'+require('@discordjs/voice').generateDependencyReport());
 console.log(`Logged in as ${client.user.tag}`);
 try{
  await deploy();
 }catch(error){
  console.error('Slash command deployment failed:',error);
 }
 setInterval(scheduler,15000); setInterval(()=>stats.collect(client).catch(console.error),60000); stats.collect(client).catch(console.error);
 await scheduler();
});
client.on('guildMemberAdd',async m=>{const c=store.guildConfig(m.guild.id);if(c.autoroleId){const r=m.guild.roles.cache.get(c.autoroleId);if(canManageRole(m.guild,r))await m.roles.add(r).catch(()=>{})}const ch=c.welcomeChannelId&&m.guild.channels.cache.get(c.welcomeChannelId);if(ch?.isTextBased())await ch.send(c.welcomeMessage.replaceAll('{member}',`${m}`).replaceAll('{server}',m.guild.name).replaceAll('{count}',String(m.guild.memberCount))).catch(()=>{});await log(client,m.guild,'Member joined',`${m.user.tag} (${m.id})`,BRAND.success)});
client.on('guildMemberRemove',m=>log(client,m.guild,'Member left',`${m.user.tag} (${m.id})`,BRAND.warning));
client.on('messageDelete',m=>{if(m.guild&&!m.author?.bot)log(client,m.guild,'Message deleted',`${m.author} in ${m.channel}: ${m.content||'[no content]'}`,BRAND.warning)});
client.on('messageUpdate',(a,b)=>{if(a.guild&&!a.author?.bot&&a.content!==b.content)log(client,a.guild,'Message edited',`${a.author} in ${a.channel}\nBefore: ${a.content||''}\nAfter: ${b.content||''}`)});
client.on('guildMemberUpdate',(a,b)=>{if(a.nickname!==b.nickname)log(client,b.guild,'Nickname changed',`${b.user.tag}: ${a.nickname||a.user.username} → ${b.nickname||b.user.username}`);const old=new Set(a.roles.cache.keys()),neu=new Set(b.roles.cache.keys());const added=[...neu].filter(x=>!old.has(x)),removed=[...old].filter(x=>!neu.has(x));if(added.length||removed.length)log(client,b.guild,'Roles changed',`${b.user.tag}\nAdded: ${added.map(x=>`<@&${x}>`).join(', ')||'none'}\nRemoved: ${removed.map(x=>`<@&${x}>`).join(', ')||'none'}`)});
client.on('voiceStateUpdate',(before,after)=>{
  if(before.channelId!==after.channelId){
    log(
      client,
      after.guild,
      'Voice update',
      `${after.member.user.tag}: ${before.channel||'none'} → ${after.channel||'none'}`
    );
  }

  // Temporary voice creation is intentionally disabled.
  // The music bot will never create or move itself into another voice channel.
});
client.on('channelCreate',ch=>ch.guild&&log(client,ch.guild,'Channel created',`${ch.name} (${ch.id})`,BRAND.success));client.on('channelDelete',ch=>ch.guild&&log(client,ch.guild,'Channel deleted',`${ch.name} (${ch.id})`,BRAND.warning));client.on('emojiCreate',e=>log(client,e.guild,'Emoji created',`${e.name}`,BRAND.success));client.on('emojiDelete',e=>log(client,e.guild,'Emoji deleted',`${e.name}`,BRAND.warning));
client.on('messageCreate',async m=>{if(!m.guild||m.author.bot)return;const stick=store.read('sticky')[m.channel.id];if(stick&&m.id!==stick.lastMessageId){if(stick.lastMessageId)await m.channel.messages.delete(stick.lastMessageId).catch(()=>{});const sent=await m.channel.send({embeds:[embed('📌 Sticky message',stick.message)]});stick.lastMessageId=sent.id;store.mutate('sticky',x=>{x[m.channel.id]=stick})}const tickets=store.read('tickets');if(tickets[m.channel.id]){tickets[m.channel.id].lastActivity=Date.now();tickets[m.channel.id].autoCloseAt=Date.now()+store.guildConfig(m.guild.id).ticketAutoCloseHours*3600000;store.write('tickets',tickets)}});
client.on('interactionCreate',async i=>{try{
if(i.isModalSubmit()&&i.customId.startsWith('say_modal:')){
  const channelId=i.customId.split(':')[1];
  const channel=await i.guild.channels.fetch(channelId).catch(()=>null);
  if(!channel?.isTextBased()){
    return i.reply({content:'The selected text channel is no longer available.',ephemeral:true});
  }

  const content=i.fields.getTextInputValue('message').trim();
  if(!content){
    return i.reply({content:'The message cannot be empty.',ephemeral:true});
  }

  await channel.send({
    content,
    allowedMentions:{parse:['users','roles'],repliedUser:false}
  });

  return i.reply({content:`Message sent in ${channel}.`,ephemeral:true});
}
if(await studioV5.component(i))return; if(await messageStudio.handleComponent(i))return;
if(i.isButton())return handleButton(i);
if(!i.isChatInputCommand())return;
if(['play','pause','resume','skip','stop','queue','nowplaying','volume','loop','shuffle','autoplay','equalizer','lyrics'].includes(i.commandName))return await music.handleCommand(i);
await handleCommand(i)}catch(e){
console.error('Interaction error:',e);
const payload={content:`Error: ${String(e.message||e).slice(0,1800)}`,ephemeral:true};
if(i.deferred&&!i.replied)await i.editReply(payload).catch(()=>{});
else if(i.replied||i.deferred)await i.followUp(payload).catch(()=>{});
else await i.reply(payload).catch(()=>{});
}});
global.__helixClient=client;await client.login(process.env.BOT_TOKEN);return client}
async function handleButton(i){const [kind,action,value]=i.customId.split(':');if(kind==='verify'){const r=i.guild.roles.cache.get(action);if(!canManageRole(i.guild,r))throw new Error('Bot role must be above the verify role');if(i.member.roles.cache.has(r.id))return i.reply({content:'Already verified.',ephemeral:true});await i.member.roles.add(r);return i.reply({content:`Verified: ${r}`,ephemeral:true})}if(kind==='role'){const r=i.guild.roles.cache.get(action);if(!canManageRole(i.guild,r))throw new Error('Cannot manage role');if(i.member.roles.cache.has(r.id)){await i.member.roles.remove(r);return i.reply({content:`Removed ${r}`,ephemeral:true})}await i.member.roles.add(r);return i.reply({content:`Added ${r}`,ephemeral:true})}if(kind==='ticket'&&action==='open'){const cfg=store.guildConfig(i.guild.id);const existing=Object.entries(store.read('tickets')).find(([,t])=>t.guildId===i.guild.id&&t.openerId===i.user.id&&t.status==='open');if(existing)return i.reply({content:`You already have <#${existing[0]}>`,ephemeral:true});const ow=[{id:i.guild.id,deny:[PermissionFlagsBits.ViewChannel]},{id:i.user.id,allow:[PermissionFlagsBits.ViewChannel,PermissionFlagsBits.SendMessages,PermissionFlagsBits.ReadMessageHistory]},{id:i.guild.members.me.id,allow:[PermissionFlagsBits.ViewChannel,PermissionFlagsBits.ManageChannels,PermissionFlagsBits.SendMessages]}];if(cfg.ticketSupportRoleId)ow.push({id:cfg.ticketSupportRoleId,allow:[PermissionFlagsBits.ViewChannel,PermissionFlagsBits.SendMessages,PermissionFlagsBits.ReadMessageHistory]});const ch=await i.guild.channels.create({name:`ticket-${i.user.username}`.toLowerCase().replace(/[^a-z0-9-]/g,'').slice(0,80),type:ChannelType.GuildText,parent:cfg.ticketCategoryId,permissionOverwrites:ow});store.mutate('tickets',x=>{x[ch.id]={guildId:i.guild.id,openerId:i.user.id,status:'open',claimedBy:null,createdAt:Date.now(),lastActivity:Date.now(),autoCloseAt:Date.now()+cfg.ticketAutoCloseHours*3600000}});await ch.send({content:`${i.user} <@&${cfg.ticketSupportRoleId||i.guild.id}>`,embeds:[embed('🎫 Support ticket','Explain your issue clearly. Staff can use `/ticket claim`, `/ticket unclaim`, or `/ticket close`.')]});return i.reply({content:`Ticket created: ${ch}`,ephemeral:true})}if(kind==='gw'&&action==='join'){const all=store.read('giveaways'),g=all[value];if(!g||g.ended||g.paused)return i.reply({content:'Giveaway unavailable.',ephemeral:true});if(g.requiredRoleId&&!i.member.roles.cache.has(g.requiredRoleId))return i.reply({content:`You need <@&${g.requiredRoleId}>.`,ephemeral:true});if(g.minAccountDays&&(Date.now()-i.user.createdTimestamp)<g.minAccountDays*86400000)return i.reply({content:'Your account is too new.',ephemeral:true});if(g.minMemberDays&&(Date.now()-i.member.joinedTimestamp)<g.minMemberDays*86400000)return i.reply({content:'You have not been in the server long enough.',ephemeral:true});g.entries||=[];g.bonusEntries||=[];const idx=g.entries.indexOf(i.user.id);if(idx>=0){g.entries.splice(idx,1);g.bonusEntries=g.bonusEntries.filter(x=>x!==i.user.id);store.write('giveaways',all);return i.reply({content:'You left the giveaway.',ephemeral:true})}g.entries.push(i.user.id);if(g.bonusRoleId&&i.member.roles.cache.has(g.bonusRoleId))g.bonusEntries.push(i.user.id);store.write('giveaways',all);return i.reply({content:'You entered the giveaway.',ephemeral:true})}}
async function handleCommand(i){const c=i.commandName;if(c==='ping')return i.reply(`Pong: ${client.ws.ping}ms`);if(c==='help')return i.reply({embeds:[embed('Helixcraft Bot v3','**Moderation:** `/warn`, `/warnings`, `/unwarn`, `/tempban`, `/softban`, `/slowmode`\n**Tickets:** `/ticket-panel`, `/ticket claim|unclaim|close`\n**Giveaways:** `/giveaway start|list|end|reroll|pause|resume`\n**Server:** `/setup`, `/verify-panel`, `/role-panel`, `/sticky`, `/suggest`, `/backup`\n**Messages:** `/say`, `/embed`')],ephemeral:true});if(c==='say'){
  const target=i.options.getChannel('channel')||i.channel;
  if(!target?.isTextBased())throw new Error('Choose a text channel');

  const modal=new ModalBuilder()
    .setCustomId(`say_modal:${target.id}`)
    .setTitle('Send message as bot');

  const messageInput=new TextInputBuilder()
    .setCustomId('message')
    .setLabel('Message')
    .setStyle(TextInputStyle.Paragraph)
    .setPlaceholder('Hallo\n\nDit is een test')
    .setMinLength(1)
    .setMaxLength(2000)
    .setRequired(true);

  modal.addComponents(
    new ActionRowBuilder().addComponents(messageInput)
  );

  return i.showModal(modal);
}

if(c==='embed'){
  const ch=i.options.getChannel('channel')||i.channel;
  if(!ch?.isTextBased())throw new Error('Choose a text channel');

  const raw=(i.options.getString('color')||'5865F2').replace('#','');
  const color=/^[0-9a-f]{6}$/i.test(raw)?parseInt(raw,16):BRAND.color;
  const description=(i.options.getString('description')||'')
    .replace(/\\n/g,'\n')
    .trim();

  await ch.send({
    embeds:[embed(i.options.getString('title'),description,color)]
  });

  return i.reply({content:`Sent in ${ch}`,ephemeral:true});
}
if(c==='setup'){const s=i.options.getSubcommand();if(s==='welcome')store.setGuildConfig(i.guild.id,{welcomeChannelId:i.options.getChannel('channel').id,welcomeMessage:i.options.getString('message'),autoroleId:i.options.getRole('autorole')?.id||null});if(s==='logging')store.setGuildConfig(i.guild.id,{logChannelId:i.options.getChannel('channel').id});if(s==='tickets')store.setGuildConfig(i.guild.id,{ticketCategoryId:i.options.getChannel('category').id,ticketLogChannelId:i.options.getChannel('log_channel').id,ticketSupportRoleId:i.options.getRole('support_role').id,ticketAutoCloseHours:i.options.getInteger('auto_close_hours')||72});if(s==='tempvoice'){
  store.setGuildConfig(i.guild.id,{
    tempVoiceLobbyId:null,
    tempVoiceCategoryId:null
  });
  return i.reply({
    content:'Temporary voice channels are disabled. Configure the fixed music voice channel in the dashboard instead.',
    ephemeral:true
  });
}if(s==='suggestions')store.setGuildConfig(i.guild.id,{suggestionChannelId:i.options.getChannel('channel').id});if(s==='warnings')store.setGuildConfig(i.guild.id,{warnTimeoutThreshold:i.options.getInteger('threshold'),warnTimeoutMinutes:i.options.getInteger('timeout_minutes')});return i.reply({content:'Configuration saved.',ephemeral:true})}
if(c==='verify-panel'){const r=i.options.getRole('role');if(!canManageRole(i.guild,r))throw new Error('Move bot role above verify role');await i.channel.send({embeds:[embed(i.options.getString('title')||'✅ Verify',i.options.getString('description')||'Click below to verify.',BRAND.success)],components:[buttonRow(`verify:${r.id}`,'Verify',ButtonStyle.Success,'✅')]});return i.reply({content:'Verify panel created.',ephemeral:true})}
if(c==='role-panel'){const roles=[1,2,3,4,5].map(n=>i.options.getRole(`role${n}`)).filter(Boolean);if(roles.some(r=>!canManageRole(i.guild,r)))throw new Error('Bot role must be above all selected roles');const row=new ActionRowBuilder().addComponents(roles.map(r=>new ButtonBuilder().setCustomId(`role:${r.id}`).setLabel(r.name.slice(0,80)).setStyle(ButtonStyle.Secondary)));await i.channel.send({embeds:[embed(i.options.getString('title'),i.options.getString('description'))],components:[row]});return i.reply({content:'Role panel created.',ephemeral:true})}
if(c==='warn'){const u=i.options.getUser('user'),wid=id(),points=i.options.getInteger('points')||1;const all=store.read('warnings');all[i.guild.id]||={};all[i.guild.id][u.id]||=[];all[i.guild.id][u.id].push({id:wid,reason:i.options.getString('reason'),points,moderatorId:i.user.id,createdAt:Date.now()});store.write('warnings',all);const list=all[i.guild.id][u.id];const cfg=store.guildConfig(i.guild.id);if(list.length>=cfg.warnTimeoutThreshold){const m=await i.guild.members.fetch(u.id).catch(()=>null);if(m?.moderatable)await m.timeout(cfg.warnTimeoutMinutes*60000,'Automatic warning escalation')}await log(client,i.guild,'Warning issued',`${u.tag}: ${i.options.getString('reason')} (${points} points)`,BRAND.warning);return i.reply({content:`Warned ${u}. ID: \`${wid}\``})}
if(c==='warnings'){const u=i.options.getUser('user'),list=store.read('warnings')[i.guild.id]?.[u.id]||[];return i.reply({embeds:[embed(`Warnings: ${u.tag}`,list.length?list.map(x=>`\`${x.id}\` • ${x.reason} • ${x.points} pts • <@${x.moderatorId}>`).join('\n'):'No warnings.',BRAND.warning)],ephemeral:true})}
if(c==='unwarn'){const wid=i.options.getString('warning_id'),all=store.read('warnings');let found=false;for(const users of Object.values(all[i.guild.id]||{})){const n=users.findIndex(x=>x.id===wid);if(n>=0){users.splice(n,1);found=true;break}}store.write('warnings',all);return i.reply({content:found?'Warning removed.':'Warning not found.',ephemeral:true})}
if(c==='tempban'){const u=i.options.getUser('user'),dur=parseDuration(i.options.getString('duration'));await i.guild.members.ban(u.id,{reason:i.options.getString('reason')||'Temporary ban'});store.mutate('punishments',x=>{x.push({type:'tempban',guildId:i.guild.id,userId:u.id,until:Date.now()+dur,done:false})});return i.reply(`Temporarily banned ${u}.`)}
if(c==='softban'){const u=i.options.getUser('user');await i.guild.members.ban(u.id,{deleteMessageSeconds:604800,reason:i.options.getString('reason')||'Softban'});await i.guild.members.unban(u.id,'Softban complete');return i.reply(`Softbanned ${u}.`)}
if(c==='slowmode'){await i.channel.setRateLimitPerUser(i.options.getInteger('seconds'));return i.reply(`Slowmode set to ${i.options.getInteger('seconds')}s.`)}
if(c==='ticket-panel'){await i.channel.send({embeds:[embed('🎫 Helixcraft Support','Click below to open a private ticket.')],components:[buttonRow('ticket:open','Open ticket',ButtonStyle.Primary,'🎫')]});return i.reply({content:'Ticket panel created.',ephemeral:true})}
if(c==='ticket'){const s=i.options.getSubcommand(),tickets=store.read('tickets'),t=tickets[i.channel.id];if(!t)throw new Error('Not a tracked ticket');if(s==='claim'){t.claimedBy=i.user.id;store.write('tickets',tickets);return i.reply(`Claimed by ${i.user}.`)}if(s==='unclaim'){t.claimedBy=null;store.write('tickets',tickets);return i.reply('Ticket unclaimed.')}if(s==='close'){await i.reply('Creating transcript and closing...');return closeTicket(i.channel,i.user)}}
if(c==='giveaway'){const s=i.options.getSubcommand(),all=store.read('giveaways');if(s==='start'){const gid=id(),ch=i.options.getChannel('channel')||i.channel,dur=parseDuration(i.options.getString('duration'));const g={id:gid,guildId:i.guild.id,channelId:ch.id,messageId:null,prize:i.options.getString('prize'),winners:i.options.getInteger('winners'),endsAt:Date.now()+dur,remainingMs:null,paused:false,ended:false,entries:[],bonusEntries:[],requiredRoleId:i.options.getRole('required_role')?.id||null,bonusRoleId:i.options.getRole('bonus_role')?.id||null,minAccountDays:i.options.getInteger('min_account_days')||0,minMemberDays:i.options.getInteger('min_member_days')||0};const m=await ch.send({embeds:[embed('🎉 Giveaway',`**Prize:** ${g.prize}\n**Winners:** ${g.winners}\n**Ends:** <t:${Math.floor(g.endsAt/1000)}:R>\n**ID:** \`${gid}\``,BRAND.success)],components:[buttonRow(`gw:join:${gid}`,'Enter / Leave',ButtonStyle.Success,'🎉')]});g.messageId=m.id;all[gid]=g;store.write('giveaways',all);return i.reply({content:`Giveaway started in ${ch}. ID: \`${gid}\``,ephemeral:true})}if(s==='list'){const list=Object.values(all).filter(g=>g.guildId===i.guild.id&&!g.ended);return i.reply({embeds:[embed('Active giveaways',list.length?list.map(g=>`\`${g.id}\` • ${g.prize} • ${g.entries.length} entries${g.paused?' • paused':''}`).join('\n'):'None')],ephemeral:true})}const gid=i.options.getString('id'),g=all[gid];if(!g)throw new Error('Giveaway not found');if(s==='end'){await i.deferReply({ephemeral:true});const w=await finishGiveaway(gid);return i.editReply(`Ended. Winners: ${w.map(x=>`<@${x}>`).join(', ')||'none'}`)}if(s==='reroll'){await i.deferReply({ephemeral:true});const w=await finishGiveaway(gid,true);return i.editReply(`Rerolled: ${w.map(x=>`<@${x}>`).join(', ')||'none'}`)}if(s==='pause'){g.remainingMs=Math.max(0,g.endsAt-Date.now());g.paused=true;store.write('giveaways',all);return i.reply({content:'Paused.',ephemeral:true})}if(s==='resume'){g.endsAt=Date.now()+(g.remainingMs||60000);g.paused=false;store.write('giveaways',all);return i.reply({content:'Resumed.',ephemeral:true})}}
if(c==='sticky'){const s=i.options.getSubcommand();if(s==='set')store.mutate('sticky',x=>{x[i.channel.id]={message:i.options.getString('message'),lastMessageId:null}});else store.mutate('sticky',x=>{delete x[i.channel.id]});return i.reply({content:`Sticky ${s==='set'?'set':'removed'}.`,ephemeral:true})}
if(c==='suggest'){const cfg=store.guildConfig(i.guild.id),ch=cfg.suggestionChannelId&&i.guild.channels.cache.get(cfg.suggestionChannelId);if(!ch?.isTextBased())throw new Error('Suggestion channel is not configured');const sid=id();const m=await ch.send({embeds:[embed(`💡 Suggestion ${sid}`,`${i.options.getString('suggestion')}\n\nSubmitted by ${i.user}`)]});await m.react('👍');await m.react('👎');store.mutate('suggestions',x=>{x[sid]={guildId:i.guild.id,messageId:m.id,channelId:ch.id,userId:i.user.id,text:i.options.getString('suggestion')}});return i.reply({content:'Suggestion submitted.',ephemeral:true})}
if(c==='backup'){const s=i.options.getSubcommand();if(s==='create'){const snapshot={id:id(),guildId:i.guild.id,name:i.guild.name,createdAt:Date.now(),roles:i.guild.roles.cache.filter(r=>r.id!==i.guild.id).map(r=>({name:r.name,color:r.color,permissions:r.permissions.bitfield.toString(),position:r.position,hoist:r.hoist,mentionable:r.mentionable})),channels:i.guild.channels.cache.map(ch=>({name:ch.name,type:ch.type,parentId:ch.parentId,position:ch.position,topic:ch.topic||null,nsfw:ch.nsfw||false})),config:store.guildConfig(i.guild.id)};const file=path.join(__dirname,'..','backups',`${snapshot.id}.json`);fs.writeFileSync(file,JSON.stringify(snapshot,null,2));store.mutate('backups',x=>{x.push({id:snapshot.id,guildId:i.guild.id,createdAt:snapshot.createdAt,file})});return i.reply({content:`Backup created: \`${snapshot.id}\``,files:[file],ephemeral:true})}const list=store.read('backups').filter(x=>x.guildId===i.guild.id);return i.reply({embeds:[embed('Backups',list.length?list.map(x=>`\`${x.id}\` • <t:${Math.floor(x.createdAt/1000)}:F>`).join('\n'):'None')],ephemeral:true})}}
module.exports={startBot,finishGiveaway,closeTicket};
