const fs = require('fs');
const path = require('path');
const DATA_DIR = path.join(__dirname, '..', 'data');
fs.mkdirSync(DATA_DIR,{recursive:true});
const DEFAULTS={
 config:{},warnings:{},punishments:[],tickets:{},giveaways:{},sticky:{},tempVoice:{},suggestions:{},backups:[],
 levels:{},economy:{},inventory:{},shop:{},automod:{},analytics:{},audit:[],ticketRatings:[],metrics:[],studioDrafts:{},studioTemplates:{},studioMessages:{},studioComponents:{},musicHistory:{},dashboardPrefs:{}
};
function fileFor(n){return path.join(DATA_DIR,`${n}.json`)}
function clone(v){return JSON.parse(JSON.stringify(v))}
function read(n){const f=fileFor(n),fallback=DEFAULTS[n]??{};try{if(!fs.existsSync(f))fs.writeFileSync(f,JSON.stringify(fallback,null,2));return JSON.parse(fs.readFileSync(f,'utf8'))}catch(e){console.error(`Store read error ${n}:`,e);return clone(fallback)}}
function write(n,v){const f=fileFor(n),tmp=`${f}.tmp`;fs.writeFileSync(tmp,JSON.stringify(v,null,2));fs.renameSync(tmp,f)}
function mutate(n,fn){const v=read(n);const result=fn(v)??v;write(n,result);return result}
function guildConfig(gid){const all=read('config');if(!all[gid]){all[gid]={
 welcomeChannelId:null,welcomeMessage:'Welcome {member} to **{server}**! You are member #{count}.',autoroleId:null,logChannelId:null,
 ticketCategoryId:null,ticketLogChannelId:null,ticketSupportRoleId:null,ticketAutoCloseHours:72,ticketCategories:['Support','Appeal','Bug','Purchase'],
 tempVoiceLobbyId:null,tempVoiceCategoryId:null,suggestionChannelId:null,warnTimeoutThreshold:3,warnTimeoutMinutes:60,
 levelsEnabled:true,levelChannelId:null,xpMin:8,xpMax:15,xpCooldownSeconds:60,dailyXpLimit:500,voiceXpPerMinute:3,
 economyEnabled:true,dailyAmount:250,workMin:50,workMax:180,crimeMin:40,crimeMax:350,crimeFailChance:35,
 automodEnabled:true,antiLinks:true,antiInvites:true,antiCaps:true,antiMentions:true,antiSpam:true,antiZalgo:true,antiRaid:true,antiNuke:true,
 maxCapsPercent:75,maxMentions:5,spamMessages:6,spamWindowSeconds:8,raidJoins:8,raidWindowSeconds:15,timeoutMinutes:10,
 automodWhitelistRoleIds:[],automodWhitelistChannelIds:[],giveawayAutoReroll:false
};write('config',all)}return all[gid]}
function setGuildConfig(gid,patch){return mutate('config',all=>{all[gid]={...guildConfig(gid),...patch}})}
function audit(gid,action,actorId=null,targetId=null,details=''){mutate('audit',rows=>{rows.unshift({id:Date.now().toString(36)+Math.random().toString(36).slice(2,7),guildId:gid,action,actorId,targetId,details,createdAt:Date.now()});if(rows.length>5000)rows.length=5000})}
module.exports={read,write,mutate,guildConfig,setGuildConfig,audit,DATA_DIR};
