const os = require('node:os');
const store = require('./store');
let lastCpu = os.cpus();
function cpuPercent(){
  const now=os.cpus(); let idle=0,total=0,oldIdle=0,oldTotal=0;
  now.forEach((c,i)=>{const t=Object.values(c.times).reduce((a,b)=>a+b,0); idle+=c.times.idle; total+=t; const o=lastCpu[i]||c; oldIdle+=o.times.idle; oldTotal+=Object.values(o.times).reduce((a,b)=>a+b,0)});
  lastCpu=now; const dt=total-oldTotal, di=idle-oldIdle; return dt>0?Math.max(0,Math.min(100,Math.round((1-di/dt)*1000)/10)):0;
}
async function minecraft(){
  const host=process.env.MINECRAFT_HOST; if(!host)return null;
  try{const mc=require('minecraft-server-util'); const r=await mc.status(host,Number(process.env.MINECRAFT_PORT||25565),{timeout:2500});return {online:true,players:r.players.online,maxPlayers:r.players.max,version:r.version.name,motd:r.motd.clean}}catch(e){return {online:false,error:e.message,players:0,maxPlayers:0}}
}
async function snapshot(client,guild){
  const mem=process.memoryUsage(); const mc=await minecraft();
  return {at:Date.now(),guildId:guild.id,members:guild.memberCount,onlineMembers:guild.members.cache.filter(m=>m.presence?.status&&m.presence.status!=='offline').size,channels:guild.channels.cache.size,voiceUsers:guild.voiceStates.cache.filter(v=>v.channelId).size,cpu:cpuPercent(),ramUsedMb:Math.round((os.totalmem()-os.freemem())/1048576),ramTotalMb:Math.round(os.totalmem()/1048576),processMb:Math.round(mem.rss/1048576),uptime:process.uptime(),minecraft:mc};
}
async function collect(client){for(const guild of client.guilds.cache.values()){const row=await snapshot(client,guild);store.mutate('metrics',rows=>{rows.push(row);const cutoff=Date.now()-30*86400000;while(rows.length&&rows[0].at<cutoff)rows.shift();if(rows.length>20000)rows.splice(0,rows.length-20000)})}}
module.exports={snapshot,collect,minecraft};
