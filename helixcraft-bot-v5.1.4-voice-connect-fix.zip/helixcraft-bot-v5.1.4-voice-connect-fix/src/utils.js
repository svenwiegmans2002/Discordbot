const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { guildConfig } = require('./store');

const BRAND = { color: 0x5865f2, success: 0x57f287, warning: 0xfee75c, error: 0xed4245 };
function embed(title, description, color = BRAND.color) { return new EmbedBuilder().setTitle(title).setDescription(description).setColor(color).setFooter({text:'Helixcraft Management System'}).setTimestamp(); }
function parseDuration(v) { const m=/^(\d+)(s|m|h|d)$/i.exec(String(v).trim()); if(!m) throw new Error('Use 30s, 10m, 2h or 3d.'); return Number(m[1])*({s:1e3,m:6e4,h:36e5,d:864e5}[m[2].toLowerCase()]); }
function id(bytes=4){ return crypto.randomBytes(bytes).toString('hex'); }
function htmlEscape(v=''){ return String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
async function log(client,guild,title,description,color=BRAND.color){ const cfg=guildConfig(guild.id); const ch=cfg.logChannelId && guild.channels.cache.get(cfg.logChannelId); if(ch?.isTextBased()) await ch.send({embeds:[embed(title,description,color)]}).catch(()=>{}); }
function canManageRole(guild, role){ return role && guild.members.me && role.position < guild.members.me.roles.highest.position && !role.managed; }
async function transcript(channel){ const rows=[]; let before; while(rows.length<2000){ const batch=await channel.messages.fetch({limit:100,before}); if(!batch.size)break; const list=[...batch.values()]; rows.push(...list); before=list[list.length-1].id; if(batch.size<100)break; } rows.sort((a,b)=>a.createdTimestamp-b.createdTimestamp); const body=rows.map(m=>`<article><b>${htmlEscape(m.author.tag)}</b><small>${new Date(m.createdTimestamp).toISOString()}</small><pre>${htmlEscape(m.content)}</pre></article>`).join(''); return `<!doctype html><meta charset="utf-8"><style>body{font-family:Arial;background:#101218;color:#eee;padding:24px}article{padding:12px;border-bottom:1px solid #333}small{color:#999;margin-left:10px}pre{white-space:pre-wrap}</style><h1>${htmlEscape(channel.name)}</h1>${body}`; }
module.exports={BRAND,embed,parseDuration,id,htmlEscape,log,canManageRole,transcript};
