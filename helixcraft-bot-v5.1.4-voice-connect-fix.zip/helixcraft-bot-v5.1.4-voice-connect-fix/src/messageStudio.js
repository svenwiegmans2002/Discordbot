const {
  ActionRowBuilder,
  ButtonBuilder,
  ButtonStyle,
  StringSelectMenuBuilder,
  EmbedBuilder,
} = require('discord.js');
const store = require('./store');

function normalizeUrl(value) {
  const text = String(value || '').trim();
  if (!text) return null;
  try {
    const url = new URL(text);
    return ['http:', 'https:'].includes(url.protocol) ? url.toString() : null;
  } catch {
    return null;
  }
}

function parseButtons(raw = '') {
  return String(raw)
    .split(/\r?\n/)
    .map(line => line.trim())
    .filter(Boolean)
    .slice(0, 5)
    .map(line => {
      const [label, url] = line.split('|').map(part => part?.trim());
      const validUrl = normalizeUrl(url);
      return label && validUrl ? { label: label.slice(0, 80), url: validUrl } : null;
    })
    .filter(Boolean);
}

function parseSelectOptions(raw = '') {
  return String(raw)
    .split(/\r?\n/)
    .map(line => line.trim())
    .filter(Boolean)
    .slice(0, 25)
    .map((line, index) => {
      const [label, response] = line.split('|').map(part => part?.trim());
      return label ? {
        label: label.slice(0, 100),
        value: `option-${index}`,
        response: (response || label).slice(0, 1800),
      } : null;
    })
    .filter(Boolean);
}

function buildPayload(data, componentId) {
  const payload = {
    content: String(data.content || '').trim() || undefined,
    embeds: [],
    components: [],
    allowedMentions: { parse: ['users', 'roles'], repliedUser: false },
  };

  const title = String(data.embedTitle || '').trim();
  const description = String(data.embedDescription || '').trim();
  if (title || description || data.imageUrl || data.thumbnailUrl) {
    const embed = new EmbedBuilder();
    if (title) embed.setTitle(title.slice(0, 256));
    if (description) embed.setDescription(description.slice(0, 4096));

    const rawColor = String(data.color || '5865F2').replace('#', '');
    embed.setColor(/^[0-9a-f]{6}$/i.test(rawColor) ? parseInt(rawColor, 16) : 0x5865F2);

    const image = normalizeUrl(data.imageUrl);
    const thumbnail = normalizeUrl(data.thumbnailUrl);
    if (image) embed.setImage(image);
    if (thumbnail) embed.setThumbnail(thumbnail);
    embed.setTimestamp();
    payload.embeds.push(embed);
  }

  const buttons = parseButtons(data.buttons);
  if (buttons.length) {
    payload.components.push(
      new ActionRowBuilder().addComponents(
        buttons.map(button =>
          new ButtonBuilder()
            .setLabel(button.label)
            .setURL(button.url)
            .setStyle(ButtonStyle.Link)
        )
      )
    );
  }

  const selectOptions = parseSelectOptions(data.selectOptions);
  if (selectOptions.length && componentId) {
    payload.components.push(
      new ActionRowBuilder().addComponents(
        new StringSelectMenuBuilder()
          .setCustomId(`studio-select:${componentId}`)
          .setPlaceholder(String(data.selectPlaceholder || 'Choose an option').slice(0, 150))
          .addOptions(selectOptions.map(option => ({
            label: option.label,
            value: option.value,
          })))
      )
    );
  }

  if (!payload.content && !payload.embeds.length) {
    throw new Error('Add message content or an embed.');
  }

  return { payload, selectOptions };
}

async function sendStudioMessage(client, data) {
  const guild = client.guilds.cache.get(String(data.guildId));
  if (!guild) throw new Error('Guild not found.');
  const channel = await guild.channels.fetch(String(data.channelId));
  if (!channel?.isTextBased()) throw new Error('Target channel is not a text channel.');

  const componentId = `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`;
  const { payload, selectOptions } = buildPayload(data, componentId);
  const message = await channel.send(payload);

  if (selectOptions.length) {
    store.mutate('messageComponents', all => {
      all[componentId] = {
        guildId: guild.id,
        channelId: channel.id,
        messageId: message.id,
        selectOptions,
        createdAt: Date.now(),
      };
    });
  }

  if (data.sticky) {
    store.mutate('sticky', all => {
      all[channel.id] = {
        message: String(data.content || data.embedDescription || data.embedTitle || 'Sticky message'),
        lastMessageId: message.id,
      };
    });
  }

  return message;
}

async function processScheduledMessages(client) {
  const jobs = store.read('scheduledMessages');
  let changed = false;

  for (const job of jobs) {
    if (job.status === 'pending' && job.sendAt <= Date.now()) {
      try {
        const message = await sendStudioMessage(client, job);
        job.status = 'sent';
        job.messageId = message.id;
        job.sentAt = Date.now();
      } catch (error) {
        job.status = 'failed';
        job.error = error.message;
      }
      changed = true;
    }
  }

  if (changed) store.write('scheduledMessages', jobs);
}

async function handleComponent(interaction) {
  if (!interaction.isStringSelectMenu() || !interaction.customId.startsWith('studio-select:')) {
    return false;
  }

  const componentId = interaction.customId.split(':')[1];
  const config = store.read('messageComponents')[componentId];
  if (!config) {
    await interaction.reply({ content: 'This menu is no longer configured.', ephemeral: true });
    return true;
  }

  const selected = config.selectOptions.find(option => option.value === interaction.values[0]);
  await interaction.reply({
    content: selected?.response || 'Option selected.',
    ephemeral: true,
  });
  return true;
}

module.exports = {
  buildPayload,
  sendStudioMessage,
  processScheduledMessages,
  handleComponent,
};
