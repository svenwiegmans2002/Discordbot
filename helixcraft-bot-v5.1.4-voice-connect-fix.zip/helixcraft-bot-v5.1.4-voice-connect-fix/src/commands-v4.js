const {SlashCommandBuilder,PermissionFlagsBits,ChannelType}=require('discord.js');
const C=[];const add=x=>C.push(x);
add(new SlashCommandBuilder().setName('level').setDescription('Show level and XP.').addUserOption(o=>o.setName('user').setDescription('User')));
add(new SlashCommandBuilder().setName('leaderboard').setDescription('Show XP leaderboard.'));
add(new SlashCommandBuilder().setName('balance').setDescription('Show economy balance.').addUserOption(o=>o.setName('user').setDescription('User')));
add(new SlashCommandBuilder().setName('daily').setDescription('Claim daily coins.'));
add(new SlashCommandBuilder().setName('work').setDescription('Work for coins.'));
add(new SlashCommandBuilder().setName('crime').setDescription('Risk a crime for coins.'));
add(new SlashCommandBuilder().setName('deposit').setDescription('Deposit coins.').addIntegerOption(o=>o.setName('amount').setDescription('Amount').setMinValue(1).setRequired(true)));
add(new SlashCommandBuilder().setName('withdraw').setDescription('Withdraw coins.').addIntegerOption(o=>o.setName('amount').setDescription('Amount').setMinValue(1).setRequired(true)));
add(new SlashCommandBuilder().setName('pay').setDescription('Pay another member.').addUserOption(o=>o.setName('user').setDescription('User').setRequired(true)).addIntegerOption(o=>o.setName('amount').setDescription('Amount').setMinValue(1).setRequired(true)));
add(new SlashCommandBuilder().setName('gamble').setDescription('Gamble coins.').addIntegerOption(o=>o.setName('amount').setDescription('Amount').setMinValue(1).setRequired(true)));
add(new SlashCommandBuilder().setName('shop').setDescription('View server shop.'));
add(new SlashCommandBuilder().setName('buy').setDescription('Buy shop item.').addStringOption(o=>o.setName('item').setDescription('Item ID').setRequired(true)));
add(new SlashCommandBuilder().setName('inventory').setDescription('View inventory.').addUserOption(o=>o.setName('user').setDescription('User')));
add(new SlashCommandBuilder().setName('economy-admin').setDescription('Economy administration.').setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
 .addSubcommand(s=>s.setName('add-coins').setDescription('Add coins').addUserOption(o=>o.setName('user').setDescription('User').setRequired(true)).addIntegerOption(o=>o.setName('amount').setDescription('Amount').setRequired(true)))
 .addSubcommand(s=>s.setName('add-item').setDescription('Add shop item').addStringOption(o=>o.setName('name').setDescription('Name').setRequired(true)).addIntegerOption(o=>o.setName('price').setDescription('Price').setMinValue(1).setRequired(true)).addRoleOption(o=>o.setName('role').setDescription('Optional reward role'))));
add(new SlashCommandBuilder().setName('ticket-panel-v2').setDescription('Create category ticket panel.').setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels));
add(new SlashCommandBuilder().setName('ticket-note').setDescription('Add private staff note.').setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels).addStringOption(o=>o.setName('note').setDescription('Note').setRequired(true)));
add(new SlashCommandBuilder().setName('ticket-priority').setDescription('Set ticket priority.').setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels).addStringOption(o=>o.setName('priority').setDescription('Priority').setRequired(true).addChoices({name:'Low',value:'low'},{name:'Normal',value:'normal'},{name:'High',value:'high'},{name:'Urgent',value:'urgent'})));
add(new SlashCommandBuilder().setName('automod-status').setDescription('Show AutoMod configuration.').setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild));
// Keep existing v3 commands by loading legacy list and merging is intentionally avoided; these are appended in bot.js deployment.
module.exports={v4Commands:C.map(x=>x.toJSON())};
