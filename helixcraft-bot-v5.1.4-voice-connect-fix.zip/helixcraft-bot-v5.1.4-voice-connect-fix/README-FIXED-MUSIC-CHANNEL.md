# Helixcraft Bot v5.0.3 — Fixed Music Channel

## Behaviour

- Configure one fixed music voice channel in Dashboard → Music Manager.
- `/play` always joins that configured channel.
- The user running `/play` does not need to be in a voice channel.
- Dashboard playback uses the same configured channel.
- Temporary voice creation is completely disabled.
- The bot never creates or moves itself into a temporary voice channel.

## Update

You can replace only these files in your active bot:

```bash
cp src/bot.js /root/helixcraft-bot/src/bot.js
cp src/music.js /root/helixcraft-bot/src/music.js
cp src/dashboard.js /root/helixcraft-bot/src/dashboard.js
```

Then restart the bot and open Dashboard → Music Manager to save the fixed
voice channel.
