#!/usr/bin/env bash
set -Eeuo pipefail

SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ACTIVE_DIR="/root/helixcraft-bot"

if [ ! -d "$ACTIVE_DIR" ]; then
  echo "Active bot directory not found: $ACTIVE_DIR"
  exit 1
fi

cp "$SOURCE_DIR/src/music.js" "$ACTIVE_DIR/src/music.js"
cp "$SOURCE_DIR/package.json" "$ACTIVE_DIR/package.json"

cd "$ACTIVE_DIR"
npm install --no-audit --no-fund
node --check src/music.js

if systemctl list-unit-files | grep -q '^helixcraft-bot.service'; then
  systemctl restart helixcraft-bot
  sleep 2
  systemctl --no-pager --full status helixcraft-bot || true
else
  pkill -f "/root/helixcraft-bot/index.js" 2>/dev/null || true
  echo "Patch installed. Start with: cd /root/helixcraft-bot && npm start"
fi
