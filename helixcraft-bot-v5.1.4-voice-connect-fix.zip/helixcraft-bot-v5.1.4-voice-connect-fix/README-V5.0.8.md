# Helixcraft Bot v5.0.8 — ytsearch Scheme Removed

This fixes:

```text
Unsupported url scheme: "ytsearch1" (urllib)
```

The executable code no longer creates or sends `ytsearch1:` pseudo URLs.

Instead it calls:

```text
yt-dlp --default-search ytsearch1 "plain search text"
```

The patch also strips old `ytsearch1:` values if they still exist in a queued
track and clears old persisted music queue state.

## Apply

```bash
cd /root/helixcraft-bot-v5.0.8-no-ytsearch-scheme
chmod +x apply-v5.0.8-fix.sh
./apply-v5.0.8-fix.sh
```

## Test

```text
/stop
/play query:C418 Sweden official audio
```

Then test one Spotify track before testing the full playlist.
