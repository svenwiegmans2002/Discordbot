# Helixcraft Bot v5.0.6 — No-Audio Fix

The previous music version could join Discord voice but remain silent because
the `yt-dlp stdout -> FFmpeg stdin` pipe did not reliably produce audio on the
CT.

## New playback pipeline

1. Spotify provides metadata only.
2. The bot resolves a separate playable media result.
3. `yt-dlp --get-url` returns a direct audio stream URL.
4. FFmpeg reads that URL directly with reconnect and timeout options.
5. FFmpeg converts it to 48 kHz stereo signed 16-bit PCM for Discord.
6. The bot logs the first received audio bytes.
7. Silent inputs are stopped automatically after 15 seconds.

## Apply to the active bot

```bash
cd /root/helixcraft-bot-v5.0.6-audio-fix
chmod +x apply-audio-fix.sh
./apply-audio-fix.sh
```

## Test

Set volume first:

```text
/volume percent:100
```

Then use:

```text
/play query:C418 Sweden official audio
```

And check:

```text
/nowplaying
```

Service logs:

```bash
journalctl -u helixcraft-bot -f
```

A working stream logs:

```text
[AUDIO ...] FFmpeg produced first audio bytes
```
