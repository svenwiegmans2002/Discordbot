# Helixcraft Bot v5.1.2

Fixes:

- Discord callback now redirects to `/servers`.
- Logged-in users opening `/` are redirected to `/servers`.
- The Discord access token is stored under every name used by older dashboard code.
- The guild list reads the correct session token.

Apply:

```bash
cd /root/helixcraft-bot-v5.1.2-server-redirect-fix
chmod +x apply-v5.1.2-fix.sh
./apply-v5.1.2-fix.sh
```
