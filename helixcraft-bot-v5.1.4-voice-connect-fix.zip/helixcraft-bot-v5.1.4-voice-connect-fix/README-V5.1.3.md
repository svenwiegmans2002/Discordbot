# Helixcraft Bot v5.1.3 — permissionNames Fix

Herstelt:

```text
Could not play this item: permissionNames is not defined
```

De ontbrekende helper is teruggezet vóór `connect()`.

## Toepassen

```bash
cd /root/helixcraft-bot-v5.1.3-permission-fix
chmod +x apply-v5.1.3-fix.sh
./apply-v5.1.3-fix.sh
```
