# Helixcraft Bot v5.1.1 — OAuth Loop Fix

Fixes the Discord dashboard login loop behind Nginx and Cloudflare Tunnel.

Apply:

```bash
cd /root/helixcraft-bot-v5.1.1-oauth-loop-fix
chmod +x apply-oauth-loop-fix.sh
./apply-oauth-loop-fix.sh
```

Required `.env`:

```env
DASHBOARD_URL=https://bot.helixcraft-hosting.net
DISCORD_REDIRECT_URI=https://bot.helixcraft-hosting.net/callback
SPOTIFY_REDIRECT_URI=https://bot.helixcraft-hosting.net/spotify/callback
```

After applying, clear cookies for `bot.helixcraft-hosting.net` or use an incognito window.
