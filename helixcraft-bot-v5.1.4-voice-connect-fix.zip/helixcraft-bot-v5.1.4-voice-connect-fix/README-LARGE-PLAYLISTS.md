# Helixcraft Bot v5.1.0 — Large Spotify Playlists

## What changed

- Spotify user OAuth is added to the existing dashboard.
- Private and collaborative playlists can be read after connecting Spotify.
- Playlist items are retrieved through Spotify pagination.
- Playlists with thousands of items are loaded gradually.
- The in-memory queue remains bounded instead of loading 4,000+ items at once.
- More pages are fetched automatically as the queue drains.
- Local files, podcasts and unavailable tracks are skipped without rejecting
  the entire playlist.
- Playlist progress is logged as `loaded / total / skipped`.

## Required Spotify redirect URI

Add this exact URI in Spotify Developer Dashboard:

```text
http://YOUR_CT_IP:3000/spotify/callback
```

Add the same value to `.env`:

```env
SPOTIFY_REDIRECT_URI=http://YOUR_CT_IP:3000/spotify/callback
```

The Spotify Developer app must use **Web API**.

## Apply

```bash
cd /root/helixcraft-bot-v5.1.0-large-playlists
chmod +x apply-v5.1.0.sh
./apply-v5.1.0.sh
```

Open Dashboard → Music Manager and click **Connect Spotify**. Log in using the
Spotify account that owns or can access the playlist.

Then:

```text
/stop
/play query:https://open.spotify.com/playlist/...
```

The response shows the complete playlist item count and confirms that items are
loaded gradually.
