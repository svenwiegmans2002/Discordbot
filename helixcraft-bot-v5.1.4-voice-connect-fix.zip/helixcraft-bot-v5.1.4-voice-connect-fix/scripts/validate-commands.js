const commands=require('../src/commands');
const {v4Commands}=require('../src/commands-v4');
const merged=[...commands,...v4Commands];
const seen=new Set();
const duplicates=[];
for(const command of merged){
  if(seen.has(command.name)) duplicates.push(command.name);
  seen.add(command.name);
}
if(duplicates.length){
  console.error('Duplicate slash command names:',[...new Set(duplicates)].join(', '));
  process.exit(1);
}
console.log(`Validated ${merged.length} unique slash commands.`);
