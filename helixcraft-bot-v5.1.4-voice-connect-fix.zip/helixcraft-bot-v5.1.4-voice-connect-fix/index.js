require('dotenv').config();
const { startBot } = require('./src/bot');
const { startDashboard } = require('./src/dashboard');

(async () => {
  try {
    const client = await startBot();
    await startDashboard(client);
  } catch (error) {
    console.error('Fatal startup error:', error);
    process.exit(1);
  }
})();
