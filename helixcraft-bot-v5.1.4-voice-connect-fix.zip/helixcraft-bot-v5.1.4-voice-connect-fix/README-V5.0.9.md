# Helixcraft Bot v5.0.9 — Spotify URL Detection Fix

The previous Spotify URL check accidentally transformed:

```text
open.spotify.com
```

into an invalid hostname during validation. Therefore the bot treated a
Spotify URL as a normal media URL and returned:

```text
Spotify URLs must be resolved through Spotify metadata first.
```

This patch correctly recognizes:

- Spotify tracks
- Spotify albums
- Spotify playlists
- localized Spotify URLs such as `/intl-nl/playlist/...`
- Spotify URLs containing query parameters

It also runs a parser self-test when the module loads.

## Apply

```bash
cd /root/helixcraft-bot-v5.0.9-spotify-detect-fix
chmod +x apply-v5.0.9-fix.sh
./apply-v5.0.9-fix.sh
```
