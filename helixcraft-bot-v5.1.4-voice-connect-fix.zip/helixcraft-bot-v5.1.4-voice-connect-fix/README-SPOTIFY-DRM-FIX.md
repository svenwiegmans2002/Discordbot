# Helixcraft Bot v5.0.5 — Spotify DRM Fix

This version keeps the complete v5.0.4 project and changes only Spotify/media
playback behavior.

## Fixed

- Spotify links are never sent directly to `yt-dlp`.
- Spotify remains metadata-only.
- Every Spotify track is converted to:
  `artist + title + official audio`
  and then resolved to a separate playable source.
- A final safety guard blocks Spotify URLs before playback.
- DRM errors now produce a clear user-facing message.
- Tracks without a usable alternative source are skipped with a readable error.

## Update only the music file

```bash
cp /root/helixcraft-bot-v5.0.5-spotify-drm-fix/src/music.js \
/root/helixcraft-bot/src/music.js

systemctl restart helixcraft-bot
```

## Test

```text
/play query:https://open.spotify.com/track/...
```

Then test a playlist:

```text
/play query:https://open.spotify.com/playlist/...
```
