# Helixcraft Bot v5.1.4 — Fixed Music Channel Voice Connection

Herstelt:

```text
Could not play this item: createVoiceConnection is not defined
```

## Gedrag

- `/play` gebruikt uitsluitend het voicekanaal dat in
  Dashboard → Music Manager is ingesteld.
- De bot maakt zelf geen voicekanaal aan.
- Temporary voice creation blijft volledig uitgeschakeld.
- De bot probeert maximaal drie keer automatisch te verbinden.
- Bij een probleem verschijnt uitgebreide diagnostiek in de servicelogs.

## Patch toepassen

```bash
cd /root/helixcraft-bot-v5.1.4-voice-connect-fix
chmod +x apply-v5.1.4-fix.sh
./apply-v5.1.4-fix.sh
```

Start niet vanuit de patchmap met `npm start`. Het script werkt de actieve map
`/root/helixcraft-bot` bij.
