# Helixcraft Bot v4.0.1

Fixed release: unique slash commands, command validation, and correct v4 module initialization.

# Helixcraft Bot v4

Upgrade van v3.1 met:

- Advanced AutoMod: links, invites, spam, caps, mentions, Zalgo, raid alerts en automatische timeout
- Tickets 2.0: categorieknoppen, modalformulier, prioriteit en staff notes
- Levels: message XP, voice XP, daily XP limit en leaderboard
- Economy: wallet, bank, daily, work, crime, pay, gamble, shop en inventory
- Giveaways Pro blijft aanwezig uit v3.1: role requirements, bonus entries, account/member age, pause/resume/reroll
- Dashboard: aparte AutoMod-, Levels-, Economy- en Auditpagina’s met losse save-acties

## Upgrade

```bash
cd /root
cp -a helixcraft-bot helixcraft-bot-backup-v4
unzip -o helixcraft-bot-v4.zip
cp /root/helixcraft-bot/.env /root/helixcraft-bot-v4/.env
cp -a /root/helixcraft-bot/data/. /root/helixcraft-bot-v4/data/
cd /root/helixcraft-bot-v4
npm install
npm run check
npm start
```

Test eerst v4 voordat je de oude map verwijdert.

## Nieuwe commands

`/level`, `/leaderboard`, `/balance`, `/daily`, `/work`, `/crime`, `/deposit`, `/withdraw`, `/pay`, `/gamble`, `/shop`, `/buy`, `/inventory`, `/economy-admin`, `/ticket-panel-v2`, `/ticket-note`, `/ticket-priority`, `/automod-status`.

## Opmerking over AI-spamdetectie

Deze versie gebruikt lokale heuristieken voor spamdetectie. Echte externe AI-classificatie is bewust niet standaard ingeschakeld, zodat berichten niet naar een externe dienst worden gestuurd en de bot zonder extra API-kosten werkt.


## v4.0.1 fixes

- Removed duplicate `/ping` and `/help` definitions from the v4 command extension.
- Added `npm run validate-commands` to detect duplicates before startup.
- `npm run check` now validates JavaScript syntax and slash-command uniqueness.
- Enabled the v4 event/interaction module during bot initialization.
- A Discord command deployment error is logged without immediately killing the connected bot.


## v4.0.2 — multiline bot messages

`/say` supports up to five paragraphs. Every supplied line field is separated by
one blank line.

Example:

```text
/say message:Hallo line2:Dit is een test
```

Result:

```text
Hallo

Dit is een test
```

You can also type literal `\n` inside a field:

```text
Hallo\n\nDit is een test
```

The `/embed` description converts literal `\n` into line breaks as well.


## v4.0.3 — simple multiline `/say`

Run:

```text
/say
```

Optionally choose a channel. A large Discord modal text box opens. Type or paste
the message exactly as it should appear, including blank lines:

```text
Hallo

Dit is een test
```

Press **Send** and the bot posts the message exactly as entered. No `line2`,
`line3`, or literal `\n` fields are needed.


# v4.1.0 — Message Studio and Music Manager

## CT packages for music

Install these once:

```bash
apt update
apt install -y ffmpeg python3-pip
python3 -m pip install -U yt-dlp --break-system-packages
```

Verify:

```bash
ffmpeg -version
yt-dlp --version
```

## Music commands

```text
/play query:<URL or search>
/pause
/resume
/skip
/stop
/queue
/nowplaying
/volume percent:<0-200>
```

The member running `/play` must be connected to a voice channel. The bot needs
Connect and Speak permissions.

## Dashboard Music Manager

Open:

```text
http://CT-IP:3000/g/SERVER-ID/music
```

Select a voice channel, enter a query or URL, and manage pause/resume/skip/stop,
volume and the live queue.

## Dashboard Message Studio

Message Studio supports:

- normal multiline message text;
- embed title, description and color;
- image and thumbnail URLs;
- up to five link buttons using `Label|URL`;
- dropdown options using `Label|Private response`;
- scheduled publishing;
- sticky publishing;
- live Discord-style preview;
- scheduled-message status history.

Scheduled messages are stored in `data/scheduledMessages.json`. Persistent
dropdown responses are stored in `data/messageComponents.json`.


See `README-V5.md` for v5 features and setup.
