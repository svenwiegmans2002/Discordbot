# Helixcraft Bot v5.0.7 — ytsearch Fix

Fixed:

```text
Unsupported url scheme: "ytsearch1"
```

`ytsearch1:` is now resolved to a real webpage URL first. Only then does the
bot request a direct audio stream URL and pass it to FFmpeg.

## Apply

```bash
cd /root/helixcraft-bot-v5.0.7-search-fix
chmod +x apply-search-fix.sh
./apply-search-fix.sh
```

## Test

```text
/stop
/play query:C418 Sweden official audio
```

Then test a Spotify track and playlist.
