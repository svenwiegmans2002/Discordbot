#!/usr/bin/env bash
set -Eeuo pipefail

SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ACTIVE_DIR="/root/helixcraft-bot"
BACKUP="/root/dashboard.js.backup-$(date +%Y%m%d-%H%M%S)"

cp "$ACTIVE_DIR/src/dashboard.js" "$BACKUP"
cp "$SOURCE_DIR/src/dashboard.js" "$ACTIVE_DIR/src/dashboard.js"

cd "$ACTIVE_DIR"
node --check src/dashboard.js

if systemctl list-unit-files | grep -q '^helixcraft-bot.service'; then
  systemctl restart helixcraft-bot
  sleep 3
  systemctl --no-pager --full status helixcraft-bot || true
else
  pkill -f "/root/helixcraft-bot/index.js" 2>/dev/null || true
  echo "Patch applied. Start with: cd /root/helixcraft-bot && npm start"
fi

echo
echo "Server redirect fix applied."
echo "Backup: $BACKUP"
echo "Open the dashboard in an incognito window or clear its cookies once."
