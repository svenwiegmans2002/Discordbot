# Helixcraft Bot v5.0.1 — Spotify / Music Fix

This build is based on the existing full **v5.0.0** project. No dashboard,
moderation, ticket, economy, Message Studio, analytics or other features were
removed.

## Fixed

- `/play` is now properly awaited.
- Discord receives an immediate deferred response for slow Spotify playlists.
- Failures are returned with `editReply()` instead of causing
  “The application did not respond”.
- Spotify tracks, albums and playlists are supported.
- Spotify playlist pagination is supported.
- Both `item` and legacy `track` playlist response shapes are supported.
- Invalid, private, inaccessible and empty playlists show useful errors.
- Spotify access tokens refresh automatically after expiry or a 401 response.
- Up to 300 playlist tracks are queued.
- Spotify tracks are resolved to playable media only when playback begins.
- `yt-dlp` and FFmpeg timeouts/errors are handled more clearly.
- Voice connection errors explain which permissions to check.
- The generated archive contains no `package-lock.json` tied to an internal
  package registry.

## Installation

```bash
cd /root
unzip -o helixcraft-bot-v5.0.1-music-fix.zip
cp /root/helixcraft-bot/.env /root/helixcraft-bot-v5.0.1-music-fix/.env
cp -a /root/helixcraft-bot/data/. /root/helixcraft-bot-v5.0.1-music-fix/data/

cd /root/helixcraft-bot-v5.0.1-music-fix
rm -rf node_modules package-lock.json
npm config set registry https://registry.npmjs.org/
npm install
npm run check
npm start
```

## System dependencies

```bash
apt update
apt install -y ffmpeg yt-dlp
```

If your distro's `yt-dlp` is too old:

```bash
python3 -m pip install -U yt-dlp --break-system-packages
```

## Required `.env` values

```env
SPOTIFY_CLIENT_ID=your_client_id
SPOTIFY_CLIENT_SECRET=your_client_secret
```

## Test

Join a Discord voice channel and run:

```text
/play query:https://open.spotify.com/playlist/...
```

A large playlist can take several seconds to read. Discord will show that the
bot is working and then confirm how many tracks were queued.

## Discord permissions

The bot needs:

- View Channel
- Connect
- Speak
- Send Messages
- Use Application Commands
