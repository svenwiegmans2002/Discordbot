# Helixcraft Bot v5.0.2 — Voice Fix

## Fixed

The temporary voice handler previously reacted to the music bot joining a
join-to-create lobby. It created a new room for the bot and moved it, which
destroyed the music voice connection and produced:

```text
Could not connect to the voice channel. Check the bot Connect and Speak permissions.
```

Bots are now excluded from temporary-room creation. Empty-room cleanup also
ignores bot members.

## Update only the fixed file

You may copy only this file into the active installation:

```bash
cp /root/helixcraft-bot-v5.0.2-voice-fix/src/bot.js /root/helixcraft-bot/src/bot.js
```

Then restart the bot.
