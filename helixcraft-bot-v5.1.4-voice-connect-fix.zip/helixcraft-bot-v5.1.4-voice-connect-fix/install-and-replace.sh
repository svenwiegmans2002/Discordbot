#!/usr/bin/env bash
set -Eeuo pipefail

SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ACTIVE_DIR="/root/helixcraft-bot"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP_DIR="/root/helixcraft-bot-backup-${STAMP}"

echo "[1/8] Checking Node.js..."
NODE_MAJOR="$(node -p "process.versions.node.split('.')[0]" 2>/dev/null || echo 0)"
if [ "$NODE_MAJOR" -lt 22 ]; then
  echo "Node.js 22 or newer is required."
  exit 1
fi

echo "[2/8] Installing CT audio packages..."
apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y ffmpeg yt-dlp ca-certificates curl

echo "[3/8] Preserving current configuration and data..."
if [ -d "$ACTIVE_DIR" ]; then
  cp -a "$ACTIVE_DIR" "$BACKUP_DIR"
  [ -f "$ACTIVE_DIR/.env" ] && cp "$ACTIVE_DIR/.env" "$SOURCE_DIR/.env"
  if [ -d "$ACTIVE_DIR/data" ]; then
    mkdir -p "$SOURCE_DIR/data"
    cp -a "$ACTIVE_DIR/data/." "$SOURCE_DIR/data/"
  fi
fi

echo "[4/8] Configuring npm public registry..."
npm config delete proxy || true
npm config delete https-proxy || true
npm config set registry https://registry.npmjs.org/
rm -rf "$SOURCE_DIR/node_modules" "$SOURCE_DIR/package-lock.json"

echo "[5/8] Installing npm packages with retries..."
cd "$SOURCE_DIR"
for attempt in 1 2 3; do
  if npm install --no-audit --no-fund; then
    break
  fi

  if [ "$attempt" -eq 3 ]; then
    echo "npm install failed after 3 attempts."
    exit 1
  fi

  echo "Retrying npm install in 5 seconds..."
  sleep 5
  npm cache clean --force || true
done

echo "[6/8] Running checks..."
npm run check
node -e "console.log(require('@discordjs/voice').generateDependencyReport())"

echo "[7/8] Replacing active installation..."
pkill -f "/root/helixcraft-bot/index.js" 2>/dev/null || true
if command -v pm2 >/dev/null 2>&1; then
  pm2 delete helixcraft-bot >/dev/null 2>&1 || true
fi
systemctl stop helixcraft-bot.service 2>/dev/null || true

rm -rf "$ACTIVE_DIR"
mv "$SOURCE_DIR" "$ACTIVE_DIR"

echo "[8/8] Installing and starting systemd service..."
cat >/etc/systemd/system/helixcraft-bot.service <<'UNIT'
[Unit]
Description=Helixcraft Discord Bot
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=/root/helixcraft-bot
ExecStart=/usr/bin/env node /root/helixcraft-bot/index.js
Restart=always
RestartSec=5
Environment=NODE_ENV=production
LimitNOFILE=65536

[Install]
WantedBy=multi-user.target
UNIT

systemctl daemon-reload
systemctl enable helixcraft-bot.service
systemctl restart helixcraft-bot.service
sleep 3
systemctl --no-pager --full status helixcraft-bot.service || true

echo
echo "Update complete."
echo "Backup: $BACKUP_DIR"
echo "Logs: journalctl -u helixcraft-bot -f"
