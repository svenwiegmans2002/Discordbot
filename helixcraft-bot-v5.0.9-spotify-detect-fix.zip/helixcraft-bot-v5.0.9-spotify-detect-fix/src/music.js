const { spawn } = require('node:child_process');
const {
  joinVoiceChannel,
  createAudioPlayer,
  createAudioResource,
  AudioPlayerStatus,
  VoiceConnectionStatus,
  entersState,
  StreamType,
  NoSubscriberBehavior,
  getVoiceConnection,
  generateDependencyReport,
} = require('@discordjs/voice');
const store = require('./store');

const states = new Map();
let spotifyToken = null;
let spotifyExpiresAt = 0;

function stateFor(guildId) {
  if (states.has(guildId)) return states.get(guildId);

  const player = createAudioPlayer({
    behaviors: { noSubscriber: NoSubscriberBehavior.Pause },
  });

  const state = {
    guildId,
    player,
    connection: null,
    queue: [],
    current: null,
    volume: 0.5,
    process: null,
    textChannelId: null,
    voiceChannelId: null,
    loop: 'off',
    autoplay: false,
    shuffle: false,
    equalizer: 'flat',
    startedAt: null,
    pausedAt: null,
    pausedTotal: 0,
    manuallyStopped: false,
    connectionAttempt: 0,
    connectionLog: [],
  };

  player.on(AudioPlayerStatus.Idle, async () => {
    cleanupProcesses(state);

    const finished = state.current;
    state.current = null;

    if (state.manuallyStopped) {
      state.manuallyStopped = false;
      return;
    }

    if (finished) {
      store.mutate('musicHistory', all => {
        (all[guildId] ??= []).unshift({ ...finished, playedAt: Date.now() });
        all[guildId] = all[guildId].slice(0, 100);
      });

      if (state.loop === 'track') {
        state.queue.unshift(finished);
      } else if (state.loop === 'queue') {
        state.queue.push(finished);
      } else if (state.autoplay && state.queue.length === 0) {
        state.queue.push({
          ...finished,
          id: `auto-${Date.now()}`,
          query: `${finished.artist || ''} ${finished.title} similar official audio`,
          title: `Autoplay after ${finished.title}`,
          source: 'autoplay',
        });
      }
    }

    try {
      await playNext(state);
    } catch (error) {
      console.error('Music next-track error:', error);
      await notifyMusicError(state, error);
    }
  });

  player.on('error', async error => {
    console.error('Music player error:', error);
    cleanupProcesses(state);
    state.current = null;
    await notifyMusicError(state, error);

    try {
      await playNext(state);
    } catch (nextError) {
      console.error('Music recovery error:', nextError);
    }
  });

  states.set(guildId, state);
  return state;
}

function cleanupProcesses(state) {
  const processes = Array.isArray(state.process) ? state.process : state.process ? [state.process] : [];

  for (const process of processes) {
    try {
      if (process && !process.killed) process.kill('SIGKILL');
    } catch {}
  }

  state.process = null;
}

async function notifyMusicError(state, error) {
  if (!state.textChannelId || !global.__helixClient) return;

  const channel = await global.__helixClient.channels
    .fetch(state.textChannelId)
    .catch(() => null);

  if (channel?.isTextBased()) {
    await channel
      .send(`❌ Music error: ${String(error.message || error).slice(0, 1500)}`)
      .catch(() => {});
  }
}

function hasBinary(binary) {
  return new Promise(resolve => {
    const process = spawn('sh', ['-lc', `command -v ${binary}`]);
    process.once('close', code => resolve(code === 0));
    process.once('error', () => resolve(false));
  });
}

async function dependencyStatus() {
  const [ytdlp, ffmpeg] = await Promise.all([
    hasBinary('yt-dlp'),
    hasBinary('ffmpeg'),
  ]);

  return { ytdlp, ffmpeg };
}

function runJsonCommand(binary, args, timeoutMs = 45_000) {
  return new Promise((resolve, reject) => {
    const process = spawn(binary, args, {
      stdio: ['ignore', 'pipe', 'pipe'],
    });

    let stdout = '';
    let stderr = '';
    let finished = false;

    const timeout = setTimeout(() => {
      if (finished) return;
      finished = true;
      process.kill('SIGKILL');
      reject(new Error(`${binary} timed out after ${Math.round(timeoutMs / 1000)} seconds.`));
    }, timeoutMs);

    process.stdout.on('data', chunk => {
      stdout += chunk.toString();
    });

    process.stderr.on('data', chunk => {
      stderr += chunk.toString();
    });

    process.once('error', error => {
      if (finished) return;
      finished = true;
      clearTimeout(timeout);
      reject(error);
    });

    process.once('close', code => {
      if (finished) return;
      finished = true;
      clearTimeout(timeout);

      if (code !== 0) {
        return reject(
          new Error(
            stderr.trim() ||
              `${binary} exited with code ${code}.`
          )
        );
      }

      try {
        resolve(JSON.parse(stdout));
      } catch {
        reject(new Error(`Invalid JSON returned by ${binary}.`));
      }
    });
  });
}


async function resolveMediaTrack(query) {
  const normalized = String(query || '').trim();
  if (!normalized) throw new Error('Enter a URL or search query.');

  const isHttpUrl = /^https?:\/\//i.test(normalized);
  const isSpotifyUrl = /(?:open\.)?spotify\.com\//i.test(normalized);

  if (isSpotifyUrl) {
    throw new Error('Spotify URLs must be resolved through Spotify metadata first.');
  }

  const args = [
    '--no-playlist',
    '--dump-single-json',
    '--skip-download',
  ];

  if (!isHttpUrl) {
    // Important: pass the search as plain text. Do not construct a ytsearch1:
    // pseudo URL because some yt-dlp builds route it through urllib.
    args.push('--default-search', 'ytsearch1');
  }

  args.push(normalized);

  const json = await runJsonCommand('yt-dlp', args, 60_000);
  const track = Array.isArray(json.entries) ? json.entries[0] : json;

  if (!track) throw new Error('No playable result was found.');

  const webpageUrl =
    track.webpage_url ||
    track.original_url ||
    (typeof track.url === 'string' && /^https?:\/\//i.test(track.url) ? track.url : null);

  if (!webpageUrl || !/^https?:\/\//i.test(webpageUrl)) {
    throw new Error('Search result did not contain a valid media webpage URL.');
  }

  return {
    title: track.title || normalized,
    url: webpageUrl,
    query: webpageUrl,
    duration: Number(track.duration || 0),
    durationText: track.duration_string || 'unknown',
    thumbnail: track.thumbnail || null,
    artist: track.artist || track.uploader || '',
    source: 'media',
  };
}

function parseSpotifyUrl(input) {
  const value = String(input || '').trim();

  if (!value) return null;

  try {
    const url = new URL(value);
    const hostname = url.hostname.toLowerCase();

    if (
      hostname !== 'open.spotify.com' &&
      hostname !== 'spotify.com' &&
      !hostname.endsWith('.spotify.com')
    ) {
      return null;
    }

    const parts = url.pathname
      .split('/')
      .filter(Boolean)
      .filter(part => !part.toLowerCase().startsWith('intl-'));

    const typeIndex = parts.findIndex(part =>
      ['track', 'album', 'playlist'].includes(part.toLowerCase())
    );

    if (typeIndex === -1 || !parts[typeIndex + 1]) return null;

    const type = parts[typeIndex].toLowerCase();
    const id = parts[typeIndex + 1].split('?')[0].trim();

    if (!/^[A-Za-z0-9]+$/.test(id)) return null;

    return { type, id };
  } catch {
    const match = value.match(
      /(?:https?:\/\/)?(?:open\.)?spotify\.com\/(?:intl-[a-z-]+\/)?(track|album|playlist)\/([A-Za-z0-9]+)/i
    );

    return match
      ? { type: match[1].toLowerCase(), id: match[2] }
      : null;
  }
}

async function spotifyAuth(force = false) {
  if (!force && spotifyToken && Date.now() < spotifyExpiresAt) {
    return spotifyToken;
  }

  const clientId = process.env.SPOTIFY_CLIENT_ID;
  const clientSecret = process.env.SPOTIFY_CLIENT_SECRET;

  if (!clientId || !clientSecret) {
    throw new Error(
      'Spotify is not configured. Add SPOTIFY_CLIENT_ID and SPOTIFY_CLIENT_SECRET to .env.'
    );
  }

  const authorization = Buffer.from(`${clientId}:${clientSecret}`).toString('base64');

  const response = await fetch('https://accounts.spotify.com/api/token', {
    method: 'POST',
    headers: {
      Authorization: `Basic ${authorization}`,
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: new URLSearchParams({ grant_type: 'client_credentials' }),
    signal: AbortSignal.timeout(20_000),
  });

  if (!response.ok) {
    const details = await response.text().catch(() => '');
    throw new Error(
      `Spotify authentication failed (${response.status}). ${details.slice(0, 300)}`
    );
  }

  const payload = await response.json();
  spotifyToken = payload.access_token;
  spotifyExpiresAt = Date.now() + Math.max(60, payload.expires_in - 60) * 1000;

  return spotifyToken;
}

async function spotifyRequest(url, retry = true) {
  const token = await spotifyAuth();

  const response = await fetch(url, {
    headers: { Authorization: `Bearer ${token}` },
    signal: AbortSignal.timeout(25_000),
  });

  if (response.status === 401 && retry) {
    spotifyToken = null;
    spotifyExpiresAt = 0;
    await spotifyAuth(true);
    return spotifyRequest(url, false);
  }

  if (!response.ok) {
    const details = await response.text().catch(() => '');

    if (response.status === 403) {
      throw new Error(
        'Spotify denied access to this playlist. Make sure the playlist is accessible to the Spotify app/user and that Web API is enabled.'
      );
    }

    if (response.status === 404) {
      throw new Error(
        'Spotify item not found. Check whether the link is valid and the playlist is public or accessible.'
      );
    }

    if (response.status === 429) {
      const retryAfter = response.headers.get('retry-after') || '?';
      throw new Error(`Spotify rate limit reached. Retry after ${retryAfter} seconds.`);
    }

    throw new Error(
      `Spotify API error ${response.status}. ${details.slice(0, 300)}`
    );
  }

  return response.json();
}

function spotifyTrackToQueueItem(track) {
  if (!track || !track.name) return null;

  const artists = Array.isArray(track.artists)
    ? track.artists.map(artist => artist.name).filter(Boolean)
    : [];

  const artistText = artists.join(', ');
  const image =
    track.album?.images?.[0]?.url ||
    track.images?.[0]?.url ||
    null;

  return {
    query: `${artistText} ${track.name} official audio`,
    title: track.name,
    artist: artistText,
    duration: Math.round(Number(track.duration_ms || 0) / 1000),
    durationText: track.duration_ms
      ? `${Math.floor(track.duration_ms / 60000)}:${String(
          Math.floor((track.duration_ms % 60000) / 1000)
        ).padStart(2, '0')}`
      : 'Spotify',
    thumbnail: image,
    spotifyUrl: track.external_urls?.spotify || null,
    source: 'spotify',
  };
}

async function fetchSpotifyPages(initialUrl, maxTracks = 300) {
  const results = [];
  let url = initialUrl;

  while (url && results.length < maxTracks) {
    const page = await spotifyRequest(url);
    const entries = Array.isArray(page.items) ? page.items : [];

    for (const entry of entries) {
      const track = entry?.item || entry?.track || entry;
      const converted = spotifyTrackToQueueItem(track);

      if (converted) {
        results.push(converted);
        if (results.length >= maxTracks) break;
      }
    }

    url = page.next || null;
  }

  return results;
}

async function spotifyTracks(input) {
  const parsed = parseSpotifyUrl(input);
  if (!parsed) return null;

  if (parsed.type === 'track') {
    const track = await spotifyRequest(
      `https://api.spotify.com/v1/tracks/${parsed.id}`
    );
    const converted = spotifyTrackToQueueItem(track);
    return converted ? [converted] : [];
  }

  if (parsed.type === 'album') {
    const album = await spotifyRequest(
      `https://api.spotify.com/v1/albums/${parsed.id}`
    );

    const albumImage = album.images?.[0]?.url || null;
    const tracks = [];
    let page = album.tracks;

    while (page && tracks.length < 300) {
      for (const track of page.items || []) {
        const converted = spotifyTrackToQueueItem({
          ...track,
          album: {
            images: album.images || [],
          },
        });

        if (converted) {
          converted.thumbnail = converted.thumbnail || albumImage;
          tracks.push(converted);
        }
      }

      page = page.next ? await spotifyRequest(page.next) : null;
    }

    return tracks;
  }

  const playlist = await spotifyRequest(
    `https://api.spotify.com/v1/playlists/${parsed.id}?fields=name,tracks(items(item(name,duration_ms,artists(name),album(images),external_urls),track(name,duration_ms,artists(name),album(images),external_urls)),next)`
  );

  const firstPage = playlist.tracks || { items: [], next: null };
  const tracks = [];

  for (const entry of firstPage.items || []) {
    const track = entry?.item || entry?.track || entry;
    const converted = spotifyTrackToQueueItem(track);
    if (converted) tracks.push(converted);
  }

  let nextUrl = firstPage.next || null;

  while (nextUrl && tracks.length < 300) {
    const pageTracks = await fetchSpotifyPages(nextUrl, 300 - tracks.length);
    tracks.push(...pageTracks);
    nextUrl = null;
  }

  if (!tracks.length) {
    throw new Error(
      'No playable tracks were found in this Spotify playlist. Local files, podcasts and unavailable tracks are skipped.'
    );
  }

  return tracks;
}


function permissionNames(channel, member) {
  const permissions = channel.permissionsFor(member);
  return permissions ? permissions.toArray() : [];
}

function connectionSnapshot(connection) {
  const state = connection?.state || {};
  return {
    status: state.status || 'unknown',
    reason: state.reason || null,
    closeCode: state.closeCode || null,
  };
}

async function waitForVoiceReady(connection, timeoutMs) {
  try {
    await entersState(connection, VoiceConnectionStatus.Ready, timeoutMs);
    return true;
  } catch {
    return false;
  }
}

async function createVoiceConnection(guild, voiceChannel, state, attempt) {
  const existing = getVoiceConnection(guild.id);
  if (existing) {
    try {
      existing.destroy();
    } catch {}
  }

  const connection = joinVoiceChannel({
    channelId: voiceChannel.id,
    guildId: guild.id,
    adapterCreator: guild.voiceAdapterCreator,
    selfDeaf: attempt !== 2,
    selfMute: false,
    group: `helixcraft-${guild.id}`,
  });

  state.connection = connection;
  state.voiceChannelId = voiceChannel.id;
  state.connectionAttempt = attempt;
  state.connectionLog = [];

  const record = (from, to) => {
    const entry = {
      at: new Date().toISOString(),
      from: from.status,
      to: to.status,
      reason: to.reason || null,
      closeCode: to.closeCode || null,
    };

    state.connectionLog.push(entry);
    state.connectionLog = state.connectionLog.slice(-25);
    console.log(
      `[VOICE ${guild.id}] attempt=${attempt} ${entry.from} -> ${entry.to}`,
      entry.reason || '',
      entry.closeCode || ''
    );
  };

  connection.on('stateChange', record);
  connection.on('error', error => {
    console.error(`[VOICE ${guild.id}] connection error`, error);
  });

  connection.subscribe(state.player);
  return connection;
}

async function connect(guild, voiceChannel) {
  const state = stateFor(guild.id);
  const botMember = guild.members.me || await guild.members.fetchMe();

  const required = ['ViewChannel', 'Connect', 'Speak'];
  const available = permissionNames(voiceChannel, botMember);
  const missing = required.filter(name => !available.includes(name));

  if (missing.length) {
    throw new Error(
      `The bot is missing these permissions in ${voiceChannel.name}: ${missing.join(', ')}.`
    );
  }

  if (
    state.connection &&
    state.voiceChannelId === voiceChannel.id &&
    state.connection.state.status === VoiceConnectionStatus.Ready
  ) {
    return state;
  }

  cleanupProcesses(state);

  if (state.connection) {
    try {
      state.connection.destroy();
    } catch {}
    state.connection = null;
  }

  const attempts = [
    { number: 1, timeout: 20_000, delay: 0 },
    { number: 2, timeout: 25_000, delay: 1_500 },
    { number: 3, timeout: 30_000, delay: 3_000 },
  ];

  let lastSnapshot = null;

  for (const attempt of attempts) {
    if (attempt.delay) {
      await new Promise(resolve => setTimeout(resolve, attempt.delay));
    }

    const connection = await createVoiceConnection(
      guild,
      voiceChannel,
      state,
      attempt.number
    );

    const ready = await waitForVoiceReady(connection, attempt.timeout);

    if (ready) {
      console.log(
        `[VOICE ${guild.id}] ready in ${voiceChannel.name} on attempt ${attempt.number}`
      );
      return state;
    }

    lastSnapshot = connectionSnapshot(connection);
    console.error(
      `[VOICE ${guild.id}] attempt ${attempt.number} timed out`,
      lastSnapshot
    );

    try {
      connection.destroy();
    } catch {}

    state.connection = null;
    state.voiceChannelId = null;
  }

  const diagnostic = {
    guildId: guild.id,
    channelId: voiceChannel.id,
    channelName: voiceChannel.name,
    permissions: available,
    lastConnectionState: lastSnapshot,
    dependencyReport: generateDependencyReport(),
    attempts: state.connectionLog,
  };

  console.error('[VOICE DIAGNOSTIC]', JSON.stringify(diagnostic, null, 2));

  throw new Error(
    'Discord voice did not complete its handshake after 3 automatic attempts. ' +
    'The full diagnostic was written to the bot console.'
  );
}

async function enqueue({
  guild,
  voiceChannel,
  textChannel,
  query,
  requestedBy,
}) {
  const dependencies = await dependencyStatus();

  if (!dependencies.ytdlp || !dependencies.ffmpeg) {
    const missing = [
      !dependencies.ytdlp ? 'yt-dlp' : null,
      !dependencies.ffmpeg ? 'ffmpeg' : null,
    ].filter(Boolean);

    throw new Error(
      `Missing CT dependencies: ${missing.join(', ')}.`
    );
  }

  const state = await connect(guild, voiceChannel);
  state.textChannelId = textChannel?.id || state.textChannelId;

  const isSpotify = Boolean(parseSpotifyUrl(query));
  const tracks = isSpotify
    ? await spotifyTracks(query)
    : [await resolveMediaTrack(query)];

  if (!tracks || tracks.length === 0) {
    throw new Error('No tracks could be added.');
  }

  const added = tracks.map(raw => ({
    ...raw,
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`,
    requestedBy,
    queuedAt: Date.now(),
  }));

  state.queue.push(...added);

  if (state.shuffle && state.queue.length > 1) {
    for (let index = state.queue.length - 1; index > 0; index -= 1) {
      const randomIndex = Math.floor(Math.random() * (index + 1));
      [state.queue[index], state.queue[randomIndex]] = [
        state.queue[randomIndex],
        state.queue[index],
      ];
    }
  }

  if (
    !state.current &&
    state.player.state.status === AudioPlayerStatus.Idle
  ) {
    await playNext(state);
  }

  return {
    track: added[0],
    count: added.length,
  };
}

function ffmpegFilter(equalizer) {
  return (
    {
      bass: 'bass=g=8',
      treble: 'treble=g=6',
      vocal: 'equalizer=f=1000:t=q:w=1:g=5',
      nightcore: 'asetrate=48000*1.15,aresample=48000,atempo=1.05',
      flat: 'anull',
    }[equalizer] || 'anull'
  );
}


function runTextCommand(binary, args, timeoutMs = 45_000) {
  return new Promise((resolve, reject) => {
    const process = spawn(binary, args, {
      stdio: ['ignore', 'pipe', 'pipe'],
    });

    let stdout = '';
    let stderr = '';
    let completed = false;

    const timeout = setTimeout(() => {
      if (completed) return;
      completed = true;
      process.kill('SIGKILL');
      reject(new Error(`${binary} timed out after ${Math.round(timeoutMs / 1000)} seconds.`));
    }, timeoutMs);

    process.stdout.on('data', chunk => {
      stdout += chunk.toString();
    });

    process.stderr.on('data', chunk => {
      stderr += chunk.toString();
    });

    process.once('error', error => {
      if (completed) return;
      completed = true;
      clearTimeout(timeout);
      reject(error);
    });

    process.once('close', code => {
      if (completed) return;
      completed = true;
      clearTimeout(timeout);

      if (code !== 0) {
        return reject(
          new Error(stderr.trim() || `${binary} exited with code ${code}.`)
        );
      }

      const value = stdout
        .split(/\r?\n/)
        .map(line => line.trim())
        .find(Boolean);

      if (!value) {
        return reject(new Error(`${binary} returned no playable audio URL.`));
      }

      resolve(value);
    });
  });
}



async function resolveSearchToWebpageUrl(searchQuery) {
  let normalized = String(searchQuery || '').trim();

  if (!normalized) {
    throw new Error('Search query is empty.');
  }

  // Strip any legacy pseudo-scheme left in old persisted queue entries.
  normalized = normalized.replace(/^ytsearch\d*:/i, '').trim();

  const webpageUrl = await runTextCommand(
    'yt-dlp',
    [
      '--no-playlist',
      '--no-warnings',
      '--quiet',
      '--default-search',
      'ytsearch1',
      '--print',
      '%(webpage_url)s',
      normalized,
    ],
    60_000
  );

  if (!/^https?:\/\//i.test(webpageUrl)) {
    throw new Error(
      `Search did not resolve to a valid webpage URL: ${webpageUrl}`
    );
  }

  return webpageUrl;
}


async function resolveDirectAudioUrl(sourceQuery) {
  let resolvedSource = String(sourceQuery || '').trim();

  if (!resolvedSource) {
    throw new Error('Audio source is empty.');
  }

  if (/(?:open\.)?spotify\.com\//i.test(resolvedSource)) {
    throw new Error('Spotify URLs cannot be used as direct audio sources.');
  }

  const hadLegacySearchScheme = /^ytsearch\d*:/i.test(resolvedSource);
  if (hadLegacySearchScheme) {
    resolvedSource = resolvedSource.replace(/^ytsearch\d*:/i, '').trim();
  }

  if (hadLegacySearchScheme || !/^https?:\/\//i.test(resolvedSource)) {
    resolvedSource = await resolveSearchToWebpageUrl(resolvedSource);
  }

  const directUrl = await runTextCommand(
    'yt-dlp',
    [
      '--no-playlist',
      '--no-warnings',
      '--quiet',
      '--format',
      'bestaudio[acodec=opus]/bestaudio/best',
      '--get-url',
      resolvedSource,
    ],
    60_000
  );

  if (!/^https?:\/\//i.test(directUrl)) {
    throw new Error(
      `yt-dlp did not return a valid direct audio URL: ${directUrl}`
    );
  }

  return directUrl;
}

async function playNext(state) {
  if (!state.connection) return;

  const track = state.queue.shift();
  if (!track) return;

  state.current = track;
  state.startedAt = Date.now();
  state.pausedAt = null;
  state.pausedTotal = 0;

  let sourceQuery = track.url || track.query;

  // Spotify items are metadata only. Resolve each item to a playable source just
  // before playback, which keeps playlist queueing fast.
  if (track.source === 'spotify' || track.source === 'autoplay') {
    const searchQuery = [
      track.artist || '',
      track.title || '',
      'official audio'
    ]
      .filter(Boolean)
      .join(' ')
      .trim();

    if (!searchQuery) {
      throw new Error('Spotify track metadata is incomplete.');
    }

    const resolved = await resolveMediaTrack(searchQuery);

    if (!resolved?.url) {
      throw new Error(
        `No playable non-DRM source found for ${track.artist || 'Unknown artist'} - ${track.title || 'Unknown track'}.`
      );
    }

    // Never send Spotify URLs to yt-dlp. Spotify is metadata-only.
    sourceQuery = resolved.url;
    track.playbackUrl = resolved.url;
    track.duration = track.duration || resolved.duration;
    track.durationText = track.durationText || resolved.durationText;
    track.thumbnail = track.thumbnail || resolved.thumbnail;
  }

  if (/(?:open\.)?spotify\.com\//i.test(sourceQuery)) {
    throw new Error(
      'Spotify URLs are metadata-only and cannot be sent directly to yt-dlp.'
    );
  }

  const directAudioUrl = await resolveDirectAudioUrl(sourceQuery);

  const ffmpeg = spawn(
    'ffmpeg',
    [
      '-hide_banner',
      '-loglevel',
      'warning',
      '-nostdin',
      '-reconnect',
      '1',
      '-reconnect_streamed',
      '1',
      '-reconnect_at_eof',
      '1',
      '-reconnect_delay_max',
      '5',
      '-rw_timeout',
      '15000000',
      '-i',
      directAudioUrl,
      '-vn',
      '-af',
      ffmpegFilter(state.equalizer),
      '-acodec',
      'pcm_s16le',
      '-f',
      's16le',
      '-ar',
      '48000',
      '-ac',
      '2',
      'pipe:1',
    ],
    { stdio: ['ignore', 'pipe', 'pipe'] }
  );

  const errors = [];
  let audioBytes = 0;
  let firstAudioAt = null;

  ffmpeg.stderr.on('data', chunk => {
    const text = chunk.toString();
    errors.push(text);
    if (errors.join('').length > 6000) errors.shift();
  });

  ffmpeg.stdout.on('data', chunk => {
    audioBytes += chunk.length;
    if (!firstAudioAt) {
      firstAudioAt = Date.now();
      console.log(
        `[AUDIO ${state.guildId}] FFmpeg produced first audio bytes for "${track.title}".`
      );
    }
  });

  ffmpeg.once('error', error => {
    console.error(`[AUDIO ${state.guildId}] FFmpeg process error:`, error);
  });

  ffmpeg.once('close', code => {
    console.log(
      `[AUDIO ${state.guildId}] FFmpeg closed code=${code} bytes=${audioBytes} track="${track.title}".`
    );

    if (
      code !== 0 &&
      state.current?.id === track.id &&
      audioBytes === 0
    ) {
      console.error(
        `[AUDIO ${state.guildId}] FFmpeg produced no audio: ${errors.join('').slice(0, 3000)}`
      );
    }
  });

  state.process = [ffmpeg];

  const resource = createAudioResource(ffmpeg.stdout, {
    inputType: StreamType.Raw,
    inlineVolume: true,
    metadata: track,
  });

  resource.volume?.setVolume(Math.max(0.05, state.volume || 0.5));
  state.player.play(resource);

  // Detect silent/broken inputs early and advance to the next track instead of
  // remaining connected without sound.
  setTimeout(() => {
    if (
      state.current?.id === track.id &&
      audioBytes === 0 &&
      !ffmpeg.killed
    ) {
      console.error(
        `[AUDIO ${state.guildId}] No audio bytes after 15 seconds. ${errors.join('').slice(0, 2500)}`
      );
      try {
        ffmpeg.kill('SIGKILL');
      } catch {}
      state.player.stop(true);
    }
  }, 15_000);
}

function pause(guildId) {
  const state = stateFor(guildId);
  const paused = state.player.pause();

  if (paused) state.pausedAt = Date.now();
  return paused;
}

function resume(guildId) {
  const state = stateFor(guildId);
  const resumed = state.player.unpause();

  if (resumed && state.pausedAt) {
    state.pausedTotal += Date.now() - state.pausedAt;
    state.pausedAt = null;
  }

  return resumed;
}

function skip(guildId) {
  const state = stateFor(guildId);
  cleanupProcesses(state);
  return state.player.stop(true);
}

function stop(guildId) {
  const state = stateFor(guildId);
  state.manuallyStopped = true;
  state.queue = [];
  state.current = null;
  cleanupProcesses(state);
  state.player.stop(true);

  if (state.connection) {
    try {
      state.connection.destroy();
    } catch {}
  }

  state.connection = null;
  state.voiceChannelId = null;
}

function setVolume(guildId, percentage) {
  const state = stateFor(guildId);
  state.volume = Math.max(0, Math.min(2, Number(percentage) / 100));
  state.player.state.resource?.volume?.setVolume(state.volume);
  return Math.round(state.volume * 100);
}

function setLoop(guildId, mode) {
  if (!['off', 'track', 'queue'].includes(mode)) {
    throw new Error('Invalid loop mode.');
  }

  stateFor(guildId).loop = mode;
  return mode;
}

function toggleShuffle(guildId, value) {
  const state = stateFor(guildId);
  state.shuffle = value ?? !state.shuffle;
  return state.shuffle;
}

function toggleAutoplay(guildId, value) {
  const state = stateFor(guildId);
  state.autoplay = value ?? !state.autoplay;
  return state.autoplay;
}

function setEqualizer(guildId, preset) {
  if (!['flat', 'bass', 'treble', 'vocal', 'nightcore'].includes(preset)) {
    throw new Error('Invalid equalizer preset.');
  }

  stateFor(guildId).equalizer = preset;
  return preset;
}

function snapshot(guildId) {
  const state = stateFor(guildId);
  const end = state.pausedAt || Date.now();

  const elapsed = state.current
    ? Math.max(
        0,
        Math.floor(
          (end - state.startedAt - state.pausedTotal) / 1000
        )
      )
    : 0;

  const settings = store.read('musicSettings')[guildId] || {};

  return {
    guildId,
    configuredVoiceChannelId: settings.voiceChannelId || null,
    configuredTextChannelId: settings.textChannelId || null,
    current: state.current,
    queue: [...state.queue],
    volume: Math.round(state.volume * 100),
    status: state.player.state.status,
    voiceChannelId: state.voiceChannelId,
    textChannelId: state.textChannelId,
    loop: state.loop,
    shuffle: state.shuffle,
    autoplay: state.autoplay,
    equalizer: state.equalizer,
    elapsed,
    duration: state.current?.duration || 0,
  };
}

async function lyrics(guildId) {
  const track = stateFor(guildId).current;
  if (!track) throw new Error('Nothing is playing.');

  const query = new URLSearchParams({
    track_name: track.title,
    artist_name: track.artist || '',
  });

  const response = await fetch(
    `https://lrclib.net/api/search?${query}`,
    {
      headers: { 'User-Agent': 'HelixcraftBot/5.0.1' },
      signal: AbortSignal.timeout(15_000),
    }
  );

  if (!response.ok) throw new Error('Lyrics service unavailable.');

  const results = await response.json();
  return (
    results[0]?.plainLyrics ||
    results[0]?.syncedLyrics ||
    'No lyrics found.'
  );
}

async function handleCommand(interaction) {
  const command = interaction.commandName;
  const guildId = interaction.guildId;

  if (command === 'play') {
    const settings = store.read('musicSettings')[guildId] || {};
    const configuredVoiceChannelId = settings.voiceChannelId;

    if (!configuredVoiceChannelId) {
      return interaction.reply({
        content: 'No fixed music voice channel is configured. Set one in Dashboard → Music Manager.',
        ephemeral: true,
      });
    }

    const voiceChannel = await interaction.guild.channels
      .fetch(configuredVoiceChannelId)
      .catch(() => null);

    if (!voiceChannel || voiceChannel.type !== 2) {
      return interaction.reply({
        content: 'The configured music voice channel no longer exists. Select a new channel in the dashboard.',
        ephemeral: true,
      });
    }

    const configuredTextChannel = settings.textChannelId
      ? await interaction.guild.channels.fetch(settings.textChannelId).catch(() => null)
      : interaction.channel;

    await interaction.deferReply();

    try {
      const result = await enqueue({
        guild: interaction.guild,
        voiceChannel,
        textChannel: configuredTextChannel?.isTextBased() ? configuredTextChannel : interaction.channel,
        query: interaction.options.getString('query'),
        requestedBy: interaction.user.id,
      });

      return interaction.editReply(
        `🎵 Queued **${result.track.title}**${
          result.count > 1 ? ` and ${result.count - 1} more track(s)` : ''
        }.`
      );
    } catch (error) {
      console.error('Play command failed:', error);
      const rawMessage = String(error.message || error);
      const friendlyMessage = /DRM/i.test(rawMessage)
        ? 'The original source uses DRM. The bot tried to find a non-DRM alternative but none was available.'
        : rawMessage;

      return interaction.editReply(
        `❌ Could not play this item: ${friendlyMessage.slice(0, 1800)}`
      );
    }
  }

  if (command === 'pause') {
    return interaction.reply(
      pause(guildId) ? '⏸️ Paused.' : 'Nothing could be paused.'
    );
  }

  if (command === 'resume') {
    return interaction.reply(
      resume(guildId) ? '▶️ Resumed.' : 'Nothing could be resumed.'
    );
  }

  if (command === 'skip') {
    skip(guildId);
    return interaction.reply('⏭️ Skipped.');
  }

  if (command === 'stop') {
    stop(guildId);
    return interaction.reply('⏹️ Stopped and disconnected.');
  }

  if (command === 'volume') {
    return interaction.reply(
      `🔊 Volume: ${setVolume(
        guildId,
        interaction.options.getInteger('percent')
      )}%`
    );
  }

  if (command === 'loop') {
    return interaction.reply(
      `🔁 Loop: ${setLoop(
        guildId,
        interaction.options.getString('mode')
      )}`
    );
  }

  if (command === 'shuffle') {
    return interaction.reply(
      `🔀 Shuffle: ${toggleShuffle(guildId) ? 'on' : 'off'}`
    );
  }

  if (command === 'autoplay') {
    return interaction.reply(
      `♾️ Autoplay: ${toggleAutoplay(guildId) ? 'on' : 'off'}`
    );
  }

  if (command === 'equalizer') {
    return interaction.reply(
      `🎚️ Equalizer: ${setEqualizer(
        guildId,
        interaction.options.getString('preset')
      )}`
    );
  }

  if (command === 'lyrics') {
    const text = (await lyrics(guildId)).slice(0, 1900);
    return interaction.reply({
      content: `**Lyrics**\n${text}`,
      ephemeral: true,
    });
  }

  const state = snapshot(guildId);

  if (command === 'queue') {
    const lines = [
      state.current ? `**Now:** ${state.current.title}` : '',
      ...state.queue
        .slice(0, 20)
        .map((track, index) => `${index + 1}. ${track.title}`),
    ].filter(Boolean);

    return interaction.reply({
      content: lines.join('\n') || 'Queue empty.',
      ephemeral: true,
    });
  }

  if (command === 'nowplaying') {
    return interaction.reply(
      state.current
        ? [
            `🎧 **${state.current.title}**`,
            `Progress: ${state.elapsed}s / ${state.duration || '?'}s`,
            `Player: ${state.status}`,
            `Volume: ${state.volume}%`,
          ].join('\n')
        : `Nothing is playing. Player: ${state.status}`
    );
  }
}


function voiceHealth(guildId) {
  const state = stateFor(guildId);
  return {
    connection: state.connection
      ? connectionSnapshot(state.connection)
      : { status: 'disconnected', reason: null, closeCode: null },
    voiceChannelId: state.voiceChannelId,
    attempt: state.connectionAttempt,
    recentTransitions: [...state.connectionLog],
    dependencies: generateDependencyReport(),
  };
}


function spotifyUrlSelfTest() {
  const samples = [
    ['https://open.spotify.com/track/4cOdK2wGLETKBW3PvgPWqT', 'track'],
    ['https://open.spotify.com/album/1ATL5GLyefJaxhQzSPVrLX', 'album'],
    ['https://open.spotify.com/playlist/37i9dQZF1DXcBWIGoYBM5M', 'playlist'],
    ['https://open.spotify.com/intl-nl/playlist/37i9dQZF1DXcBWIGoYBM5M?si=test', 'playlist'],
  ];

  for (const [url, expectedType] of samples) {
    const parsed = parseSpotifyUrl(url);
    if (!parsed || parsed.type !== expectedType) {
      throw new Error(`Spotify URL parser self-test failed for ${url}`);
    }
  }

  return true;
}

spotifyUrlSelfTest();

module.exports = {
  enqueue,
  pause,
  resume,
  skip,
  stop,
  setVolume,
  setLoop,
  toggleShuffle,
  toggleAutoplay,
  setEqualizer,
  snapshot,
  lyrics,
  dependencyStatus,
  voiceHealth,
  handleCommand,
};
