# Helixcraft Bot v4

Upgrade van v3.1 met:

- Advanced AutoMod: links, invites, spam, caps, mentions, Zalgo, raid alerts en automatische timeout
- Tickets 2.0: categorieknoppen, modalformulier, prioriteit en staff notes
- Levels: message XP, voice XP, daily XP limit en leaderboard
- Economy: wallet, bank, daily, work, crime, pay, gamble, shop en inventory
- Giveaways Pro blijft aanwezig uit v3.1: role requirements, bonus entries, account/member age, pause/resume/reroll
- Dashboard: aparte AutoMod-, Levels-, Economy- en Auditpagina’s met losse save-acties

## Upgrade

```bash
cd /root
cp -a helixcraft-bot helixcraft-bot-backup-v4
unzip -o helixcraft-bot-v4.zip
cp /root/helixcraft-bot/.env /root/helixcraft-bot-v4/.env
cp -a /root/helixcraft-bot/data/. /root/helixcraft-bot-v4/data/
cd /root/helixcraft-bot-v4
npm install
npm run check
npm start
```

Test eerst v4 voordat je de oude map verwijdert.

## Nieuwe commands

`/level`, `/leaderboard`, `/balance`, `/daily`, `/work`, `/crime`, `/deposit`, `/withdraw`, `/pay`, `/gamble`, `/shop`, `/buy`, `/inventory`, `/economy-admin`, `/ticket-panel-v2`, `/ticket-note`, `/ticket-priority`, `/automod-status`.

## Opmerking over AI-spamdetectie

Deze versie gebruikt lokale heuristieken voor spamdetectie. Echte externe AI-classificatie is bewust niet standaard ingeschakeld, zodat berichten niet naar een externe dienst worden gestuurd en de bot zonder extra API-kosten werkt.
