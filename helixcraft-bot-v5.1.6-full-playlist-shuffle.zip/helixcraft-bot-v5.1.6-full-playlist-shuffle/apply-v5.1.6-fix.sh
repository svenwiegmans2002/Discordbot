#!/usr/bin/env bash
set -Eeuo pipefail

SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ACTIVE_DIR="/root/helixcraft-bot"
STAMP="$(date +%Y%m%d-%H%M%S)"

cp "$ACTIVE_DIR/src/music.js" "/root/music.js.backup-$STAMP"
cp "$ACTIVE_DIR/src/dashboard.js" "/root/dashboard.js.backup-$STAMP"

cp "$SOURCE_DIR/src/music.js" "$ACTIVE_DIR/src/music.js"
cp "$SOURCE_DIR/src/dashboard.js" "$ACTIVE_DIR/src/dashboard.js"

cd "$ACTIVE_DIR"
node --check src/music.js
node --check src/dashboard.js

if systemctl list-unit-files | grep -q '^helixcraft-bot.service'; then
  systemctl restart helixcraft-bot
  sleep 3
  systemctl --no-pager --full status helixcraft-bot || true
else
  pkill -f "/root/helixcraft-bot/index.js" 2>/dev/null || true
  echo "Patch toegepast. Start met: cd /root/helixcraft-bot && npm start"
fi

echo
echo "v5.1.6 toegepast."
echo "De volledige Spotify-playlist wordt nu ingelezen."
echo "Shuffle kan via /shuffle en Dashboard → Music Manager."
