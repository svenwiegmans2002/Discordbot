#!/usr/bin/env bash
set -Eeuo pipefail

SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ACTIVE_DIR="/root/helixcraft-bot"
BACKUP="/root/music.js.backup-$(date +%Y%m%d-%H%M%S)"

if [ ! -f "$ACTIVE_DIR/src/music.js" ]; then
  echo "Actieve music.js niet gevonden: $ACTIVE_DIR/src/music.js"
  exit 1
fi

cp "$ACTIVE_DIR/src/music.js" "$BACKUP"
cp "$SOURCE_DIR/src/music.js" "$ACTIVE_DIR/src/music.js"

cd "$ACTIVE_DIR"
node --check src/music.js

# Old in-memory state disappears on restart; no configuration or Spotify tokens
# are removed.
if systemctl list-unit-files | grep -q '^helixcraft-bot.service'; then
  systemctl restart helixcraft-bot
  sleep 3
  systemctl --no-pager --full status helixcraft-bot || true
else
  pkill -f "/root/helixcraft-bot/index.js" 2>/dev/null || true
  echo "Patch toegepast."
  echo "Start de actieve bot met:"
  echo "cd /root/helixcraft-bot && npm start"
fi

echo
echo "v5.1.5 Spotify-items-fix toegepast."
echo "Backup: $BACKUP"
echo "Koppel Spotify opnieuw in Dashboard → Music Manager voordat je de playlist test."
