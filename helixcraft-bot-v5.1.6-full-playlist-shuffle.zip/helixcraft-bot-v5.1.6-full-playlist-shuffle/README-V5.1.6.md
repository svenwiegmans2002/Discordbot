# Helixcraft Bot v5.1.6 — Full Spotify Playlist + Shuffle

## Nieuw

- Alle Spotify-pagina's worden opgehaald.
- Geen limiet van 100 nummers.
- Playlists met 4.000+ items worden volledig ingelezen.
- `/shuffle` schudt de volledige huidige queue.
- Dashboard → Music Manager heeft een standaard shuffle-optie.
- Lokale bestanden, podcasts en niet-beschikbare items worden overgeslagen.
- De vaste Music-voicechannel en de voice-fixes blijven behouden.
- Temporary voice creation blijft uitgeschakeld.

## Installeren

```bash
cd /root/helixcraft-bot-v5.1.6-full-playlist-shuffle
chmod +x apply-v5.1.6-fix.sh
./apply-v5.1.6-fix.sh
```

## Gebruiken

Shuffle vooraf inschakelen:

```text
/shuffle
```

Daarna:

```text
/play query:https://open.spotify.com/playlist/...
```

Bij een playlist met duizenden nummers kan het volledig inladen enkele minuten
duren. De voortgang verschijnt in de servicelogs:

```bash
journalctl -u helixcraft-bot -f
```
