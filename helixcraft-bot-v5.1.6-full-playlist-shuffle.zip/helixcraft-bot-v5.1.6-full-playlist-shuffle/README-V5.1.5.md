# Helixcraft Bot v5.1.5 — Spotify Playlist Items Fix

Spotify gebruikt voor playlistinhoud nu:

```text
GET /v1/playlists/{playlist_id}/items
```

De oude `/tracks`-route en het oude ingebedde `tracks`-veld worden niet meer
voor playlistinhoud gebruikt.

## Hersteld

- actuele `/items`-endpoint;
- 50 playlistitems per pagina;
- nieuwe `item`-responsevorm;
- lazy loading voor playlists met duizenden nummers;
- lokale bestanden, podcasts en onbeschikbare items worden afzonderlijk
  overgeslagen;
- Spotify OAuth-token en overige botgegevens blijven behouden.

## Patch toepassen

```bash
cd /root/helixcraft-bot-v5.1.5-spotify-items-fix
chmod +x apply-v5.1.5-fix.sh
./apply-v5.1.5-fix.sh
```

Koppel Spotify daarna opnieuw via Dashboard → Music Manager en test de playlist.
