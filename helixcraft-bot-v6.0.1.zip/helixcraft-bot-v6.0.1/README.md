# Helixcraft Bot v6.0.1

Deze volledige v6-versie bevat een vernieuwd categorie-specifiek ticketsysteem.

## Standaard ticketcategorieën

- 🛟 Support
- 🐛 Bug Report
- 🛒 Purchase
- ⚖️ Appeal
- 📝 Apply

Elke categorie opent een eigen formulier met vragen die bij dat type ticket
passen. **Apply** vraagt bijvoorbeeld naar de gewenste positie, ervaring,
motivatie, beschikbaarheid en eventuele portfolio-informatie.

## Engelse privacywaarschuwing

Het panel, ticketkanaal en bevestigingsbericht tonen:

> Your responses will be submitted to Helixcraft Bot. Do not share passwords,
> payment details, recovery codes, API keys, tokens, or other sensitive
> information.

## Installeren

```bash
cd /root/helixcraft-bot-v6.0.1
chmod +x install-v6.sh
./install-v6.sh
```

Het installatiescript behoudt je bestaande `.env`, data en transcripts.

Maak daarna een nieuw panel:

```text
/ticket-panel-v2
```

Verwijder het oude panelbericht; bestaande Discord-berichten worden niet
automatisch bijgewerkt.
