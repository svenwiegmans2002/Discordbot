const {EmbedBuilder,ActionRowBuilder,ButtonBuilder,ButtonStyle,StringSelectMenuBuilder,ModalBuilder,TextInputBuilder,TextInputStyle,ChannelType,PermissionFlagsBits}=require('discord.js');
const store=require('./store');const automod=require('./automod');const levels=require('./levels');const economy=require('./economy');
function emb(t,d,c=0x5865f2){return new EmbedBuilder().setTitle(t).setDescription(d).setColor(c).setTimestamp().setFooter({text:'Helixcraft v4'})}
function randomId(){return Math.random().toString(36).slice(2,10)}


const TICKET_PRIVACY_NOTICE =
  'Your responses will be submitted to Helixcraft Bot. ' +
  'Do not share passwords, payment details, recovery codes, API keys, tokens, ' +
  'or other sensitive information.';

const BUILTIN_TICKET_FORMS = {
  support: {
    label: 'Support', emoji: '🛟',
    description: 'General help with the server or services',
    fields: [
      ['subject','Subject','Short summary of your support request','short',true,3,100],
      ['issue','What do you need help with?','Explain the problem clearly and include relevant context','paragraph',true,10,1500],
      ['steps','What have you already tried?','List troubleshooting steps you already attempted','paragraph',false,0,900],
      ['expected','What outcome do you expect?','Describe the result that would resolve your request','paragraph',true,0,800],
      ['extra','Extra information (optional)','Safe links or error codes only. Never share secrets.','paragraph',false,0,800],
    ],
  },
  bug: {
    label: 'Bug Report', emoji: '🐛',
    description: 'Report a reproducible bug or technical issue',
    fields: [
      ['subject','Bug title','Short name for the bug','short',true,3,100],
      ['reproduce','Steps to reproduce','Explain exactly how staff can reproduce the issue','paragraph',true,10,1500],
      ['expected','Expected behaviour','What should have happened?','paragraph',true,0,800],
      ['environment','Environment','Platform, version, device, browser, plugin, or mod','paragraph',true,0,700],
      ['extra','Evidence or extra details','Safe screenshot or log links and non-sensitive errors','paragraph',false,0,900],
    ],
  },
  purchase: {
    label: 'Purchase', emoji: '🛒',
    description: 'Questions about purchases, billing, or delivery',
    fields: [
      ['subject','Purchase subject','Refund, missing item, delivery issue, or another question','short',true,3,100],
      ['product','Product or service','What did you purchase or attempt to purchase?','short',true,0,120],
      ['order','Order reference (optional)','Order number only. Never enter card or bank details.','short',false,0,120],
      ['issue','Explain the purchase issue','Describe what happened and when','paragraph',true,10,1400],
      ['extra','Extra information (optional)','Safe context only. Do not share payment details.','paragraph',false,0,800],
    ],
  },
  appeal: {
    label: 'Appeal', emoji: '⚖️',
    description: 'Appeal a warning, mute, timeout, kick, or ban',
    fields: [
      ['subject','Appeal subject','What punishment are you appealing?','short',true,3,100],
      ['punishment','Punishment details','Type, approximate date, reason, and case ID','paragraph',true,10,1000],
      ['reason','Why should it be reconsidered?','Explain your appeal honestly and clearly','paragraph',true,20,1500],
      ['evidence','Evidence or context (optional)','Safe links or relevant context only','paragraph',false,0,900],
      ['future','How will this be prevented?','Explain what will change if approved','paragraph',true,0,900],
    ],
  },
  apply: {
    label: 'Apply', emoji: '📝',
    description: 'Apply for staff, creator, builder, partner, or another role',
    fields: [
      ['subject','Position or role','Which position or role are you applying for?','short',true,2,100],
      ['experience','Relevant experience','Describe your skills and previous experience','paragraph',true,20,1500],
      ['motivation','Why do you want to apply?','Explain your motivation and contribution','paragraph',true,20,1500],
      ['availability','Availability and timezone','Days, approximate hours, and timezone','paragraph',true,0,700],
      ['extra','Portfolio or extra information','Safe public links or other relevant information','paragraph',false,0,900],
    ],
  },
};

function materializeForm(key, definition) {
  return {
    key,
    label: definition.label,
    emoji: definition.emoji,
    description: definition.description,
    fields: definition.fields.map(([id,label,placeholder,style,required,minLength,maxLength])=>({
      id,label,placeholder,
      style:style==='short'?TextInputStyle.Short:TextInputStyle.Paragraph,
      required,minLength,maxLength
    }))
  };
}

function normalizeTicketKey(value) {
  const key=String(value||'').trim().toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');
  if(['application','applications','apply'].includes(key))return 'apply';
  if(['bug-report','bugs','bug'].includes(key))return 'bug';
  if(['billing','shop','purchase'].includes(key))return 'purchase';
  if(['ban-appeal','appeals','appeal'].includes(key))return 'appeal';
  if(['help','support'].includes(key))return 'support';
  return key||'support';
}

function genericTicketForm(label,key) {
  return {
    key,label,emoji:'🎫',description:`Open a ${label} ticket`,
    fields:[
      {id:'subject',label:'Subject',placeholder:'Short summary of your request',style:TextInputStyle.Short,required:true,minLength:3,maxLength:100},
      {id:'details',label:'Detailed explanation',placeholder:'Explain your request in as much detail as possible',style:TextInputStyle.Paragraph,required:true,minLength:10,maxLength:1500},
      {id:'expected',label:'Expected solution',placeholder:'What outcome would help you?',style:TextInputStyle.Paragraph,required:true,minLength:0,maxLength:800},
      {id:'extra',label:'Extra information (optional)',placeholder:'Safe, non-sensitive information only',style:TextInputStyle.Paragraph,required:false,minLength:0,maxLength:800},
    ]
  };
}

function ticketCategories(guildId) {
  const configured=store.guildConfig(guildId).ticketCategories;
  if(Array.isArray(configured)&&configured.length){
    return configured.slice(0,25).map(entry=>{
      const label=typeof entry==='string'?entry:String(entry?.label||entry?.name||'Ticket');
      const key=normalizeTicketKey(typeof entry==='string'?entry:(entry?.key||label));
      const builtin=BUILTIN_TICKET_FORMS[key];
      if(builtin){
        const form=materializeForm(key,builtin);
        if(typeof entry==='object'){
          form.label=label;
          form.emoji=entry?.emoji||form.emoji;
          form.description=entry?.description||form.description;
        }
        return form;
      }
      return genericTicketForm(label,key);
    });
  }
  return ['support','bug','purchase','appeal','apply']
    .map(key=>materializeForm(key,BUILTIN_TICKET_FORMS[key]));
}

function ticketFormByKey(guildId,key){
  return ticketCategories(guildId).find(category=>category.key===key)||null;
}

function isTicketStaff(interaction,cfg){
  return Boolean(
    interaction.memberPermissions?.has(PermissionFlagsBits.ManageChannels) ||
    interaction.memberPermissions?.has(PermissionFlagsBits.Administrator) ||
    (cfg.ticketSupportRoleId && interaction.member.roles.cache.has(cfg.ticketSupportRoleId))
  );
}

function priorityMeta(priority){
  return {
    low:{label:'Low',emoji:'🟢',color:0x57f287},
    normal:{label:'Normal',emoji:'🔵',color:0x5865f2},
    high:{label:'High',emoji:'🟠',color:0xfee75c},
    urgent:{label:'Urgent',emoji:'🔴',color:0xed4245},
  }[priority]||{label:'Normal',emoji:'🔵',color:0x5865f2};
}

function ticketControlRows(ticket){
  const claimLabel=ticket.claimedBy?'Unclaim':'Claim';
  const claimAction=ticket.claimedBy?'unclaim':'claim';
  const actions=new ActionRowBuilder().addComponents(
    new ButtonBuilder().setCustomId(`ticketv5:action:${claimAction}`).setLabel(claimLabel).setEmoji(ticket.claimedBy?'↩️':'🙋').setStyle(ticket.claimedBy?ButtonStyle.Secondary:ButtonStyle.Success),
    new ButtonBuilder().setCustomId('ticketv5:action:close-help').setLabel('Close ticket').setEmoji('🔒').setStyle(ButtonStyle.Danger)
  );
  const priorities=new ActionRowBuilder().addComponents(
    new StringSelectMenuBuilder().setCustomId('ticketv5:priority').setPlaceholder(`Priority: ${priorityMeta(ticket.priority).label}`).addOptions(
      {label:'Low',value:'low',emoji:'🟢',description:'No urgency'},
      {label:'Normal',value:'normal',emoji:'🔵',description:'Standard support request'},
      {label:'High',value:'high',emoji:'🟠',description:'Needs quick attention'},
      {label:'Urgent',value:'urgent',emoji:'🔴',description:'Critical issue'}
    )
  );
  return [actions,priorities];
}

function ticketDescription(ticket){
  const p=priorityMeta(ticket.priority);
  const answers=Array.isArray(ticket.formAnswers)
    ? ticket.formAnswers.filter(a=>a.value).map(a=>`**${a.label}**\n${a.value}`)
    : [`**Explanation**\n${ticket.details||'Not provided.'}`,`**Expected solution**\n${ticket.expectedSolution||'Not specified.'}`,`**Extra information**\n${ticket.extraInfo||'None.'}`];
  return [
    `**Category:** ${ticket.type}`,
    `**Subject:** ${ticket.subject}`,
    `**Priority:** ${p.emoji} ${p.label}`,
    `**Opened by:** <@${ticket.openerId}>`,
    `**Claimed by:** ${ticket.claimedBy?`<@${ticket.claimedBy}>`:'Nobody'}`,
    '',...answers,'',`> ${TICKET_PRIVACY_NOTICE}`
  ].join('\n');
}

async function updateTicketHeader(channel,ticket){
  if(!ticket.headerMessageId)return;
  const message=await channel.messages.fetch(ticket.headerMessageId).catch(()=>null);
  if(!message)return;
  const p=priorityMeta(ticket.priority);
  await message.edit({
    embeds:[emb(`🎫 ${ticket.type} Ticket`,ticketDescription(ticket),p.color)],
    components:ticketControlRows(ticket)
  }).catch(()=>{});
}

function installV4(client){
 client.on('messageCreate',m=>{automod.onMessage(m);levels.messageXp(m)});client.on('guildMemberAdd',m=>automod.onJoin(m));client.on('voiceStateUpdate',(a,b)=>levels.voiceState(a,b));
 client.on('interactionCreate',async i=>{try{
  if(i.isStringSelectMenu()&&i.customId==='ticketv5:category'){
   const form=ticketFormByKey(i.guild.id,String(i.values[0]||''));
   if(!form)return i.reply({content:'This ticket category is no longer available.',ephemeral:true});

   const modal=new ModalBuilder()
    .setCustomId(`ticketv6:modal:${form.key}`)
    .setTitle(`${form.emoji} ${form.label}`.slice(0,45));

   for(const field of form.fields.slice(0,5)){
    const input=new TextInputBuilder()
     .setCustomId(field.id)
     .setLabel(field.label.slice(0,45))
     .setPlaceholder(field.placeholder.slice(0,100))
     .setStyle(field.style)
     .setRequired(Boolean(field.required));
    if(field.minLength)input.setMinLength(field.minLength);
    if(field.maxLength)input.setMaxLength(field.maxLength);
    modal.addComponents(new ActionRowBuilder().addComponents(input));
   }
   return i.showModal(modal);
  }

  if(i.isModalSubmit()&&i.customId.startsWith('ticketv6:modal:')){
   const form=ticketFormByKey(i.guild.id,i.customId.split(':')[2]);
   if(!form)return i.reply({content:'This ticket category is no longer available.',ephemeral:true});

   const allTickets=store.read('tickets');
   const existing=Object.values(allTickets).find(ticket=>ticket.guildId===i.guild.id&&ticket.openerId===i.user.id&&ticket.status==='open');
   if(existing)return i.reply({content:`You already have an open ticket: <#${existing.channelId}>`,ephemeral:true});

   const cfg=store.guildConfig(i.guild.id);
   const cat=cfg.ticketCategoryId&&i.guild.channels.cache.get(cfg.ticketCategoryId);
   const support=cfg.ticketSupportRoleId&&i.guild.roles.cache.get(cfg.ticketSupportRoleId);
   const formAnswers=form.fields.map(field=>{
    let value='';try{value=i.fields.getTextInputValue(field.id).trim()}catch{}
    return {id:field.id,label:field.label,value,required:Boolean(field.required)};
   });
   const map=Object.fromEntries(formAnswers.map(a=>[a.id,a.value]));
   const subject=map.subject||`${form.label} request`;
   const safeType=form.key.replace(/[^a-z0-9]/g,'-');
   const safeUser=i.user.username.toLowerCase().replace(/[^a-z0-9]/g,'-');

   const overwrites=[
    {id:i.guild.id,deny:[PermissionFlagsBits.ViewChannel]},
    {id:i.user.id,allow:[PermissionFlagsBits.ViewChannel,PermissionFlagsBits.SendMessages,PermissionFlagsBits.ReadMessageHistory,PermissionFlagsBits.AttachFiles,PermissionFlagsBits.EmbedLinks]},
    {id:i.guild.members.me.id,allow:[PermissionFlagsBits.ViewChannel,PermissionFlagsBits.SendMessages,PermissionFlagsBits.ReadMessageHistory,PermissionFlagsBits.ManageChannels,PermissionFlagsBits.ManageMessages]}
   ];
   if(support)overwrites.push({id:support.id,allow:[PermissionFlagsBits.ViewChannel,PermissionFlagsBits.SendMessages,PermissionFlagsBits.ReadMessageHistory,PermissionFlagsBits.AttachFiles,PermissionFlagsBits.EmbedLinks]});

   const ch=await i.guild.channels.create({
    name:`${safeType}-${safeUser}`.replace(/-+/g,'-').slice(0,90),
    type:ChannelType.GuildText,parent:cat?.id,
    topic:`${form.label} ticket by ${i.user.tag} | ${subject}`.slice(0,1024),
    permissionOverwrites:overwrites
   });

   const ticket={
    id:randomId(),guildId:i.guild.id,channelId:ch.id,openerId:i.user.id,
    type:form.label,typeKey:form.key,subject,formAnswers,
    details:map.issue||map.details||map.reproduce||map.reason||map.experience||'',
    expectedSolution:map.expected||map.future||map.motivation||'',
    extraInfo:map.extra||map.evidence||map.environment||map.availability||'',
    privacyNotice:TICKET_PRIVACY_NOTICE,priority:'normal',claimedBy:null,status:'open',
    notes:[],createdAt:Date.now(),lastActivityAt:Date.now(),
    autoCloseAt:Date.now()+(cfg.ticketAutoCloseHours||72)*3600000,headerMessageId:null
   };

   const header=await ch.send({
    content:`${i.user}${support?` ${support}`:''}`,
    embeds:[emb(`${form.emoji} ${form.label} Ticket`,ticketDescription(ticket),priorityMeta(ticket.priority).color)],
    components:ticketControlRows(ticket)
   });
   ticket.headerMessageId=header.id;
   allTickets[ch.id]=ticket;
   store.write('tickets',allTickets);
   store.audit(i.guild.id,'ticket-open',i.user.id,ch.id,`${form.label}: ${subject}`);

   return i.reply({content:`Ticket created: ${ch}\n\n${TICKET_PRIVACY_NOTICE}`,ephemeral:true});
  }

  if(i.isButton()&&i.customId.startsWith('ticketv5:action:')){
   const action=i.customId.split(':')[2];
   const cfg=store.guildConfig(i.guild.id);
   const tickets=store.read('tickets');
   const ticket=tickets[i.channel.id];

   if(!ticket)return i.reply({content:'This is not a tracked ticket.',ephemeral:true});
   if(!isTicketStaff(i,cfg))return i.reply({content:'Only support staff can use this control.',ephemeral:true});

   if(action==='claim'){
    ticket.claimedBy=i.user.id;
    store.write('tickets',tickets);
    await updateTicketHeader(i.channel,ticket);
    store.audit(i.guild.id,'ticket-claim',i.user.id,i.channel.id,ticket.subject);
    return i.reply({content:`Ticket claimed by ${i.user}.`});
   }

   if(action==='unclaim'){
    ticket.claimedBy=null;
    store.write('tickets',tickets);
    await updateTicketHeader(i.channel,ticket);
    store.audit(i.guild.id,'ticket-unclaim',i.user.id,i.channel.id,ticket.subject);
    return i.reply({content:'Ticket unclaimed.'});
   }

   if(action==='close-help'){
    return i.reply({
     content:'Use `/ticket close` to close this ticket and create its transcript.',
     ephemeral:true
    });
   }
  }

  if(i.isStringSelectMenu()&&i.customId==='ticketv5:priority'){
   const cfg=store.guildConfig(i.guild.id);
   const tickets=store.read('tickets');
   const ticket=tickets[i.channel.id];

   if(!ticket)return i.reply({content:'This is not a tracked ticket.',ephemeral:true});
   if(!isTicketStaff(i,cfg))return i.reply({content:'Only support staff can set ticket priority.',ephemeral:true});

   ticket.priority=i.values[0];
   store.write('tickets',tickets);
   await updateTicketHeader(i.channel,ticket);

   const p=priorityMeta(ticket.priority);
   store.audit(i.guild.id,'ticket-priority',i.user.id,i.channel.id,ticket.priority);

   return i.reply({content:`Priority changed to ${p.emoji} **${p.label}**.`});
  }
  if(!i.isChatInputCommand())return;const c=i.commandName;
  if(c==='level'){const u=i.options.getUser('user')||i.user,{row}=levels.get(i.guild.id,u.id);return i.reply({embeds:[emb(`Level: ${u.username}`,`Level **${row.level}**\nXP **${row.xp}/${levels.required(row.level+1)}**\nMessages: **${row.messages}**\nVoice: **${row.voiceMinutes} min**`)]})}
  if(c==='leaderboard'){const rows=Object.entries(store.read('levels')[i.guild.id]||{}).sort((a,b)=>b[1].xp-a[1].xp).slice(0,10);return i.reply({embeds:[emb('XP Leaderboard',rows.map(([id,r],n)=>`**${n+1}.** <@${id}> — level ${r.level} (${r.xp} XP)`).join('\n')||'No XP yet.') ]})}
  if(c==='balance'){const u=i.options.getUser('user')||i.user,{row}=economy.get(i.guild.id,u.id);return i.reply({embeds:[emb(`Balance: ${u.username}`,`Wallet: **${row.wallet}**\nBank: **${row.bank}**\nTotal: **${row.wallet+row.bank}**`)]})}
  if(['daily','work','crime'].includes(c)){const cfg=store.guildConfig(i.guild.id),{all,row}=economy.get(i.guild.id,i.user.id),now=Date.now();let amount=0,msg='';if(c==='daily'){if(now-row.lastDaily<86400000)throw new Error('Daily already claimed.');amount=cfg.dailyAmount;row.lastDaily=now;msg=`Daily reward: **${amount}** coins.`}if(c==='work'){if(now-row.lastWork<3600000)throw new Error('You can work once per hour.');amount=Math.floor(Math.random()*(cfg.workMax-cfg.workMin+1))+cfg.workMin;row.lastWork=now;msg=`You earned **${amount}** coins.`}if(c==='crime'){if(now-row.lastCrime<3600000)throw new Error('You can commit crime once per hour.');row.lastCrime=now;if(Math.random()*100<cfg.crimeFailChance){amount=-Math.min(row.wallet,Math.floor(Math.random()*100)+25);row.lost+=Math.abs(amount);msg=`Crime failed. You lost **${Math.abs(amount)}** coins.`}else{amount=Math.floor(Math.random()*(cfg.crimeMax-cfg.crimeMin+1))+cfg.crimeMin;row.won+=amount;msg=`Crime succeeded. You gained **${amount}** coins.`}}row.wallet+=amount;economy.save(all);return i.reply(msg)}
  if(['deposit','withdraw','gamble'].includes(c)){const amount=i.options.getInteger('amount'),{all,row}=economy.get(i.guild.id,i.user.id);if(c==='deposit'){if(row.wallet<amount)throw new Error('Not enough wallet balance.');row.wallet-=amount;row.bank+=amount}if(c==='withdraw'){if(row.bank<amount)throw new Error('Not enough bank balance.');row.bank-=amount;row.wallet+=amount}if(c==='gamble'){if(row.wallet<amount)throw new Error('Not enough coins.');if(Math.random()<0.48){row.wallet+=amount;row.won+=amount}else{row.wallet-=amount;row.lost+=amount}}economy.save(all);return i.reply(`Updated balance: wallet **${row.wallet}**, bank **${row.bank}**.`)}
  if(c==='pay'){const u=i.options.getUser('user'),amount=i.options.getInteger('amount');if(u.bot||u.id===i.user.id)throw new Error('Choose another member.');const a=economy.get(i.guild.id,i.user.id),b=economy.get(i.guild.id,u.id);if(a.row.wallet<amount)throw new Error('Not enough coins.');a.row.wallet-=amount;b.row.wallet+=amount;store.write('economy',a.all);store.write('economy',b.all);return i.reply(`Paid **${amount}** coins to ${u}.`)}
  if(c==='shop'){const items=Object.values(store.read('shop')[i.guild.id]||{});return i.reply({embeds:[emb('Server Shop',items.map(x=>`\`${x.id}\` **${x.name}** — ${x.price} coins${x.roleId?` — <@&${x.roleId}>`:''}`).join('\n')||'Shop is empty.')]})}
  if(c==='buy'){const item=store.read('shop')[i.guild.id]?.[i.options.getString('item')];if(!item)throw new Error('Item not found.');const e=economy.get(i.guild.id,i.user.id);if(e.row.wallet<item.price)throw new Error('Not enough coins.');e.row.wallet-=item.price;economy.save(e.all);const inv=economy.inventory(i.guild.id,i.user.id);inv.row.push({itemId:item.id,name:item.name,boughtAt:Date.now()});store.write('inventory',inv.all);if(item.roleId){const role=i.guild.roles.cache.get(item.roleId);if(role)await i.member.roles.add(role).catch(()=>{})}return i.reply(`Purchased **${item.name}**.`)}
  if(c==='inventory'){const u=i.options.getUser('user')||i.user,inv=economy.inventory(i.guild.id,u.id).row;return i.reply({embeds:[emb(`Inventory: ${u.username}`,inv.map(x=>`• ${x.name}`).join('\n')||'Empty.')]})}
  if(c==='economy-admin'){const sub=i.options.getSubcommand();if(sub==='add-coins'){const u=i.options.getUser('user'),amount=i.options.getInteger('amount'),e=economy.get(i.guild.id,u.id);e.row.wallet+=amount;economy.save(e.all);return i.reply({content:'Coins updated.',ephemeral:true})}const id=randomId(),shop=store.read('shop');shop[i.guild.id]||={};shop[i.guild.id][id]={id,name:i.options.getString('name'),price:i.options.getInteger('price'),roleId:i.options.getRole('role')?.id||null};store.write('shop',shop);return i.reply({content:`Shop item added: \`${id}\`.`,ephemeral:true})}
  if(c==='ticket-panel-v2'){
   const categories=ticketCategories(i.guild.id);
   const menu=new StringSelectMenuBuilder()
    .setCustomId('ticketv5:category')
    .setPlaceholder('Choose a ticket category')
    .addOptions(categories.map(category=>({
     label:category.label.slice(0,100),
     value:category.key.slice(0,100),
     description:category.description.slice(0,100),
     emoji:category.emoji
    })));

   await i.channel.send({
    embeds:[emb('🎫 Helixcraft Support',[
      'Select the category that best matches your request.',
      'Each category opens a different form with tailored questions.',
      '',
      '**Available categories**',
      categories.map(category=>`${category.emoji} **${category.label}** — ${category.description}`).join('\n'),
      '',
      '⚠️ **Privacy notice**',
      TICKET_PRIVACY_NOTICE
    ].join('\n'))],
    components:[new ActionRowBuilder().addComponents(menu)]
   });
   return i.reply({content:'Category-specific ticket panel created.',ephemeral:true});
  }
  if(c==='ticket-note'||c==='ticket-priority'){
   const all=store.read('tickets'),t=all[i.channel.id];
   if(!t)throw new Error('This is not a tracked ticket.');
   const cfg=store.guildConfig(i.guild.id);
   if(!isTicketStaff(i,cfg))throw new Error('Only support staff can update this ticket.');

   if(c==='ticket-note'){
    t.notes||=[];
    t.notes.push({authorId:i.user.id,text:i.options.getString('note'),createdAt:Date.now()});
   }else{
    t.priority=i.options.getString('priority');
    await updateTicketHeader(i.channel,t);
   }

   store.write('tickets',all);
   store.audit(i.guild.id,c,i.user.id,i.channel.id,c==='ticket-note'?'Staff note added':t.priority);
   return i.reply({content:'Ticket updated.',ephemeral:true});
  }
  if(c==='automod-status'){const cfg=store.guildConfig(i.guild.id);return i.reply({embeds:[emb('AutoMod Status',`Enabled: **${cfg.automodEnabled}**\nLinks: **${cfg.antiLinks}**\nInvites: **${cfg.antiInvites}**\nSpam: **${cfg.antiSpam}**\nCaps: **${cfg.antiCaps}**\nMentions: **${cfg.antiMentions}**\nZalgo: **${cfg.antiZalgo}**\nRaid: **${cfg.antiRaid}**`)],ephemeral:true})}
 }catch(e){console.error('v4 interaction error',e);const p={content:`Error: ${e.message}`,ephemeral:true};if(i.replied||i.deferred)i.followUp(p).catch(()=>{});else i.reply(p).catch(()=>{})}})
}
module.exports={installV4};
