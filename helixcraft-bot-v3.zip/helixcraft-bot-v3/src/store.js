const fs = require('fs');
const path = require('path');

const DATA_DIR = path.join(__dirname, '..', 'data');
fs.mkdirSync(DATA_DIR, { recursive: true });

const DEFAULTS = {
  config: {}, warnings: {}, punishments: [], tickets: {}, giveaways: {}, sticky: {}, tempVoice: {}, suggestions: {}, backups: []
};

function fileFor(name) { return path.join(DATA_DIR, `${name}.json`); }
function read(name) {
  const file = fileFor(name); const fallback = DEFAULTS[name] ?? {};
  try {
    if (!fs.existsSync(file)) fs.writeFileSync(file, JSON.stringify(fallback, null, 2));
    return JSON.parse(fs.readFileSync(file, 'utf8'));
  } catch (e) { console.error(`Store read error ${name}:`, e); return structuredClone(fallback); }
}
function write(name, value) {
  const file = fileFor(name); const tmp = `${file}.tmp`;
  fs.writeFileSync(tmp, JSON.stringify(value, null, 2)); fs.renameSync(tmp, file);
}
function mutate(name, fn) { const value = read(name); const result = fn(value) ?? value; write(name, result); return result; }
function guildConfig(guildId) {
  const all = read('config');
  if (!all[guildId]) {
    all[guildId] = {
      welcomeChannelId: null, welcomeMessage: 'Welcome {member} to **{server}**! You are member #{count}.', autoroleId: null,
      logChannelId: null, ticketCategoryId: null, ticketLogChannelId: null, ticketSupportRoleId: null,
      ticketAutoCloseHours: 72, tempVoiceLobbyId: null, tempVoiceCategoryId: null, suggestionChannelId: null,
      warnTimeoutThreshold: 3, warnTimeoutMinutes: 60
    }; write('config', all);
  }
  return all[guildId];
}
function setGuildConfig(guildId, patch) { return mutate('config', all => { all[guildId] = { ...guildConfig(guildId), ...patch }; }); }
module.exports = { read, write, mutate, guildConfig, setGuildConfig, DATA_DIR };
