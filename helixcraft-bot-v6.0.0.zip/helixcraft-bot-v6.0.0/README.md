# Helixcraft Bot v6.0.0

Een geconsolideerde all-in-one Discord-bot. Deze versie vervangt de reeks losse
v5-patches door één consistente projectmap.

## Inbegrepen

- Discord OAuth-dashboard achter Nginx en Cloudflare Tunnel
- serverselectie en browserinstellingen
- moderatie, warnings, tijdelijke straffen en logging
- AutoMod en anti-spam/anti-raidinstellingen
- verificatie en rolesystemen
- geavanceerde tickets:
  - categorie-dropdown
  - subject en uitgebreide uitleg
  - gewenste oplossing en extra informatie
  - claim/unclaim
  - Low/Normal/High/Urgent-prioriteit
  - staff notes
  - betrouwbaar sluiten
  - HTML-transcripts
- giveaways en events
- levels en economy
- Message Studio met embeds, buttons, dropdowns, planning en templates
- vast muziekvoicekanaal uit het dashboard
- Spotify OAuth, tracks, albums en volledige playlists
- volledige playlist-shuffle
- lyrics, loop, autoplay, volume en equalizer
- optionele Minecraft-statistieken
- dashboardstatistieken, auditlogs en realtime updates

Temporary voice creation is uitgeschakeld. De muziekbot gebruikt uitsluitend
het vaste kanaal uit Music Manager en maakt zelf geen voicekanaal aan.

## Vereisten

- Ubuntu/Debian CT
- Node.js 22.12 of hoger
- Discord-bot en Discord OAuth-app
- openbaar HTTPS-dashboard via Cloudflare Tunnel
- optioneel een Spotify Developer-app

## Redirects

Discord Developer Portal:

```text
https://bot.helixcraft-hosting.net/callback
```

Spotify Developer Dashboard:

```text
https://bot.helixcraft-hosting.net/spotify/callback
```

## Installeren of upgraden

Pak de zip uit en voer uit:

```bash
cd /root/helixcraft-bot-v6.0.0
chmod +x install-v6.sh
./install-v6.sh
```

Het script:

1. controleert Node.js;
2. installeert FFmpeg en yt-dlp;
3. maakt een volledige backup;
4. neemt je bestaande `.env`, data en transcripts mee;
5. installeert npm-dependencies;
6. controleert alle JavaScript en slash commands;
7. installeert de bot als systemd-service.

Wanneer je nog geen geldige `.env` hebt, stopt het script veilig en opent het
geen bot met lege tokens. Vul dan in:

```bash
nano /root/helixcraft-bot-v6.0.0/.env
```

en voer `./install-v6.sh` opnieuw uit.

## Beheer

Status:

```bash
systemctl status helixcraft-bot --no-pager
```

Herstart:

```bash
systemctl restart helixcraft-bot
```

Live logs:

```bash
journalctl -u helixcraft-bot -f
```

Diagnose:

```bash
/root/helixcraft-bot/diagnose.sh
```

## Belangrijk

- Plaats `.env` nooit op GitHub.
- Start niet daarnaast nog een tweede instantie met `npm start`.
- Maak na installatie een nieuw ticketpanel met `/ticket-panel-v2`.
- Stel Music Manager opnieuw in als het vaste voicekanaal niet meer bestaat.
