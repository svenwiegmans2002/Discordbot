# Helixcraft Bot v6.0.4 — Ticket UI Fix

## Aangepast

- paneltitel is nu alleen `Helixcraft Support`;
- het blok `Form mapping` is verwijderd;
- ieder ticket toont duidelijk de knop `📎 Upload`;
- het eerste ticketbericht legt uit hoe bestanden moeten worden toegevoegd;
- na klikken op Upload beschrijft de gebruiker het bestand;
- daarna plaatst de gebruiker het bestand als normale Discord-attachment in het ticketkanaal;
- de bot koppelt die upload automatisch aan het ticket.

Discord ondersteunt geen bestandsveld in modals. Daarom is de uploadflow:

```text
Upload-knop → korte beschrijving → bestand uploaden in ticketkanaal
```

## Patch installeren

```bash
cd /root/helixcraft-bot-v6.0.4-ticket-upload-ui-fix
chmod +x apply-v6.0.4-ticket-ui-fix.sh
./apply-v6.0.4-ticket-ui-fix.sh
```

Verwijder daarna het oude ticketpanelbericht en voer opnieuw uit:

```text
/ticket-panel-v2
```
