require('dotenv').config();

const { validateEnvironment } = require('./scripts/validate-env');
const { startBot } = require('./src/bot');
const { startDashboard } = require('./src/dashboard');

async function main() {
  validateEnvironment();

  const client = await startBot();
  await startDashboard(client);

  console.log('Helixcraft Bot v6.0.4 is running.');
}

main().catch(error => {
  console.error('Fatal startup error:', error);
  process.exitCode = 1;
});
