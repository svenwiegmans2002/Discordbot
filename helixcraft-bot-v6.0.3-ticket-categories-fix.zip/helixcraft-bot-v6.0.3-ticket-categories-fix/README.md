# Helixcraft Bot v6.0.3 — Ticket Category Fix

Deze versie herstelt het ticketpanel wanneer een oudere dashboardconfiguratie
de standaardcategorieën overschreef.

## Gegarandeerde categorieën

Deze vijf categorieën zijn altijd aanwezig:

- 🛟 Support
- 🐛 Bug Report
- 🛒 Purchase
- ⚖️ Appeal
- 📝 Apply

Custom categorieën worden alleen aanvullend toegevoegd.

## Unieke formulieren

Iedere categorie gebruikt gegarandeerd een eigen formulier:

- Support: probleem, eerdere stappen en gewenste oplossing
- Bug Report: reproductiestappen, verwacht gedrag en omgeving
- Purchase: product, orderreferentie en aankoopprobleem
- Appeal: strafdetails, bezwaarreden, bewijs en preventie
- Apply: positie, ervaring, motivatie, beschikbaarheid en portfolio

Oude ticketpanelen met numerieke categorie-ID's worden voor compatibiliteit
herkend, maar maak na installatie een nieuw panel voor de juiste labels en
opties.

De uploadknop heet zoals gevraagd:

```text
📎 Upload
```

## Patch toepassen

```bash
cd /root/helixcraft-bot-v6.0.3-ticket-categories-fix
chmod +x apply-v6.0.3-ticket-fix.sh
./apply-v6.0.3-ticket-fix.sh
```

Daarna:

1. verwijder het oude ticketpanelbericht uit Discord;
2. voer `/ticket-panel-v2` opnieuw uit;
3. controleer dat de paneltitel `Ticket Forms v6.0.3` bevat.
