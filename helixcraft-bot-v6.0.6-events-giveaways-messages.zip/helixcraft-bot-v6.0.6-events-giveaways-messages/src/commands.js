const { SlashCommandBuilder, PermissionFlagsBits, ChannelType } = require('discord.js');
const C=[];
const add=x=>C.push(x);
add(new SlashCommandBuilder().setName('ping').setDescription('Check bot latency.'));
add(new SlashCommandBuilder().setName('help').setDescription('Show command categories.'));
add(
  new SlashCommandBuilder()
    .setName('say')
    .setDescription('Open a text editor and send a message as the bot.')
    .setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages)
    .addChannelOption(o =>
      o.setName('channel')
        .setDescription('Target text channel')
        .setRequired(false)
    )
);
add(new SlashCommandBuilder().setName('embed').setDescription('Send an embed.').setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages).addStringOption(o=>o.setName('title').setDescription('Title').setRequired(true)).addStringOption(o=>o.setName('description').setDescription('Description').setRequired(true)).addStringOption(o=>o.setName('color').setDescription('Hex color')).addChannelOption(o=>o.setName('channel').setDescription('Target channel')));
add(new SlashCommandBuilder().setName('setup').setDescription('Configure server modules.').setDefaultMemberPermissions(PermissionFlagsBits.Administrator)
 .addSubcommand(s=>s.setName('welcome').setDescription('Welcome system').addChannelOption(o=>o.setName('channel').setDescription('Welcome channel').setRequired(true)).addStringOption(o=>o.setName('message').setDescription('{member} {server} {count}').setRequired(true)).addRoleOption(o=>o.setName('autorole').setDescription('Optional autorole')))
 .addSubcommand(s=>s.setName('logging').setDescription('Logging channel').addChannelOption(o=>o.setName('channel').setDescription('Log channel').setRequired(true)))
 .addSubcommand(s=>s.setName('tickets').setDescription('Ticket settings').addChannelOption(o=>o.setName('category').setDescription('Ticket category').addChannelTypes(ChannelType.GuildCategory).setRequired(true)).addChannelOption(o=>o.setName('log_channel').setDescription('Transcript/log channel').setRequired(true)).addRoleOption(o=>o.setName('support_role').setDescription('Support role').setRequired(true)).addIntegerOption(o=>o.setName('auto_close_hours').setDescription('Auto close after inactivity').setMinValue(1).setMaxValue(720)))
 .addSubcommand(s=>s.setName('tempvoice').setDescription('Temporary voice settings').addChannelOption(o=>o.setName('lobby').setDescription('Join-to-create voice channel').addChannelTypes(ChannelType.GuildVoice).setRequired(true)).addChannelOption(o=>o.setName('category').setDescription('Voice category').addChannelTypes(ChannelType.GuildCategory).setRequired(true)))
 .addSubcommand(s=>s.setName('suggestions').setDescription('Suggestion channel').addChannelOption(o=>o.setName('channel').setDescription('Suggestion channel').setRequired(true)))
 .addSubcommand(s=>s.setName('warnings').setDescription('Warning escalation').addIntegerOption(o=>o.setName('threshold').setDescription('Warnings before timeout').setMinValue(1).setMaxValue(20).setRequired(true)).addIntegerOption(o=>o.setName('timeout_minutes').setDescription('Automatic timeout').setMinValue(1).setMaxValue(40320).setRequired(true))));
add(new SlashCommandBuilder().setName('verify-panel').setDescription('Create verification panel.').setDefaultMemberPermissions(PermissionFlagsBits.Administrator).addRoleOption(o=>o.setName('role').setDescription('Verified role').setRequired(true)).addStringOption(o=>o.setName('title').setDescription('Title')).addStringOption(o=>o.setName('description').setDescription('Description')));
add(new SlashCommandBuilder().setName('role-panel').setDescription('Create self-role panel.').setDefaultMemberPermissions(PermissionFlagsBits.ManageRoles).addStringOption(o=>o.setName('title').setDescription('Title').setRequired(true)).addStringOption(o=>o.setName('description').setDescription('Description').setRequired(true)).addRoleOption(o=>o.setName('role1').setDescription('Role 1').setRequired(true)).addRoleOption(o=>o.setName('role2').setDescription('Role 2')).addRoleOption(o=>o.setName('role3').setDescription('Role 3')).addRoleOption(o=>o.setName('role4').setDescription('Role 4')).addRoleOption(o=>o.setName('role5').setDescription('Role 5')));
add(new SlashCommandBuilder().setName('warn').setDescription('Warn a member.').setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers).addUserOption(o=>o.setName('user').setDescription('User').setRequired(true)).addStringOption(o=>o.setName('reason').setDescription('Reason').setRequired(true)).addIntegerOption(o=>o.setName('points').setDescription('Penalty points').setMinValue(1).setMaxValue(10)));
add(new SlashCommandBuilder().setName('warnings').setDescription('View warnings.').setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers).addUserOption(o=>o.setName('user').setDescription('User').setRequired(true)));
add(new SlashCommandBuilder().setName('unwarn').setDescription('Remove warning by ID.').setDefaultMemberPermissions(PermissionFlagsBits.ModerateMembers).addStringOption(o=>o.setName('warning_id').setDescription('Warning ID').setRequired(true)));
add(new SlashCommandBuilder().setName('tempban').setDescription('Temporarily ban a user.').setDefaultMemberPermissions(PermissionFlagsBits.BanMembers).addUserOption(o=>o.setName('user').setDescription('User').setRequired(true)).addStringOption(o=>o.setName('duration').setDescription('10m, 2h, 3d').setRequired(true)).addStringOption(o=>o.setName('reason').setDescription('Reason')));
add(new SlashCommandBuilder().setName('softban').setDescription('Ban and immediately unban to clear messages.').setDefaultMemberPermissions(PermissionFlagsBits.BanMembers).addUserOption(o=>o.setName('user').setDescription('User').setRequired(true)).addStringOption(o=>o.setName('reason').setDescription('Reason')));
add(new SlashCommandBuilder().setName('slowmode').setDescription('Set channel slowmode.').setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels).addIntegerOption(o=>o.setName('seconds').setDescription('0-21600').setMinValue(0).setMaxValue(21600).setRequired(true)));
add(new SlashCommandBuilder().setName('ticket-panel').setDescription('Create ticket panel.').setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels));
add(new SlashCommandBuilder().setName('ticket').setDescription('Manage current ticket.').setDefaultMemberPermissions(PermissionFlagsBits.ManageChannels).addSubcommand(s=>s.setName('claim').setDescription('Claim ticket')).addSubcommand(s=>s.setName('unclaim').setDescription('Unclaim ticket')).addSubcommand(s=>s.setName('close').setDescription('Close with transcript')));

add(new SlashCommandBuilder()
 .setName('event')
 .setDescription('Create and manage Discord server events.')
 .setDefaultMemberPermissions(PermissionFlagsBits.ManageEvents)
 .addSubcommand(s=>s
  .setName('create')
  .setDescription('Create a Discord scheduled event')
  .addStringOption(o=>o.setName('name').setDescription('Event name').setMaxLength(100).setRequired(true))
  .addStringOption(o=>o.setName('description').setDescription('Event description').setMaxLength(1000).setRequired(true))
  .addStringOption(o=>o.setName('start').setDescription('ISO date/time, e.g. 2026-07-12T20:00:00+02:00').setRequired(true))
  .addStringOption(o=>o.setName('end').setDescription('Required for external events; ISO date/time'))
  .addStringOption(o=>o.setName('type').setDescription('Event type').setRequired(true).addChoices(
   {name:'Voice channel',value:'voice'},
   {name:'External location',value:'external'}
  ))
  .addChannelOption(o=>o.setName('channel').setDescription('Voice channel').addChannelTypes(ChannelType.GuildVoice,ChannelType.GuildStageVoice))
  .addStringOption(o=>o.setName('location').setDescription('External location or URL').setMaxLength(100)))
 .addSubcommand(s=>s.setName('list').setDescription('List scheduled events'))
 .addSubcommand(s=>s
  .setName('edit')
  .setDescription('Edit a scheduled event')
  .addStringOption(o=>o.setName('id').setDescription('Discord scheduled event ID').setRequired(true))
  .addStringOption(o=>o.setName('name').setDescription('New event name').setMaxLength(100))
  .addStringOption(o=>o.setName('description').setDescription('New description').setMaxLength(1000))
  .addStringOption(o=>o.setName('start').setDescription('New ISO start date/time'))
  .addStringOption(o=>o.setName('end').setDescription('New ISO end date/time'))
  .addChannelOption(o=>o.setName('channel').setDescription('New voice channel').addChannelTypes(ChannelType.GuildVoice,ChannelType.GuildStageVoice))
  .addStringOption(o=>o.setName('location').setDescription('New external location').setMaxLength(100)))
 .addSubcommand(s=>s.setName('start').setDescription('Start a scheduled event now').addStringOption(o=>o.setName('id').setDescription('Event ID').setRequired(true)))
 .addSubcommand(s=>s.setName('cancel').setDescription('Cancel a scheduled event').addStringOption(o=>o.setName('id').setDescription('Event ID').setRequired(true)))
 .addSubcommand(s=>s.setName('delete').setDescription('Delete a scheduled event').addStringOption(o=>o.setName('id').setDescription('Event ID').setRequired(true))));

add(new SlashCommandBuilder().setName('giveaway').setDescription('Manage giveaways.').setDefaultMemberPermissions(PermissionFlagsBits.ManageGuild)
 .addSubcommand(s=>s.setName('start').setDescription('Start giveaway').addStringOption(o=>o.setName('prize').setDescription('Prize').setRequired(true)).addStringOption(o=>o.setName('duration').setDescription('10m, 2h, 3d').setRequired(true)).addIntegerOption(o=>o.setName('winners').setDescription('Winners').setMinValue(1).setMaxValue(20).setRequired(true)).addRoleOption(o=>o.setName('required_role').setDescription('Required role')).addRoleOption(o=>o.setName('bonus_role').setDescription('Bonus entry role')).addIntegerOption(o=>o.setName('min_account_days').setDescription('Minimum account age')).addIntegerOption(o=>o.setName('min_member_days').setDescription('Minimum server membership')).addChannelOption(o=>o.setName('channel').setDescription('Target channel')))
 .addSubcommand(s=>s.setName('list').setDescription('List giveaways')).addSubcommand(s=>s.setName('end').setDescription('End giveaway').addStringOption(o=>o.setName('id').setDescription('Giveaway ID').setRequired(true))).addSubcommand(s=>s.setName('reroll').setDescription('Reroll').addStringOption(o=>o.setName('id').setDescription('Giveaway ID').setRequired(true))).addSubcommand(s=>s.setName('pause').setDescription('Pause').addStringOption(o=>o.setName('id').setDescription('Giveaway ID').setRequired(true))).addSubcommand(s=>s.setName('resume').setDescription('Resume').addStringOption(o=>o.setName('id').setDescription('Giveaway ID').setRequired(true))));
add(new SlashCommandBuilder().setName('sticky').setDescription('Manage sticky message.').setDefaultMemberPermissions(PermissionFlagsBits.ManageMessages).addSubcommand(s=>s.setName('set').setDescription('Set sticky').addStringOption(o=>o.setName('message').setDescription('Message').setRequired(true))).addSubcommand(s=>s.setName('remove').setDescription('Remove sticky')));
add(new SlashCommandBuilder().setName('suggest').setDescription('Submit a suggestion.').addStringOption(o=>o.setName('suggestion').setDescription('Suggestion').setRequired(true)));
add(new SlashCommandBuilder().setName('backup').setDescription('Server backup snapshots.').setDefaultMemberPermissions(PermissionFlagsBits.Administrator).addSubcommand(s=>s.setName('create').setDescription('Create snapshot')).addSubcommand(s=>s.setName('list').setDescription('List snapshots')));

add(new SlashCommandBuilder().setName('play').setDescription('Play or queue music.').addStringOption(o=>o.setName('query').setDescription('URL or search query').setRequired(true)));
add(new SlashCommandBuilder().setName('pause').setDescription('Pause music.'));
add(new SlashCommandBuilder().setName('resume').setDescription('Resume music.'));
add(new SlashCommandBuilder().setName('skip').setDescription('Skip the current track.'));
add(new SlashCommandBuilder().setName('stop').setDescription('Stop music and clear the queue.'));
add(new SlashCommandBuilder().setName('queue').setDescription('Show the music queue.'));
add(new SlashCommandBuilder().setName('nowplaying').setDescription('Show the current track.'));
add(new SlashCommandBuilder().setName('volume').setDescription('Set music volume.').addIntegerOption(o=>o.setName('percent').setDescription('0-200').setMinValue(0).setMaxValue(200).setRequired(true)));


add(new SlashCommandBuilder().setName('loop').setDescription('Set music loop mode.').addStringOption(o=>o.setName('mode').setDescription('Loop mode').setRequired(true).addChoices({name:'Off',value:'off'},{name:'Track',value:'track'},{name:'Queue',value:'queue'})));
add(new SlashCommandBuilder().setName('shuffle').setDescription('Toggle music shuffle.'));
add(new SlashCommandBuilder().setName('autoplay').setDescription('Toggle related-track autoplay.'));
add(new SlashCommandBuilder().setName('equalizer').setDescription('Set equalizer preset.').addStringOption(o=>o.setName('preset').setDescription('Preset').setRequired(true).addChoices({name:'Flat',value:'flat'},{name:'Bass',value:'bass'},{name:'Treble',value:'treble'},{name:'Vocal',value:'vocal'},{name:'Nightcore',value:'nightcore'})));
add(new SlashCommandBuilder().setName('lyrics').setDescription('Show lyrics for the current track.'));

module.exports=C.map(c=>c.toJSON());
