# Helixcraft Bot v6.0.6

## Events

- `/event create`
- `/event list`
- `/event edit`
- `/event start`
- `/event cancel`
- `/event delete`

The Event Manager dashboard now shows the number of interested participants
for every Discord Scheduled Event.

Each event card can also post a dedicated event announcement message to a
selected text channel. That message includes:

- event name;
- description;
- start and end time;
- location;
- current interested-participant count;
- button linking to the Discord Scheduled Event.

## Giveaways

The Giveaway Manager dashboard now shows the number of unique participants.

Each giveaway card includes:

- Post / refresh message;
- Open message;
- Pause;
- Resume;
- End now;
- Reroll;
- Delete.

The giveaway message shows the live entry count whenever it is refreshed.

## Install

```bash
cd /root/helixcraft-bot-v6.0.6-events-giveaways-messages
chmod +x apply-v6.0.6.sh
./apply-v6.0.6.sh
```

Slash commands are deployed automatically when the bot restarts.
