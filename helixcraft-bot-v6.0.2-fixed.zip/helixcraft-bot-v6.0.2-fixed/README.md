# Helixcraft Bot v6.0.2

Deze volledige v6-versie bevat categorie-specifieke ticketformulieren en een
bewijsuploadworkflow.

## Ticketcategorieën

- 🛟 Support
- 🐛 Bug Report
- 🛒 Purchase
- ⚖️ Appeal
- 📝 Apply

Iedere categorie opent een eigen formulier.

## Evidence uploads

Elk ticket bevat een knop:

```text
📎 Upload
```

De gebruiker beschrijft eerst wat het bestand bewijst. Daarna uploadt die
binnen tien minuten één of meer bestanden in het ticketkanaal. De bot:

- koppelt de upload aan het ticket;
- toont het aantal bewijsbestanden in de ticketheader;
- bewaart bestandsnaam, URL, uploader, tijdstip en beschrijving;
- neemt de gewone uploadberichten mee in het HTML-transcript;
- stuurt bij sluiten ook een `evidence.json`-index naar het ticketlogkanaal.

Ondersteunde bestandstypen:

- PNG, JPG, JPEG, GIF, WEBP
- MP4, MOV, WEBM
- PDF
- TXT, LOG, JSON, YAML
- ZIP, RAR, 7Z

## Privacywaarschuwing

Overal wordt in het Engels getoond:

> Your responses will be submitted to Helixcraft Bot. Do not share passwords,
> payment details, recovery codes, API keys, tokens, or other sensitive
> information.

## Installeren

```bash
cd /root/helixcraft-bot-v6.0.2
chmod +x install-v6.sh
./install-v6.sh
```

Het installatiescript behoudt je bestaande `.env`, data en transcripts.

Maak daarna een nieuw ticketpanel:

```text
/ticket-panel-v2
```

Verwijder het oude panelbericht uit Discord.


## v6.0.2 startup fix

The ticket upload listener is registered inside `installV4(client)`. This fixes:

```text
ReferenceError: client is not defined
```
