@echo off
python -m dashboard.app
pause
