import asyncio
import json
import logging
import os
from pathlib import Path

import discord
from discord.ext import commands
from dotenv import load_dotenv

from utils.db import init_db

logging.basicConfig(level=logging.INFO)

load_dotenv()

with open("config.json", "r", encoding="utf-8") as f:
    CONFIG = json.load(f)

intents = discord.Intents.default()
intents.members = True
intents.message_content = True
intents.guilds = True
intents.messages = True

class AllInOneBot(commands.Bot):
    def __init__(self):
        super().__init__(
            command_prefix=CONFIG.get("default_prefix", "!"),
            intents=intents,
            help_command=None,
            activity=discord.Game(CONFIG.get("activity", "All-in-one bot")),
        )

    async def setup_hook(self):
        await init_db()
        for file in Path("cogs").glob("*.py"):
            if file.name.startswith("_"):
                continue
            await self.load_extension(f"cogs.{file.stem}")
        await self.tree.sync()
        logging.info("Slash commands gesynchroniseerd.")

    async def on_ready(self):
        logging.info("Ingelogd als %s (%s)", self.user, self.user.id)

bot = AllInOneBot()

token = os.getenv("DISCORD_TOKEN")
if not token:
    raise RuntimeError("DISCORD_TOKEN ontbreekt. Maak een .env bestand op basis van .env.example.")

asyncio.run(bot.start(token))
