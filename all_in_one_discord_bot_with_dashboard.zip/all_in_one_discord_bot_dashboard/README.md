# All-in-one Discord Bot

Een modulaire Discord bot met:
- Moderatie: ban, kick, timeout, warn, purge
- Logging: joins, leaves, message delete/edit, mod logs
- Tickets
- Welkomsberichten
- Autorole
- Levels / XP
- Giveaways
- Serverconfig via slash commands

## Installatie

1. Installeer Python 3.11 of nieuwer.
2. Pak deze map uit.
3. Installeer packages:

```bash
pip install -r requirements.txt
```

4. Maak een `.env` bestand:

```bash
cp .env.example .env
```

5. Zet je Discord token in `.env`.

6. Start de bot:

```bash
python main.py
```

## Discord Developer Portal instellingen

Zet bij je bot aan:
- SERVER MEMBERS INTENT
- MESSAGE CONTENT INTENT

Invite de bot met scopes:
- `bot`
- `applications.commands`

Bot permissions:
- Administrator voor testen, of minimaal: Manage Roles, Manage Channels, Manage Messages, Kick Members, Ban Members, Moderate Members, Send Messages, View Channels, Read Message History.

## Eerste setup in je server

Gebruik slash commands:

```text
/setup logging #kanaal
/setup welcome #kanaal Welkom {member} in {server}!
/setup autorole @role
/setup tickets #categorie
```

Daarna kun je o.a. gebruiken:

```text
/ban
/kick
/timeout
/warn
/warnings
/purge
/ticketpanel
/level
/leaderboard
/giveaway
```


## Dashboard starten

Het dashboard zit nu in `/dashboard`.

### Extra Discord Developer Portal setup

Ga naar je application > OAuth2 en zet deze redirect URL erin:

```text
http://localhost:5000/callback
```

Vul daarna in `.env`:

```text
DISCORD_CLIENT_ID=...
DISCORD_CLIENT_SECRET=...
DISCORD_REDIRECT_URI=http://localhost:5000/callback
FLASK_SECRET_KEY=een_lange_random_tekst
```

Start de bot:

```bash
python main.py
```

Start in een tweede terminal het dashboard:

```bash
python -m dashboard.app
```

Open daarna:

```text
http://localhost:5000
```

### Dashboard functies

- Discord OAuth2 login
- Alleen servers waar jij Manage Server/Admin hebt
- Alleen servers waar de bot ook in zit
- Logkanaal instellen
- Welkomskanaal en welkomstbericht instellen
- Autorole instellen
- Ticketcategorie en supportrol instellen
- Warnings bekijken
- Leaderboard bekijken

Voor productiehosting moet je HTTPS gebruiken en `DISCORD_REDIRECT_URI` aanpassen naar je domein.
