import discord
from discord import app_commands
from discord.ext import commands
from utils.db import set_config, get_config

class Setup(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    setup_group = app_commands.Group(name="setup", description="Configureer de bot voor deze server.")

    async def admin_only(self, interaction: discord.Interaction) -> bool:
        return interaction.user.guild_permissions.administrator

    @setup_group.command(name="logging", description="Stel het logkanaal in.")
    @app_commands.describe(channel="Kanaal voor logs")
    async def logging_channel(self, interaction: discord.Interaction, channel: discord.TextChannel):
        if not await self.admin_only(interaction):
            return await interaction.response.send_message("Alleen admins mogen dit.", ephemeral=True)
        await set_config(interaction.guild_id, log_channel_id=channel.id)
        await interaction.response.send_message(f"Logkanaal ingesteld op {channel.mention}.", ephemeral=True)

    @setup_group.command(name="welcome", description="Stel welkomskanaal en bericht in.")
    async def welcome(self, interaction: discord.Interaction, channel: discord.TextChannel, message: str):
        if not await self.admin_only(interaction):
            return await interaction.response.send_message("Alleen admins mogen dit.", ephemeral=True)
        await set_config(interaction.guild_id, welcome_channel_id=channel.id, welcome_message=message)
        await interaction.response.send_message("Welkom ingesteld. Gebruik {member} en {server} als placeholders.", ephemeral=True)

    @setup_group.command(name="autorole", description="Stel autorole in voor nieuwe leden.")
    async def autorole(self, interaction: discord.Interaction, role: discord.Role):
        if not await self.admin_only(interaction):
            return await interaction.response.send_message("Alleen admins mogen dit.", ephemeral=True)
        await set_config(interaction.guild_id, autorole_id=role.id)
        await interaction.response.send_message(f"Autorole ingesteld op {role.mention}.", ephemeral=True)

    @setup_group.command(name="tickets", description="Stel ticketcategorie en optionele supportrol in.")
    async def tickets(self, interaction: discord.Interaction, category: discord.CategoryChannel, support_role: discord.Role | None = None):
        if not await self.admin_only(interaction):
            return await interaction.response.send_message("Alleen admins mogen dit.", ephemeral=True)
        await set_config(
            interaction.guild_id,
            ticket_category_id=category.id,
            ticket_support_role_id=support_role.id if support_role else None,
        )
        await interaction.response.send_message("Tickets ingesteld.", ephemeral=True)

    @app_commands.command(name="config", description="Bekijk botconfig voor deze server.")
    async def config(self, interaction: discord.Interaction):
        cfg = await get_config(interaction.guild_id)
        embed = discord.Embed(title="Serverconfig", color=discord.Color.blurple())
        for k, v in cfg.items():
            embed.add_field(name=k, value=str(v), inline=False)
        await interaction.response.send_message(embed=embed, ephemeral=True)

async def setup(bot):
    await bot.add_cog(Setup(bot))
