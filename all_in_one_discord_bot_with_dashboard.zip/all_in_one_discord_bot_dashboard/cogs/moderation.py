import datetime
import discord
from discord import app_commands
from discord.ext import commands
import aiosqlite

from utils.db import DB_PATH, get_config
from utils.timeparse import parse_duration

async def send_log(guild: discord.Guild, text: str):
    cfg = await get_config(guild.id)
    channel_id = cfg.get("log_channel_id")
    if channel_id:
        channel = guild.get_channel(channel_id)
        if channel:
            await channel.send(text)

class Moderation(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="kick", description="Kick een lid.")
    async def kick(self, interaction: discord.Interaction, member: discord.Member, reason: str = "Geen reden opgegeven"):
        if not interaction.user.guild_permissions.kick_members:
            return await interaction.response.send_message("Je mist Kick Members.", ephemeral=True)
        await member.kick(reason=reason)
        await interaction.response.send_message(f"{member} is gekickt. Reden: {reason}")
        await send_log(interaction.guild, f"👢 {member} gekickt door {interaction.user}. Reden: {reason}")

    @app_commands.command(name="ban", description="Ban een lid.")
    async def ban(self, interaction: discord.Interaction, member: discord.Member, reason: str = "Geen reden opgegeven"):
        if not interaction.user.guild_permissions.ban_members:
            return await interaction.response.send_message("Je mist Ban Members.", ephemeral=True)
        await member.ban(reason=reason)
        await interaction.response.send_message(f"{member} is geband. Reden: {reason}")
        await send_log(interaction.guild, f"🔨 {member} geband door {interaction.user}. Reden: {reason}")

    @app_commands.command(name="timeout", description="Geef een timeout. Voorbeeld duur: 10m, 2h, 1d.")
    async def timeout(self, interaction: discord.Interaction, member: discord.Member, duration: str, reason: str = "Geen reden opgegeven"):
        if not interaction.user.guild_permissions.moderate_members:
            return await interaction.response.send_message("Je mist Moderate Members.", ephemeral=True)
        seconds = parse_duration(duration)
        until = discord.utils.utcnow() + datetime.timedelta(seconds=seconds)
        await member.timeout(until, reason=reason)
        await interaction.response.send_message(f"{member.mention} heeft timeout voor {duration}.")
        await send_log(interaction.guild, f"⏱️ {member} timeout door {interaction.user} voor {duration}. Reden: {reason}")

    @app_commands.command(name="purge", description="Verwijder berichten uit dit kanaal.")
    async def purge(self, interaction: discord.Interaction, amount: app_commands.Range[int, 1, 100]):
        if not interaction.user.guild_permissions.manage_messages:
            return await interaction.response.send_message("Je mist Manage Messages.", ephemeral=True)
        await interaction.response.defer(ephemeral=True)
        deleted = await interaction.channel.purge(limit=amount)
        await interaction.followup.send(f"{len(deleted)} berichten verwijderd.", ephemeral=True)
        await send_log(interaction.guild, f"🧹 {len(deleted)} berichten verwijderd in {interaction.channel.mention} door {interaction.user}.")

    @app_commands.command(name="warn", description="Geef een waarschuwing.")
    async def warn(self, interaction: discord.Interaction, member: discord.Member, reason: str):
        if not interaction.user.guild_permissions.moderate_members:
            return await interaction.response.send_message("Je mist Moderate Members.", ephemeral=True)
        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute(
                "INSERT INTO warnings (guild_id, user_id, moderator_id, reason) VALUES (?, ?, ?, ?)",
                (interaction.guild_id, member.id, interaction.user.id, reason),
            )
            await db.commit()
        await interaction.response.send_message(f"{member.mention} gewaarschuwd: {reason}")
        await send_log(interaction.guild, f"⚠️ {member} gewaarschuwd door {interaction.user}. Reden: {reason}")

    @app_commands.command(name="warnings", description="Bekijk waarschuwingen van een lid.")
    async def warnings(self, interaction: discord.Interaction, member: discord.Member):
        async with aiosqlite.connect(DB_PATH) as db:
            db.row_factory = aiosqlite.Row
            cur = await db.execute(
                "SELECT * FROM warnings WHERE guild_id=? AND user_id=? ORDER BY id DESC LIMIT 10",
                (interaction.guild_id, member.id),
            )
            rows = await cur.fetchall()
        if not rows:
            return await interaction.response.send_message(f"{member.mention} heeft geen waarschuwingen.", ephemeral=True)
        embed = discord.Embed(title=f"Waarschuwingen voor {member}", color=discord.Color.orange())
        for row in rows:
            embed.add_field(name=f"#{row['id']}", value=f"{row['reason']} — mod: <@{row['moderator_id']}>", inline=False)
        await interaction.response.send_message(embed=embed, ephemeral=True)

async def setup(bot):
    await bot.add_cog(Moderation(bot))
