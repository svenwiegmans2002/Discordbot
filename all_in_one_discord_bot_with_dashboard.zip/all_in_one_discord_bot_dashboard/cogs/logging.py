import discord
from discord.ext import commands
from utils.db import get_config

async def log(guild: discord.Guild, text: str):
    cfg = await get_config(guild.id)
    channel_id = cfg.get("log_channel_id")
    if not channel_id:
        return
    channel = guild.get_channel(channel_id)
    if channel:
        await channel.send(text)

class Logging(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_member_join(self, member: discord.Member):
        cfg = await get_config(member.guild.id)
        if cfg.get("autorole_id"):
            role = member.guild.get_role(cfg["autorole_id"])
            if role:
                try:
                    await member.add_roles(role, reason="Autorole")
                except discord.Forbidden:
                    pass

        if cfg.get("welcome_channel_id"):
            channel = member.guild.get_channel(cfg["welcome_channel_id"])
            if channel:
                msg = (cfg.get("welcome_message") or "Welkom {member} in {server}!").format(
                    member=member.mention,
                    server=member.guild.name,
                )
                await channel.send(msg)

        await log(member.guild, f"✅ {member} is gejoind.")

    @commands.Cog.listener()
    async def on_member_remove(self, member: discord.Member):
        await log(member.guild, f"❌ {member} heeft de server verlaten.")

    @commands.Cog.listener()
    async def on_message_delete(self, message: discord.Message):
        if not message.guild or message.author.bot:
            return
        content = message.content[:1000] if message.content else "[geen tekst]"
        await log(message.guild, f"🗑️ Bericht verwijderd in {message.channel.mention} door {message.author}: {content}")

    @commands.Cog.listener()
    async def on_message_edit(self, before: discord.Message, after: discord.Message):
        if not before.guild or before.author.bot or before.content == after.content:
            return
        await log(before.guild, f"✏️ Bericht aangepast door {before.author} in {before.channel.mention}\nVoor: {before.content[:500]}\nNa: {after.content[:500]}")

async def setup(bot):
    await bot.add_cog(Logging(bot))
