import discord
from discord import app_commands
from discord.ext import commands

class Utility(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @app_commands.command(name="ping", description="Check of de bot werkt.")
    async def ping(self, interaction: discord.Interaction):
        await interaction.response.send_message(f"Pong! Latency: {round(self.bot.latency * 1000)}ms")

    @app_commands.command(name="serverinfo", description="Bekijk serverinformatie.")
    async def serverinfo(self, interaction: discord.Interaction):
        g = interaction.guild
        embed = discord.Embed(title=g.name, color=discord.Color.blurple())
        embed.add_field(name="Leden", value=str(g.member_count))
        embed.add_field(name="Owner", value=str(g.owner))
        embed.add_field(name="Aangemaakt", value=f"<t:{int(g.created_at.timestamp())}:D>")
        if g.icon:
            embed.set_thumbnail(url=g.icon.url)
        await interaction.response.send_message(embed=embed)

    @app_commands.command(name="userinfo", description="Bekijk gebruikersinformatie.")
    async def userinfo(self, interaction: discord.Interaction, member: discord.Member | None = None):
        member = member or interaction.user
        embed = discord.Embed(title=str(member), color=discord.Color.blurple())
        embed.add_field(name="ID", value=str(member.id), inline=False)
        embed.add_field(name="Joined", value=f"<t:{int(member.joined_at.timestamp())}:D>" if member.joined_at else "Onbekend")
        embed.add_field(name="Account", value=f"<t:{int(member.created_at.timestamp())}:D>")
        embed.set_thumbnail(url=member.display_avatar.url)
        await interaction.response.send_message(embed=embed)

async def setup(bot):
    await bot.add_cog(Utility(bot))
