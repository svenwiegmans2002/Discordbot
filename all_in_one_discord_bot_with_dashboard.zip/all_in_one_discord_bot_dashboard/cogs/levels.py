import random
import time
import discord
from discord import app_commands
from discord.ext import commands
import aiosqlite

from utils.db import DB_PATH

def level_from_xp(xp: int) -> int:
    return int((xp / 100) ** 0.5)

def xp_for_level(level: int) -> int:
    return level * level * 100

class Levels(commands.Cog):
    def __init__(self, bot):
        self.bot = bot

    @commands.Cog.listener()
    async def on_message(self, message: discord.Message):
        if not message.guild or message.author.bot:
            return

        now = time.time()
        async with aiosqlite.connect(DB_PATH) as db:
            db.row_factory = aiosqlite.Row
            cur = await db.execute(
                "SELECT * FROM levels WHERE guild_id=? AND user_id=?",
                (message.guild.id, message.author.id),
            )
            row = await cur.fetchone()
            if row and now - row["last_xp_at"] < 60:
                return

            old_xp = row["xp"] if row else 0
            old_level = row["level"] if row else 0
            new_xp = old_xp + random.randint(8, 15)
            new_level = level_from_xp(new_xp)

            await db.execute(
                """
                INSERT INTO levels (guild_id, user_id, xp, level, last_xp_at)
                VALUES (?, ?, ?, ?, ?)
                ON CONFLICT(guild_id, user_id)
                DO UPDATE SET xp=excluded.xp, level=excluded.level, last_xp_at=excluded.last_xp_at
                """,
                (message.guild.id, message.author.id, new_xp, new_level, now),
            )
            await db.commit()

        if new_level > old_level:
            await message.channel.send(f"🎉 {message.author.mention} is nu level {new_level}!")

    @app_commands.command(name="level", description="Bekijk je level of dat van iemand anders.")
    async def level(self, interaction: discord.Interaction, member: discord.Member | None = None):
        member = member or interaction.user
        async with aiosqlite.connect(DB_PATH) as db:
            db.row_factory = aiosqlite.Row
            cur = await db.execute("SELECT * FROM levels WHERE guild_id=? AND user_id=?", (interaction.guild_id, member.id))
            row = await cur.fetchone()
        xp = row["xp"] if row else 0
        lvl = row["level"] if row else 0
        needed = xp_for_level(lvl + 1)
        await interaction.response.send_message(f"{member.mention}: level {lvl}, XP {xp}/{needed}")

    @app_commands.command(name="leaderboard", description="Bekijk de top 10 levels.")
    async def leaderboard(self, interaction: discord.Interaction):
        async with aiosqlite.connect(DB_PATH) as db:
            db.row_factory = aiosqlite.Row
            cur = await db.execute(
                "SELECT user_id, xp, level FROM levels WHERE guild_id=? ORDER BY xp DESC LIMIT 10",
                (interaction.guild_id,),
            )
            rows = await cur.fetchall()
        if not rows:
            return await interaction.response.send_message("Nog geen XP data.")
        desc = "\n".join(f"**{i+1}.** <@{r['user_id']}> — level {r['level']} ({r['xp']} XP)" for i, r in enumerate(rows))
        await interaction.response.send_message(embed=discord.Embed(title="Leaderboard", description=desc, color=discord.Color.gold()))

async def setup(bot):
    await bot.add_cog(Levels(bot))
