import asyncio
import random
import time
import discord
from discord import app_commands
from discord.ext import commands, tasks
import aiosqlite

from utils.db import DB_PATH
from utils.timeparse import parse_duration

GIVEAWAY_EMOJI = "🎉"

class Giveaways(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self.check_giveaways.start()

    def cog_unload(self):
        self.check_giveaways.cancel()

    @app_commands.command(name="giveaway", description="Start een giveaway.")
    async def giveaway(self, interaction: discord.Interaction, duration: str, winners: app_commands.Range[int, 1, 20], prize: str):
        if not interaction.user.guild_permissions.manage_guild:
            return await interaction.response.send_message("Je mist Manage Server.", ephemeral=True)

        seconds = parse_duration(duration)
        ends_at = time.time() + seconds
        embed = discord.Embed(
            title="🎉 Giveaway",
            description=f"Prijs: **{prize}**\nWinnaars: **{winners}**\nEindigt: <t:{int(ends_at)}:R>\n\nReageer met {GIVEAWAY_EMOJI} om mee te doen.",
            color=discord.Color.gold(),
        )
        await interaction.response.send_message(embed=embed)
        msg = await interaction.original_response()
        await msg.add_reaction(GIVEAWAY_EMOJI)

        async with aiosqlite.connect(DB_PATH) as db:
            await db.execute(
                "INSERT INTO giveaways (message_id, guild_id, channel_id, prize, winner_count, ends_at, host_id) VALUES (?, ?, ?, ?, ?, ?, ?)",
                (msg.id, interaction.guild_id, interaction.channel_id, prize, winners, ends_at, interaction.user.id),
            )
            await db.commit()

    @tasks.loop(seconds=30)
    async def check_giveaways(self):
        await self.bot.wait_until_ready()
        now = time.time()
        async with aiosqlite.connect(DB_PATH) as db:
            db.row_factory = aiosqlite.Row
            cur = await db.execute("SELECT * FROM giveaways WHERE ended=0 AND ends_at <= ?", (now,))
            rows = await cur.fetchall()

        for row in rows:
            guild = self.bot.get_guild(row["guild_id"])
            channel = guild.get_channel(row["channel_id"]) if guild else None
            if not channel:
                continue
            try:
                msg = await channel.fetch_message(row["message_id"])
            except discord.NotFound:
                continue

            users = []
            for reaction in msg.reactions:
                if str(reaction.emoji) == GIVEAWAY_EMOJI:
                    async for user in reaction.users():
                        if not user.bot:
                            users.append(user)

            if users:
                winners = random.sample(users, min(row["winner_count"], len(users)))
                text = ", ".join(w.mention for w in winners)
                await channel.send(f"🎉 Giveaway afgelopen! Prijs: **{row['prize']}**. Winnaar(s): {text}")
            else:
                await channel.send(f"Giveaway afgelopen voor **{row['prize']}**, maar niemand deed mee.")

            async with aiosqlite.connect(DB_PATH) as db:
                await db.execute("UPDATE giveaways SET ended=1 WHERE message_id=?", (row["message_id"],))
                await db.commit()

async def setup(bot):
    await bot.add_cog(Giveaways(bot))
