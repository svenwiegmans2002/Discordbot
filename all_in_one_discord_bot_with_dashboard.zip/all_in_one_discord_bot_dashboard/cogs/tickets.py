import discord
from discord import app_commands
from discord.ext import commands
from utils.db import get_config

class TicketView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Open ticket", style=discord.ButtonStyle.green, custom_id="ticket_open")
    async def open_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        cfg = await get_config(interaction.guild_id)
        category = interaction.guild.get_channel(cfg.get("ticket_category_id")) if cfg.get("ticket_category_id") else None
        support_role = interaction.guild.get_role(cfg.get("ticket_support_role_id")) if cfg.get("ticket_support_role_id") else None

        overwrites = {
            interaction.guild.default_role: discord.PermissionOverwrite(view_channel=False),
            interaction.user: discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True),
            interaction.guild.me: discord.PermissionOverwrite(view_channel=True, send_messages=True, manage_channels=True),
        }
        if support_role:
            overwrites[support_role] = discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True)

        name = f"ticket-{interaction.user.name}".lower().replace(" ", "-")[:90]
        channel = await interaction.guild.create_text_channel(name=name, category=category, overwrites=overwrites)
        await channel.send(f"{interaction.user.mention}, je ticket is geopend.", view=CloseTicketView())
        await interaction.response.send_message(f"Ticket geopend: {channel.mention}", ephemeral=True)

class CloseTicketView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)

    @discord.ui.button(label="Sluit ticket", style=discord.ButtonStyle.red, custom_id="ticket_close")
    async def close_ticket(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message("Ticket wordt gesloten...", ephemeral=True)
        await interaction.channel.delete(reason=f"Ticket gesloten door {interaction.user}")

class Tickets(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        bot.add_view(TicketView())
        bot.add_view(CloseTicketView())

    @app_commands.command(name="ticketpanel", description="Plaats een ticketpaneel.")
    async def ticketpanel(self, interaction: discord.Interaction):
        if not interaction.user.guild_permissions.manage_channels:
            return await interaction.response.send_message("Je mist Manage Channels.", ephemeral=True)
        embed = discord.Embed(title="Support ticket", description="Klik op de knop om een ticket te openen.", color=discord.Color.green())
        await interaction.response.send_message(embed=embed, view=TicketView())

async def setup(bot):
    await bot.add_cog(Tickets(bot))
