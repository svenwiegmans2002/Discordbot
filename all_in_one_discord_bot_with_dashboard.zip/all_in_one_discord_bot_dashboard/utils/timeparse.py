import re

def parse_duration(value: str) -> int:
    """
    Zet 10m, 2h, 3d om naar seconden.
    """
    value = value.strip().lower()
    match = re.fullmatch(r"(\d+)(s|m|h|d)", value)
    if not match:
        raise ValueError("Gebruik bijvoorbeeld 30s, 10m, 2h of 3d.")
    amount = int(match.group(1))
    unit = match.group(2)
    return amount * {"s": 1, "m": 60, "h": 3600, "d": 86400}[unit]
