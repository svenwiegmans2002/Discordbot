import os
import sqlite3
from pathlib import Path

import requests
from dotenv import load_dotenv
from flask import Flask, redirect, render_template, request, session, url_for, flash

load_dotenv()

BASE_DIR = Path(__file__).resolve().parent.parent
DB_PATH = BASE_DIR / "data" / "bot.db"

CLIENT_ID = os.getenv("DISCORD_CLIENT_ID")
CLIENT_SECRET = os.getenv("DISCORD_CLIENT_SECRET")
REDIRECT_URI = os.getenv("DISCORD_REDIRECT_URI", "http://localhost:5000/callback")
BOT_TOKEN = os.getenv("DISCORD_TOKEN")

API_BASE = "https://discord.com/api/v10"
OAUTH_AUTHORIZE = "https://discord.com/oauth2/authorize"
OAUTH_TOKEN = f"{API_BASE}/oauth2/token"

app = Flask(__name__)
app.secret_key = os.getenv("FLASK_SECRET_KEY", "change-me-now")

def db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def ensure_config(guild_id: int):
    with db() as conn:
        conn.execute(
            "INSERT OR IGNORE INTO guild_config (guild_id, welcome_message) VALUES (?, ?)",
            (guild_id, "Welkom {member} in {server}!"),
        )
        conn.commit()

def get_bot_guilds():
    if not BOT_TOKEN:
        return []
    r = requests.get(f"{API_BASE}/users/@me/guilds", headers={"Authorization": f"Bot {BOT_TOKEN}"}, timeout=15)
    if r.status_code != 200:
        return []
    return r.json()

def api_get(path, token=None, bot=False):
    headers = {}
    if bot:
        headers["Authorization"] = f"Bot {BOT_TOKEN}"
    elif token:
        headers["Authorization"] = f"Bearer {token}"
    r = requests.get(f"{API_BASE}{path}", headers=headers, timeout=15)
    r.raise_for_status()
    return r.json()

def require_login():
    return "access_token" in session

def user_guilds():
    if not require_login():
        return []
    guilds = api_get("/users/@me/guilds", token=session["access_token"])
    bot_guild_ids = {str(g["id"]) for g in get_bot_guilds()}
    manageable = []
    for g in guilds:
        perms = int(g.get("permissions", 0))
        is_admin = bool(perms & 0x8)
        manage_guild = bool(perms & 0x20)
        if str(g["id"]) in bot_guild_ids and (is_admin or manage_guild):
            manageable.append(g)
    return manageable

def check_guild_access(guild_id: str):
    return any(str(g["id"]) == str(guild_id) for g in user_guilds())

@app.route("/")
def index():
    if not require_login():
        return render_template("index.html")
    return redirect(url_for("servers"))

@app.route("/login")
def login():
    if not CLIENT_ID:
        return "DISCORD_CLIENT_ID ontbreekt in .env", 500
    scope = "identify guilds"
    url = (
        f"{OAUTH_AUTHORIZE}?client_id={CLIENT_ID}"
        f"&redirect_uri={requests.utils.quote(REDIRECT_URI, safe='')}"
        f"&response_type=code&scope={requests.utils.quote(scope)}"
    )
    return redirect(url)

@app.route("/callback")
def callback():
    code = request.args.get("code")
    if not code:
        return redirect(url_for("index"))
    data = {
        "client_id": CLIENT_ID,
        "client_secret": CLIENT_SECRET,
        "grant_type": "authorization_code",
        "code": code,
        "redirect_uri": REDIRECT_URI,
    }
    headers = {"Content-Type": "application/x-www-form-urlencoded"}
    r = requests.post(OAUTH_TOKEN, data=data, headers=headers, timeout=15)
    r.raise_for_status()
    payload = r.json()
    session["access_token"] = payload["access_token"]
    session["refresh_token"] = payload.get("refresh_token")
    session["user"] = api_get("/users/@me", token=session["access_token"])
    return redirect(url_for("servers"))

@app.route("/logout")
def logout():
    session.clear()
    return redirect(url_for("index"))

@app.route("/servers")
def servers():
    if not require_login():
        return redirect(url_for("login"))
    return render_template("servers.html", guilds=user_guilds(), user=session.get("user"))

@app.route("/server/<guild_id>", methods=["GET", "POST"])
def server_dashboard(guild_id):
    if not require_login():
        return redirect(url_for("login"))
    if not check_guild_access(guild_id):
        return "Geen toegang tot deze server of bot zit niet in deze server.", 403

    ensure_config(int(guild_id))

    if request.method == "POST":
        fields = {
            "log_channel_id": request.form.get("log_channel_id") or None,
            "welcome_channel_id": request.form.get("welcome_channel_id") or None,
            "welcome_message": request.form.get("welcome_message") or "Welkom {member} in {server}!",
            "autorole_id": request.form.get("autorole_id") or None,
            "ticket_category_id": request.form.get("ticket_category_id") or None,
            "ticket_support_role_id": request.form.get("ticket_support_role_id") or None,
        }
        with db() as conn:
            conn.execute(
                """
                UPDATE guild_config
                SET log_channel_id=?, welcome_channel_id=?, welcome_message=?,
                    autorole_id=?, ticket_category_id=?, ticket_support_role_id=?
                WHERE guild_id=?
                """,
                (
                    fields["log_channel_id"],
                    fields["welcome_channel_id"],
                    fields["welcome_message"],
                    fields["autorole_id"],
                    fields["ticket_category_id"],
                    fields["ticket_support_role_id"],
                    int(guild_id),
                ),
            )
            conn.commit()
        flash("Instellingen opgeslagen.")
        return redirect(url_for("server_dashboard", guild_id=guild_id))

    guild = api_get(f"/guilds/{guild_id}", bot=True)
    channels = api_get(f"/guilds/{guild_id}/channels", bot=True)
    roles = api_get(f"/guilds/{guild_id}/roles", bot=True)

    text_channels = [c for c in channels if c["type"] == 0]
    categories = [c for c in channels if c["type"] == 4]
    roles = sorted(roles, key=lambda r: r.get("position", 0), reverse=True)

    with db() as conn:
        cfg = conn.execute("SELECT * FROM guild_config WHERE guild_id=?", (int(guild_id),)).fetchone()
        warning_count = conn.execute("SELECT COUNT(*) c FROM warnings WHERE guild_id=?", (int(guild_id),)).fetchone()["c"]
        level_count = conn.execute("SELECT COUNT(*) c FROM levels WHERE guild_id=?", (int(guild_id),)).fetchone()["c"]
        giveaway_count = conn.execute("SELECT COUNT(*) c FROM giveaways WHERE guild_id=?", (int(guild_id),)).fetchone()["c"]

    return render_template(
        "dashboard.html",
        guild=guild,
        cfg=cfg,
        text_channels=text_channels,
        categories=categories,
        roles=roles,
        warning_count=warning_count,
        level_count=level_count,
        giveaway_count=giveaway_count,
        user=session.get("user"),
    )

@app.route("/server/<guild_id>/warnings")
def warnings(guild_id):
    if not require_login():
        return redirect(url_for("login"))
    if not check_guild_access(guild_id):
        return "Geen toegang.", 403
    with db() as conn:
        rows = conn.execute(
            "SELECT * FROM warnings WHERE guild_id=? ORDER BY id DESC LIMIT 100",
            (int(guild_id),)
        ).fetchall()
    return render_template("warnings.html", rows=rows, guild_id=guild_id)

@app.route("/server/<guild_id>/levels")
def levels(guild_id):
    if not require_login():
        return redirect(url_for("login"))
    if not check_guild_access(guild_id):
        return "Geen toegang.", 403
    with db() as conn:
        rows = conn.execute(
            "SELECT * FROM levels WHERE guild_id=? ORDER BY xp DESC LIMIT 100",
            (int(guild_id),)
        ).fetchall()
    return render_template("levels.html", rows=rows, guild_id=guild_id)

if __name__ == "__main__":
    host = os.getenv("DASHBOARD_HOST", "127.0.0.1")
    port = int(os.getenv("DASHBOARD_PORT", "5000"))
    app.run(host=host, port=port, debug=True)
