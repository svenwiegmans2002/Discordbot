#!/bin/bash
set -e
cp scripts/discordbot.service /etc/systemd/system/discordbot.service
cp scripts/discordbot-dashboard.service /etc/systemd/system/discordbot-dashboard.service
systemctl daemon-reload
systemctl enable discordbot discordbot-dashboard
systemctl restart discordbot discordbot-dashboard
systemctl status discordbot --no-pager
systemctl status discordbot-dashboard --no-pager
