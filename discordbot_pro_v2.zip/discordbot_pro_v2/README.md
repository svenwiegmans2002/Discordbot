# DiscordBot Pro v2

Complete self-hosted all-in-one Discord bot met dashboard.

## Functies
- Discord OAuth2 dashboard
- Serverselectie
- Module toggles
- Welcome + autorole
- Moderatie: kick, ban, timeout, warn, warnings, purge, lock, unlock, slowmode
- AutoMod: anti-link, anti-spam, bad words
- Tickets met claim, close en HTML transcript
- Logging: join, leave, delete, edit, modlogs
- Levels + leaderboard
- Economy: balance, daily, work, pay
- Giveaways + reroll
- Embed builder in Discord én dashboard
- Dashboard pagina's: instellingen, warnings, levels, economy, audit, moderation, embed builder
- Systemd services voor Proxmox CT

## Installatie
```bash
apt update
apt install -y python3 python3-pip python3-venv unzip curl screen
cd /root
unzip discordbot_pro_v2.zip
cd discordbot_pro_v2
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt
cp .env.example .env
nano .env
```

## Discord Developer Portal
Bot tab:
- SERVER MEMBERS INTENT aan
- MESSAGE CONTENT INTENT aan

OAuth2 > Redirects:
```text
http://JOUW_CT_IP:5000/callback
```

Invite scopes:
- bot
- applications.commands

Voor testen: Administrator permission.

## Handmatig starten
Bot:
```bash
source venv/bin/activate
python main.py
```
Dashboard:
```bash
source venv/bin/activate
python -m dashboard.app
```

## Automatisch starten met systemd
```bash
chmod +x install_services.sh
./install_services.sh
```

Logs bekijken:
```bash
journalctl -u discordbot -f
journalctl -u discordbot-dashboard -f
```

Dashboard openen:
```text
http://JOUW_CT_IP:5000
```
