import discord
from discord import app_commands
from discord.ext import commands
class Embeds(commands.Cog):
    def __init__(self,bot): self.bot=bot
    @app_commands.command(name='embed')
    async def embed(self,i,title:str,description:str,channel:discord.TextChannel|None=None,color_hex:str='5865F2'):
        if not i.user.guild_permissions.manage_messages: return await i.response.send_message('Missing permission.',ephemeral=True)
        try: color=int(color_hex.replace('#',''),16)
        except Exception: color=0x5865F2
        await (channel or i.channel).send(embed=discord.Embed(title=title,description=description,color=color)); await i.response.send_message('Embed sent.',ephemeral=True)
async def setup(bot): await bot.add_cog(Embeds(bot))
