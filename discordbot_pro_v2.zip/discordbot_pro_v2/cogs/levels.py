import random,time,discord,aiosqlite
from discord import app_commands
from discord.ext import commands
from utils.db import DB_PATH,module_enabled
def lvl(xp): return int((xp/100)**0.5)
def need(l): return l*l*100
class Levels(commands.Cog):
    def __init__(self,bot): self.bot=bot
    @commands.Cog.listener()
    async def on_message(self,msg):
        if not msg.guild or msg.author.bot or not await module_enabled(msg.guild.id,'levels'): return
        now=time.time()
        async with aiosqlite.connect(DB_PATH) as db:
            db.row_factory=aiosqlite.Row; row=await (await db.execute('SELECT * FROM levels WHERE guild_id=? AND user_id=?',(msg.guild.id,msg.author.id))).fetchone()
            if row and now-row['last_xp_at']<60: return
            old=row['level'] if row else 0; xp=(row['xp'] if row else 0)+random.randint(8,15); new=lvl(xp)
            await db.execute('INSERT INTO levels (guild_id,user_id,xp,level,last_xp_at) VALUES (?,?,?,?,?) ON CONFLICT(guild_id,user_id) DO UPDATE SET xp=excluded.xp,level=excluded.level,last_xp_at=excluded.last_xp_at',(msg.guild.id,msg.author.id,xp,new,now)); await db.commit()
        if new>old: await msg.channel.send(f'🎉 {msg.author.mention} reached level **{new}**!')
    @app_commands.command(name='level')
    async def level(self,i,member:discord.Member|None=None):
        member=member or i.user
        async with aiosqlite.connect(DB_PATH) as db:
            db.row_factory=aiosqlite.Row; row=await (await db.execute('SELECT * FROM levels WHERE guild_id=? AND user_id=?',(i.guild_id,member.id))).fetchone()
        x,l=(row['xp'],row['level']) if row else (0,0); await i.response.send_message(f'{member.mention}: Level **{l}**, XP **{x}/{need(l+1)}**')
    @app_commands.command(name='leaderboard')
    async def leaderboard(self,i):
        async with aiosqlite.connect(DB_PATH) as db:
            db.row_factory=aiosqlite.Row; rows=await (await db.execute('SELECT * FROM levels WHERE guild_id=? ORDER BY xp DESC LIMIT 10',(i.guild_id,))).fetchall()
        desc='\n'.join(f"**{n+1}.** <@{r['user_id']}> — lvl {r['level']} ({r['xp']} XP)" for n,r in enumerate(rows)) or 'No data.'
        await i.response.send_message(embed=discord.Embed(title='Leaderboard',description=desc,color=discord.Color.gold()))
async def setup(bot): await bot.add_cog(Levels(bot))
