import discord
from discord.ext import commands
from utils.db import get_config,module_enabled
from cogs._shared import send_log
class LoggingCog(commands.Cog):
    def __init__(self,bot): self.bot=bot
    @commands.Cog.listener()
    async def on_member_join(self,m):
        cfg=await get_config(m.guild.id)
        if await module_enabled(m.guild.id,'welcome'):
            if cfg.get('autorole_id'):
                role=m.guild.get_role(cfg['autorole_id'])
                if role:
                    try: await m.add_roles(role,reason='Autorole')
                    except Exception: pass
            ch=m.guild.get_channel(cfg.get('welcome_channel_id')) if cfg.get('welcome_channel_id') else None
            if ch: await ch.send((cfg.get('welcome_message') or 'Welcome {member} to {server}!').format(member=m.mention,server=m.guild.name))
        await send_log(m.guild,f'✅ Join {m.mention} ({m.id})')
    @commands.Cog.listener()
    async def on_member_remove(self,m): await send_log(m.guild,f'❌ Leave {m} ({m.id})')
    @commands.Cog.listener()
    async def on_message_delete(self,msg):
        if msg.guild and not msg.author.bot: await send_log(msg.guild,f'🗑️ Deleted in {msg.channel.mention} by {msg.author}: {msg.content[:900] or "[empty]"}')
    @commands.Cog.listener()
    async def on_message_edit(self,b,a):
        if b.guild and not b.author.bot and b.content!=a.content: await send_log(b.guild,f'✏️ Edited by {b.author} in {b.channel.mention}\nBefore: {b.content[:350]}\nAfter: {a.content[:350]}')
async def setup(bot): await bot.add_cog(LoggingCog(bot))
