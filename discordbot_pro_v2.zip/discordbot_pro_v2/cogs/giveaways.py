import random,time,discord,aiosqlite
from discord import app_commands
from discord.ext import commands,tasks
from utils.db import DB_PATH
from utils.helpers import parse_duration
EMOJI='🎉'
class Giveaways(commands.Cog):
    def __init__(self,bot): self.bot=bot; self.loop.start()
    def cog_unload(self): self.loop.cancel()
    @app_commands.command(name='giveaway')
    async def giveaway(self,i,duration:str,winners:app_commands.Range[int,1,20],prize:str):
        if not i.user.guild_permissions.manage_guild: return await i.response.send_message('Missing permission.',ephemeral=True)
        ends=time.time()+parse_duration(duration); e=discord.Embed(title='🎉 Giveaway',description=f'Prize: **{prize}**\nWinners: **{winners}**\nEnds: <t:{int(ends)}:R>\nReact with {EMOJI}.',color=discord.Color.gold())
        await i.response.send_message(embed=e); msg=await i.original_response(); await msg.add_reaction(EMOJI)
        async with aiosqlite.connect(DB_PATH) as db: await db.execute('INSERT INTO giveaways (message_id,guild_id,channel_id,prize,winner_count,ends_at,host_id) VALUES (?,?,?,?,?,?,?)',(msg.id,i.guild_id,i.channel_id,prize,winners,ends,i.user.id)); await db.commit()
    @app_commands.command(name='reroll')
    async def reroll(self,i,message_id:str):
        await i.response.defer()
        try:
            msg=await i.channel.fetch_message(int(message_id)); users=[]
            for r in msg.reactions:
                if str(r.emoji)==EMOJI:
                    async for u in r.users():
                        if not u.bot: users.append(u)
            await i.followup.send(f'New winner: {random.choice(users).mention}' if users else 'No participants.')
        except Exception as e: await i.followup.send(f'Failed: {e}')
    @tasks.loop(seconds=30)
    async def loop(self):
        await self.bot.wait_until_ready(); now=time.time()
        async with aiosqlite.connect(DB_PATH) as db:
            db.row_factory=aiosqlite.Row; rows=await (await db.execute('SELECT * FROM giveaways WHERE ended=0 AND ends_at<=?',(now,))).fetchall()
        for row in rows:
            g=self.bot.get_guild(row['guild_id']); ch=g.get_channel(row['channel_id']) if g else None
            if not ch: continue
            try: msg=await ch.fetch_message(row['message_id'])
            except Exception: continue
            users=[]
            for r in msg.reactions:
                if str(r.emoji)==EMOJI:
                    async for u in r.users():
                        if not u.bot: users.append(u)
            wins=random.sample(users,min(row['winner_count'],len(users))) if users else []
            await ch.send(f"🎉 Giveaway ended! Prize: **{row['prize']}** Winner(s): {', '.join(w.mention for w in wins)}" if wins else f"Giveaway ended for **{row['prize']}**, no participants.")
            async with aiosqlite.connect(DB_PATH) as db: await db.execute('UPDATE giveaways SET ended=1,winner_ids=? WHERE message_id=?',(','.join(str(w.id) for w in wins),row['message_id'])); await db.commit()
async def setup(bot): await bot.add_cog(Giveaways(bot))
