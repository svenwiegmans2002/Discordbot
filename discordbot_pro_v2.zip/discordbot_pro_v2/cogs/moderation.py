import discord, aiosqlite
from discord import app_commands
from discord.ext import commands
from utils.db import DB_PATH,audit,module_enabled
from utils.helpers import parse_duration,utc_after
from cogs._shared import send_log
class Moderation(commands.Cog):
    def __init__(self,bot): self.bot=bot
    async def ok(self,g): return await module_enabled(g,'moderation')
    @app_commands.command(name='kick')
    async def kick(self,i,member:discord.Member,reason:str='No reason'):
        if not i.user.guild_permissions.kick_members: return await i.response.send_message('Missing permission.',ephemeral=True)
        await member.kick(reason=reason); await audit(i.guild_id,'kick',i.user.id,member.id,reason); await send_log(i.guild,f'👢 Kick {member} by {i.user}: {reason}'); await i.response.send_message(f'Kicked {member.mention}')
    @app_commands.command(name='ban')
    async def ban(self,i,member:discord.Member,reason:str='No reason'):
        if not i.user.guild_permissions.ban_members: return await i.response.send_message('Missing permission.',ephemeral=True)
        await member.ban(reason=reason); await audit(i.guild_id,'ban',i.user.id,member.id,reason); await send_log(i.guild,f'🔨 Ban {member} by {i.user}: {reason}'); await i.response.send_message(f'Banned {member.mention}')
    @app_commands.command(name='timeout')
    async def timeout(self,i,member:discord.Member,duration:str,reason:str='No reason'):
        if not i.user.guild_permissions.moderate_members: return await i.response.send_message('Missing permission.',ephemeral=True)
        await member.timeout(utc_after(parse_duration(duration)),reason=reason); await audit(i.guild_id,'timeout',i.user.id,member.id,duration+' '+reason); await i.response.send_message(f'Timed out {member.mention}')
    @app_commands.command(name='warn')
    async def warn(self,i,member:discord.Member,reason:str):
        if not i.user.guild_permissions.moderate_members: return await i.response.send_message('Missing permission.',ephemeral=True)
        async with aiosqlite.connect(DB_PATH) as db: await db.execute('INSERT INTO warnings (guild_id,user_id,moderator_id,reason) VALUES (?,?,?,?)',(i.guild_id,member.id,i.user.id,reason)); await db.commit()
        await audit(i.guild_id,'warn',i.user.id,member.id,reason); await i.response.send_message(f'Warned {member.mention}: {reason}')
    @app_commands.command(name='warnings')
    async def warnings(self,i,member:discord.Member):
        async with aiosqlite.connect(DB_PATH) as db:
            db.row_factory=aiosqlite.Row; rows=await (await db.execute('SELECT * FROM warnings WHERE guild_id=? AND user_id=? ORDER BY id DESC LIMIT 15',(i.guild_id,member.id))).fetchall()
        e=discord.Embed(title=f'Warnings: {member}',color=discord.Color.orange())
        for r in rows: e.add_field(name=f"#{r['id']} {r['created_at']}",value=f"{r['reason']} by <@{r['moderator_id']}>",inline=False)
        await i.response.send_message(embed=e if rows else None, content=None if rows else 'No warnings.', ephemeral=True)
    @app_commands.command(name='purge')
    async def purge(self,i,amount:app_commands.Range[int,1,200]):
        if not i.user.guild_permissions.manage_messages: return await i.response.send_message('Missing permission.',ephemeral=True)
        await i.response.defer(ephemeral=True); d=await i.channel.purge(limit=amount); await i.followup.send(f'Deleted {len(d)} messages.',ephemeral=True)
    @app_commands.command(name='lock')
    async def lock(self,i):
        if not i.user.guild_permissions.manage_channels: return await i.response.send_message('Missing permission.',ephemeral=True)
        await i.channel.set_permissions(i.guild.default_role,send_messages=False); await i.response.send_message('Locked.')
    @app_commands.command(name='unlock')
    async def unlock(self,i):
        if not i.user.guild_permissions.manage_channels: return await i.response.send_message('Missing permission.',ephemeral=True)
        await i.channel.set_permissions(i.guild.default_role,send_messages=None); await i.response.send_message('Unlocked.')
    @app_commands.command(name='slowmode')
    async def slowmode(self,i,seconds:app_commands.Range[int,0,21600]):
        if not i.user.guild_permissions.manage_channels: return await i.response.send_message('Missing permission.',ephemeral=True)
        await i.channel.edit(slowmode_delay=seconds); await i.response.send_message(f'Slowmode {seconds}s')
async def setup(bot): await bot.add_cog(Moderation(bot))
