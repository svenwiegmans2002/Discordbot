import pathlib,discord,aiosqlite
from discord import app_commands
from discord.ext import commands
from utils.db import DB_PATH,get_config,audit,module_enabled
from utils.helpers import make_transcript
TRANSCRIPT_DIR=pathlib.Path('data/transcripts'); TRANSCRIPT_DIR.mkdir(parents=True,exist_ok=True)
class TicketPanel(discord.ui.View):
    def __init__(self): super().__init__(timeout=None)
    @discord.ui.button(label='Open Ticket',style=discord.ButtonStyle.green,emoji='🎫',custom_id='pro_ticket_open')
    async def open(self,i,button):
        cfg=await get_config(i.guild_id); cat=i.guild.get_channel(cfg.get('ticket_category_id')) if cfg.get('ticket_category_id') else None; support=i.guild.get_role(cfg.get('ticket_support_role_id')) if cfg.get('ticket_support_role_id') else None
        ow={i.guild.default_role:discord.PermissionOverwrite(view_channel=False),i.user:discord.PermissionOverwrite(view_channel=True,send_messages=True,read_message_history=True),i.guild.me:discord.PermissionOverwrite(view_channel=True,send_messages=True,manage_channels=True)}
        if support: ow[support]=discord.PermissionOverwrite(view_channel=True,send_messages=True,read_message_history=True)
        ch=await i.guild.create_text_channel(f'ticket-{i.user.name}'.lower()[:90],category=cat,overwrites=ow)
        async with aiosqlite.connect(DB_PATH) as db: await db.execute('INSERT INTO tickets (guild_id,channel_id,opener_id) VALUES (?,?,?)',(i.guild_id,ch.id,i.user.id)); await db.commit()
        await ch.send(f'{i.user.mention}, welcome. Staff will help you soon.',view=TicketManage()); await i.response.send_message(f'Ticket opened: {ch.mention}',ephemeral=True)
class TicketManage(discord.ui.View):
    def __init__(self): super().__init__(timeout=None)
    @discord.ui.button(label='Claim',style=discord.ButtonStyle.blurple,emoji='🙋',custom_id='pro_ticket_claim')
    async def claim(self,i,button):
        async with aiosqlite.connect(DB_PATH) as db: await db.execute('UPDATE tickets SET claimed_by=? WHERE channel_id=?',(i.user.id,i.channel_id)); await db.commit()
        await i.response.send_message(f'Claimed by {i.user.mention}')
    @discord.ui.button(label='Close + Transcript',style=discord.ButtonStyle.red,emoji='🔒',custom_id='pro_ticket_close')
    async def close(self,i,button):
        await i.response.defer(ephemeral=True); path=TRANSCRIPT_DIR/f'ticket-{i.channel.id}.html'; path.write_text(await make_transcript(i.channel),encoding='utf-8')
        async with aiosqlite.connect(DB_PATH) as db: await db.execute("UPDATE tickets SET status='closed', closed_at=CURRENT_TIMESTAMP WHERE channel_id=?",(i.channel_id,)); await db.commit()
        await audit(i.guild_id,'ticket-close',i.user.id,i.channel_id,str(path)); await i.followup.send('Transcript saved. Closing...',ephemeral=True); await i.channel.delete(reason='Ticket closed')
class Tickets(commands.Cog):
    def __init__(self,bot): self.bot=bot; bot.add_view(TicketPanel()); bot.add_view(TicketManage())
    @app_commands.command(name='ticketpanel')
    async def ticketpanel(self,i):
        if not i.user.guild_permissions.manage_channels: return await i.response.send_message('Missing permission.',ephemeral=True)
        await i.response.send_message(embed=discord.Embed(title='Support Tickets',description='Click below to open a ticket.',color=discord.Color.green()),view=TicketPanel())
async def setup(bot): await bot.add_cog(Tickets(bot))
