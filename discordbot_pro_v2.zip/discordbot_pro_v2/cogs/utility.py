import discord
from discord import app_commands
from discord.ext import commands
class Utility(commands.Cog):
    def __init__(self,bot): self.bot=bot
    @app_commands.command(name='ping')
    async def ping(self,i): await i.response.send_message(f'Pong: {round(self.bot.latency*1000)}ms')
    @app_commands.command(name='serverinfo')
    async def serverinfo(self,i):
        g=i.guild; e=discord.Embed(title=g.name,color=discord.Color.blurple()); e.add_field(name='Members',value=str(g.member_count)); e.add_field(name='Owner',value=str(g.owner)); e.add_field(name='Created',value=f'<t:{int(g.created_at.timestamp())}:D>')
        if g.icon: e.set_thumbnail(url=g.icon.url)
        await i.response.send_message(embed=e)
    @app_commands.command(name='userinfo')
    async def userinfo(self,i,member:discord.Member|None=None):
        m=member or i.user; e=discord.Embed(title=str(m),color=discord.Color.blurple()); e.add_field(name='ID',value=str(m.id),inline=False); e.add_field(name='Joined',value=f'<t:{int(m.joined_at.timestamp())}:D>' if m.joined_at else 'Unknown'); e.add_field(name='Created',value=f'<t:{int(m.created_at.timestamp())}:D>'); e.set_thumbnail(url=m.display_avatar.url); await i.response.send_message(embed=e)
async def setup(bot): await bot.add_cog(Utility(bot))
