import random,time,discord,aiosqlite
from discord import app_commands
from discord.ext import commands
from utils.db import DB_PATH,module_enabled
async def ensure(db,g,u): await db.execute('INSERT OR IGNORE INTO economy (guild_id,user_id,wallet,bank) VALUES (?,?,0,0)',(g,u))
class Economy(commands.Cog):
    def __init__(self,bot): self.bot=bot
    @app_commands.command(name='balance')
    async def balance(self,i,member:discord.Member|None=None):
        member=member or i.user
        async with aiosqlite.connect(DB_PATH) as db:
            db.row_factory=aiosqlite.Row; await ensure(db,i.guild_id,member.id); await db.commit(); row=await (await db.execute('SELECT * FROM economy WHERE guild_id=? AND user_id=?',(i.guild_id,member.id))).fetchone()
        await i.response.send_message(f'💰 {member.mention}: wallet **{row["wallet"]}**, bank **{row["bank"]}**')
    @app_commands.command(name='daily')
    async def daily(self,i):
        now=time.time()
        async with aiosqlite.connect(DB_PATH) as db:
            db.row_factory=aiosqlite.Row; await ensure(db,i.guild_id,i.user.id); row=await (await db.execute('SELECT * FROM economy WHERE guild_id=? AND user_id=?',(i.guild_id,i.user.id))).fetchone()
            if now-row['last_daily']<86400: return await i.response.send_message('Already claimed daily.',ephemeral=True)
            await db.execute('UPDATE economy SET wallet=wallet+250,last_daily=? WHERE guild_id=? AND user_id=?',(now,i.guild_id,i.user.id)); await db.commit()
        await i.response.send_message('Daily claimed: **250** coins.')
    @app_commands.command(name='work')
    async def work(self,i):
        now=time.time(); amt=random.randint(50,180)
        async with aiosqlite.connect(DB_PATH) as db:
            db.row_factory=aiosqlite.Row; await ensure(db,i.guild_id,i.user.id); row=await (await db.execute('SELECT * FROM economy WHERE guild_id=? AND user_id=?',(i.guild_id,i.user.id))).fetchone()
            if now-row['last_work']<3600: return await i.response.send_message('You can work once per hour.',ephemeral=True)
            await db.execute('UPDATE economy SET wallet=wallet+?,last_work=? WHERE guild_id=? AND user_id=?',(amt,now,i.guild_id,i.user.id)); await db.commit()
        await i.response.send_message(f'You earned **{amt}** coins.')
    @app_commands.command(name='pay')
    async def pay(self,i,member:discord.Member,amount:app_commands.Range[int,1,1000000]):
        async with aiosqlite.connect(DB_PATH) as db:
            db.row_factory=aiosqlite.Row; await ensure(db,i.guild_id,i.user.id); await ensure(db,i.guild_id,member.id); row=await (await db.execute('SELECT wallet FROM economy WHERE guild_id=? AND user_id=?',(i.guild_id,i.user.id))).fetchone()
            if row['wallet']<amount: return await i.response.send_message('Not enough coins.',ephemeral=True)
            await db.execute('UPDATE economy SET wallet=wallet-? WHERE guild_id=? AND user_id=?',(amount,i.guild_id,i.user.id)); await db.execute('UPDATE economy SET wallet=wallet+? WHERE guild_id=? AND user_id=?',(amount,i.guild_id,member.id)); await db.commit()
        await i.response.send_message(f'Paid **{amount}** to {member.mention}.')
async def setup(bot): await bot.add_cog(Economy(bot))
