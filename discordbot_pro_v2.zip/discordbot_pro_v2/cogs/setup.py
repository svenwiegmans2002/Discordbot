import discord
from discord import app_commands
from discord.ext import commands
from utils.db import set_config, get_config
class Setup(commands.Cog):
    def __init__(self,bot): self.bot=bot
    group=app_commands.Group(name='setup',description='Server setup')
    @group.command(name='log')
    async def log(self,i:discord.Interaction,channel:discord.TextChannel):
        if not i.user.guild_permissions.administrator: return await i.response.send_message('Admins only.',ephemeral=True)
        await set_config(i.guild_id,log_channel_id=channel.id,modlog_channel_id=channel.id); await i.response.send_message(f'Log set to {channel.mention}',ephemeral=True)
    @group.command(name='welcome')
    async def welcome(self,i:discord.Interaction,channel:discord.TextChannel,message:str):
        if not i.user.guild_permissions.administrator: return await i.response.send_message('Admins only.',ephemeral=True)
        await set_config(i.guild_id,welcome_channel_id=channel.id,welcome_message=message); await i.response.send_message('Welcome saved.',ephemeral=True)
    @group.command(name='autorole')
    async def autorole(self,i:discord.Interaction,role:discord.Role):
        if not i.user.guild_permissions.administrator: return await i.response.send_message('Admins only.',ephemeral=True)
        await set_config(i.guild_id,autorole_id=role.id); await i.response.send_message('Autorole saved.',ephemeral=True)
    @group.command(name='tickets')
    async def tickets(self,i:discord.Interaction,category:discord.CategoryChannel,support_role:discord.Role|None=None):
        if not i.user.guild_permissions.administrator: return await i.response.send_message('Admins only.',ephemeral=True)
        await set_config(i.guild_id,ticket_category_id=category.id,ticket_support_role_id=support_role.id if support_role else None); await i.response.send_message('Tickets saved.',ephemeral=True)
    @app_commands.command(name='config')
    async def config(self,i):
        cfg=await get_config(i.guild_id); e=discord.Embed(title='Config',color=discord.Color.blurple())
        for k,v in cfg.items(): e.add_field(name=k,value=str(v),inline=False)
        await i.response.send_message(embed=e,ephemeral=True)
async def setup(bot): await bot.add_cog(Setup(bot))
