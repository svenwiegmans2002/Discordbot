from utils.db import get_config
async def send_log(guild, text):
    cfg=await get_config(guild.id); cid=cfg.get('modlog_channel_id') or cfg.get('log_channel_id')
    ch=guild.get_channel(cid) if cid else None
    if ch:
        try: await ch.send(text)
        except Exception: pass
