import time,re,aiosqlite,discord
from discord.ext import commands
from utils.db import DB_PATH,module_enabled,audit
from cogs._shared import send_log
LINK_RE=re.compile(r'(https?://|discord\.gg/|www\.)',re.I)
class AutoMod(commands.Cog):
    def __init__(self,bot): self.bot=bot; self.cache={}
    async def cfg(self,gid):
        async with aiosqlite.connect(DB_PATH) as db:
            db.row_factory=aiosqlite.Row; row=await (await db.execute('SELECT * FROM automod_config WHERE guild_id=?',(gid,))).fetchone(); return dict(row) if row else {}
    @commands.Cog.listener()
    async def on_message(self,msg):
        if not msg.guild or msg.author.bot or msg.author.guild_permissions.manage_messages: return
        if not await module_enabled(msg.guild.id,'automod'): return
        cfg=await self.cfg(msg.guild.id); reason=None
        if cfg.get('anti_links') and LINK_RE.search(msg.content): reason='anti-link'
        words=[w.strip().lower() for w in (cfg.get('bad_words') or '').split(',') if w.strip()]
        if words and any(w in msg.content.lower() for w in words): reason='bad-word'
        if cfg.get('anti_spam'):
            key=(msg.guild.id,msg.author.id); now=time.time(); arr=[t for t in self.cache.get(key,[]) if now-t<int(cfg.get('spam_seconds') or 8)]+[now]; self.cache[key]=arr
            if len(arr)>=int(cfg.get('spam_limit') or 5): reason='anti-spam'
        if reason:
            try: await msg.delete()
            except Exception: pass
            await audit(msg.guild.id,'automod-'+reason,self.bot.user.id,msg.author.id,msg.content[:300]); await send_log(msg.guild,f'🛡️ AutoMod blocked {msg.author.mention}: {reason}')
async def setup(bot): await bot.add_cog(AutoMod(bot))
