import os, sqlite3, requests
from pathlib import Path
from dotenv import load_dotenv
from flask import Flask,redirect,render_template,request,session,url_for,flash
load_dotenv(); BASE=Path(__file__).resolve().parent.parent; DB=BASE/'data/bot.db'; API='https://discord.com/api/v10'
CID=os.getenv('DISCORD_CLIENT_ID'); SECRET=os.getenv('DISCORD_CLIENT_SECRET'); REDIRECT=os.getenv('DISCORD_REDIRECT_URI'); BOT=os.getenv('DISCORD_TOKEN')
app=Flask(__name__); app.secret_key=os.getenv('FLASK_SECRET_KEY','change-this')
def con(): c=sqlite3.connect(DB); c.row_factory=sqlite3.Row; return c
def api(path,token=None,bot=False,method='GET',json=None):
    h={};
    if bot: h['Authorization']=f'Bot {BOT}'
    elif token: h['Authorization']=f'Bearer {token}'
    r=requests.request(method,API+path,headers=h,json=json,timeout=20); r.raise_for_status(); return r.json() if r.text else {}
def init(gid):
    with con() as db:
        db.execute('INSERT OR IGNORE INTO guild_config (guild_id) VALUES (?)',(gid,)); db.execute('INSERT OR IGNORE INTO automod_config (guild_id) VALUES (?)',(gid,))
        for m in ['moderation','logging','tickets','welcome','levels','economy','giveaways','automod','embeds','utility']: db.execute('INSERT OR IGNORE INTO module_config (guild_id,module,enabled) VALUES (?,?,1)',(gid,m))
        db.commit()
def logged(): return 'access_token' in session
def botguilds():
    try: return {str(g['id']) for g in api('/users/@me/guilds',bot=True)}
    except Exception: return set()
def guilds():
    if not logged(): return []
    bg=botguilds(); out=[]
    for g in api('/users/@me/guilds',token=session['access_token']):
        p=int(g.get('permissions',0))
        if str(g['id']) in bg and ((p&0x8) or (p&0x20)): out.append(g)
    return out
def allowed(gid): return any(str(g['id'])==str(gid) for g in guilds())
@app.route('/')
def index(): return redirect('/servers') if logged() else render_template('index.html')
@app.route('/login')
def login(): return redirect(f"https://discord.com/oauth2/authorize?client_id={CID}&redirect_uri={requests.utils.quote(REDIRECT or '',safe='')}&response_type=code&scope=identify%20guilds")
@app.route('/callback')
def callback():
    r=requests.post(API+'/oauth2/token',data={'client_id':CID,'client_secret':SECRET,'grant_type':'authorization_code','code':request.args.get('code'),'redirect_uri':REDIRECT},headers={'Content-Type':'application/x-www-form-urlencoded'},timeout=20); r.raise_for_status(); t=r.json(); session['access_token']=t['access_token']; session['user']=api('/users/@me',token=t['access_token']); return redirect('/servers')
@app.route('/logout')
def logout(): session.clear(); return redirect('/')
@app.route('/servers')
def servers():
    if not logged(): return redirect('/login')
    return render_template('servers.html',guilds=guilds())
@app.route('/g/<gid>',methods=['GET','POST'])
def guild(gid):
    if not logged() or not allowed(gid): return 'No access',403
    init(int(gid))
    if request.method=='POST':
        with con() as db:
            db.execute('UPDATE guild_config SET log_channel_id=?,modlog_channel_id=?,welcome_channel_id=?,welcome_message=?,autorole_id=?,ticket_category_id=?,ticket_support_role_id=?,embed_channel_id=? WHERE guild_id=?', tuple(request.form.get(x) or None for x in ['log_channel_id','modlog_channel_id','welcome_channel_id','welcome_message','autorole_id','ticket_category_id','ticket_support_role_id','embed_channel_id'])+(int(gid),))
            mods=[r['module'] for r in db.execute('SELECT module FROM module_config WHERE guild_id=?',(int(gid),)).fetchall()]
            for m in mods: db.execute('UPDATE module_config SET enabled=? WHERE guild_id=? AND module=?',(1 if request.form.get('module_'+m) else 0,int(gid),m))
            db.execute('UPDATE automod_config SET anti_links=?,anti_spam=?,bad_words=?,spam_limit=?,spam_seconds=? WHERE guild_id=?',(1 if request.form.get('anti_links') else 0,1 if request.form.get('anti_spam') else 0,request.form.get('bad_words',''),int(request.form.get('spam_limit') or 5),int(request.form.get('spam_seconds') or 8),int(gid))); db.commit()
        flash('Saved.'); return redirect('/g/'+gid)
    g=api(f'/guilds/{gid}',bot=True); chans=api(f'/guilds/{gid}/channels',bot=True); roles=api(f'/guilds/{gid}/roles',bot=True)
    with con() as db:
        cfg=db.execute('SELECT * FROM guild_config WHERE guild_id=?',(int(gid),)).fetchone(); mods=db.execute('SELECT * FROM module_config WHERE guild_id=? ORDER BY module',(int(gid),)).fetchall(); am=db.execute('SELECT * FROM automod_config WHERE guild_id=?',(int(gid),)).fetchone(); stats={k:db.execute(f'SELECT COUNT(*) c FROM {t} WHERE guild_id=?',(int(gid),)).fetchone()['c'] for k,t in {'warnings':'warnings','tickets':'tickets','levels':'levels','economy':'economy'}.items()}
    return render_template('guild.html',guild=g,guild_id=gid,cfg=cfg,modules=mods,automod=am,stats=stats,text_channels=[c for c in chans if c['type']==0],categories=[c for c in chans if c['type']==4],roles=sorted(roles,key=lambda r:r.get('position',0),reverse=True))
@app.route('/g/<gid>/<page>')
def table(gid,page):
    if not logged() or not allowed(gid): return 'No access',403
    mapping={'warnings':'SELECT * FROM warnings WHERE guild_id=? ORDER BY id DESC LIMIT 200','levels':'SELECT user_id,level,xp,last_xp_at FROM levels WHERE guild_id=? ORDER BY xp DESC LIMIT 200','economy':'SELECT user_id,wallet,bank,last_daily,last_work FROM economy WHERE guild_id=? ORDER BY wallet+bank DESC LIMIT 200','audit':'SELECT * FROM audit_events WHERE guild_id=? ORDER BY id DESC LIMIT 200'}
    if page not in mapping: return 'Not found',404
    with con() as db: rows=db.execute(mapping[page],(int(gid),)).fetchall()
    return render_template('table.html',title=page.title(),guild_id=gid,rows=rows)
@app.route('/g/<gid>/embed',methods=['GET','POST'])
def embed(gid):
    if not logged() or not allowed(gid): return 'No access',403
    chans=[c for c in api(f'/guilds/{gid}/channels',bot=True) if c['type']==0]; result=None
    if request.method=='POST':
        color=int((request.form.get('color') or '5865F2').replace('#',''),16); payload={'embeds':[{'title':request.form.get('title'),'description':request.form.get('description'),'color':color}]}
        try: api(f'/channels/{request.form.get("channel_id")}/messages',bot=True,method='POST',json=payload); result='Embed sent.'
        except Exception as e: result='Failed: '+str(e)
    return render_template('embed.html',guild_id=gid,channels=chans,result=result)
if __name__=='__main__': app.run(host=os.getenv('DASHBOARD_HOST','0.0.0.0'),port=int(os.getenv('DASHBOARD_PORT','5000')),debug=False)
