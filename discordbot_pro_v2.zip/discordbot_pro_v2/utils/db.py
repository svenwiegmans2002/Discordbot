import aiosqlite
from pathlib import Path
DB_PATH = Path('data/bot.db')
MODULES=['moderation','logging','tickets','welcome','levels','economy','giveaways','automod','embeds','utility']
SCHEMA="""
CREATE TABLE IF NOT EXISTS guild_config (guild_id INTEGER PRIMARY KEY, log_channel_id INTEGER, welcome_channel_id INTEGER, welcome_message TEXT DEFAULT 'Welcome {member} to {server}!', autorole_id INTEGER, ticket_category_id INTEGER, ticket_support_role_id INTEGER, modlog_channel_id INTEGER, embed_channel_id INTEGER);
CREATE TABLE IF NOT EXISTS module_config (guild_id INTEGER NOT NULL, module TEXT NOT NULL, enabled INTEGER NOT NULL DEFAULT 1, PRIMARY KEY(guild_id,module));
CREATE TABLE IF NOT EXISTS warnings (id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id INTEGER NOT NULL, user_id INTEGER NOT NULL, moderator_id INTEGER NOT NULL, reason TEXT NOT NULL, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
CREATE TABLE IF NOT EXISTS automod_config (guild_id INTEGER PRIMARY KEY, anti_links INTEGER DEFAULT 0, anti_spam INTEGER DEFAULT 0, bad_words TEXT DEFAULT '', spam_limit INTEGER DEFAULT 5, spam_seconds INTEGER DEFAULT 8);
CREATE TABLE IF NOT EXISTS levels (guild_id INTEGER NOT NULL, user_id INTEGER NOT NULL, xp INTEGER NOT NULL DEFAULT 0, level INTEGER NOT NULL DEFAULT 0, last_xp_at REAL NOT NULL DEFAULT 0, PRIMARY KEY(guild_id,user_id));
CREATE TABLE IF NOT EXISTS economy (guild_id INTEGER NOT NULL, user_id INTEGER NOT NULL, wallet INTEGER NOT NULL DEFAULT 0, bank INTEGER NOT NULL DEFAULT 0, last_daily REAL NOT NULL DEFAULT 0, last_work REAL NOT NULL DEFAULT 0, PRIMARY KEY(guild_id,user_id));
CREATE TABLE IF NOT EXISTS giveaways (message_id INTEGER PRIMARY KEY, guild_id INTEGER NOT NULL, channel_id INTEGER NOT NULL, prize TEXT NOT NULL, winner_count INTEGER NOT NULL, ends_at REAL NOT NULL, host_id INTEGER NOT NULL, ended INTEGER NOT NULL DEFAULT 0, winner_ids TEXT DEFAULT '');
CREATE TABLE IF NOT EXISTS tickets (id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id INTEGER NOT NULL, channel_id INTEGER NOT NULL, opener_id INTEGER NOT NULL, claimed_by INTEGER, status TEXT DEFAULT 'open', created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP, closed_at TIMESTAMP);
CREATE TABLE IF NOT EXISTS audit_events (id INTEGER PRIMARY KEY AUTOINCREMENT, guild_id INTEGER NOT NULL, actor_id INTEGER, action TEXT NOT NULL, target_id INTEGER, details TEXT, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP);
"""
async def init_db():
    DB_PATH.parent.mkdir(exist_ok=True)
    async with aiosqlite.connect(DB_PATH) as db:
        await db.executescript(SCHEMA); await db.commit()
async def ensure_guild(guild_id:int):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute('INSERT OR IGNORE INTO guild_config (guild_id) VALUES (?)',(guild_id,))
        await db.execute('INSERT OR IGNORE INTO automod_config (guild_id) VALUES (?)',(guild_id,))
        for m in MODULES:
            await db.execute('INSERT OR IGNORE INTO module_config (guild_id,module,enabled) VALUES (?,?,1)',(guild_id,m))
        await db.commit()
async def get_config(guild_id:int)->dict:
    await ensure_guild(guild_id)
    async with aiosqlite.connect(DB_PATH) as db:
        db.row_factory=aiosqlite.Row
        return dict(await (await db.execute('SELECT * FROM guild_config WHERE guild_id=?',(guild_id,))).fetchone())
async def set_config(guild_id:int, **kw):
    await ensure_guild(guild_id)
    if not kw: return
    sql=', '.join(f'{k}=?' for k in kw)
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute(f'UPDATE guild_config SET {sql} WHERE guild_id=?', (*kw.values(), guild_id)); await db.commit()
async def module_enabled(guild_id:int, module:str)->bool:
    await ensure_guild(guild_id)
    async with aiosqlite.connect(DB_PATH) as db:
        row=await (await db.execute('SELECT enabled FROM module_config WHERE guild_id=? AND module=?',(guild_id,module))).fetchone()
        return bool(row and row[0])
async def audit(guild_id:int, action:str, actor_id=None, target_id=None, details=None):
    async with aiosqlite.connect(DB_PATH) as db:
        await db.execute('INSERT INTO audit_events (guild_id,actor_id,action,target_id,details) VALUES (?,?,?,?,?)',(guild_id,actor_id,action,target_id,details)); await db.commit()
