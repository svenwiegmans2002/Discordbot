import re, html, datetime, discord
DURATION_RE=re.compile(r'^(\d+)(s|m|h|d)$',re.I)
def parse_duration(v:str)->int:
    m=DURATION_RE.match(v.strip())
    if not m: raise ValueError('Use 30s, 10m, 2h or 3d')
    return int(m.group(1))*{'s':1,'m':60,'h':3600,'d':86400}[m.group(2).lower()]
def utc_after(sec:int): return discord.utils.utcnow()+datetime.timedelta(seconds=sec)
def esc(s): return html.escape(s or '')
async def make_transcript(channel, limit=1000):
    rows=[]
    async for msg in channel.history(limit=limit, oldest_first=True):
        rows.append(f"<div class='msg'><b>{esc(str(msg.author))}</b> <span>{msg.created_at:%Y-%m-%d %H:%M:%S UTC}</span><p>{esc(msg.content)}</p></div>")
    return "<!doctype html><html><head><meta charset='utf-8'><style>body{font-family:Arial;background:#111;color:#eee;padding:24px}.msg{border-bottom:1px solid #333;padding:12px}span{color:#aaa;font-size:12px}p{white-space:pre-wrap}</style></head><body><h1>Transcript: "+esc(channel.name)+"</h1>"+''.join(rows)+"</body></html>"
