import asyncio, json, logging, os
from pathlib import Path
import discord
from discord.ext import commands
from dotenv import load_dotenv
from utils.db import init_db
logging.basicConfig(level=logging.INFO, format='[%(levelname)s] %(message)s')
load_dotenv()
CONFIG=json.load(open('config.json','r',encoding='utf-8'))
intents=discord.Intents.default(); intents.members=True; intents.message_content=True; intents.guilds=True; intents.messages=True; intents.reactions=True
class ProBot(commands.Bot):
    def __init__(self): super().__init__(command_prefix=CONFIG.get('prefix','!'), intents=intents, help_command=None, activity=discord.Game(CONFIG.get('activity','All-in-one Pro Bot')))
    async def setup_hook(self):
        await init_db()
        for file in Path('cogs').glob('*.py'):
            if not file.name.startswith('_'): await self.load_extension(f'cogs.{file.stem}')
        await self.tree.sync(); logging.info('Slash commands synced')
    async def on_ready(self): logging.info('Logged in as %s (%s)', self.user, self.user.id)
token=os.getenv('DISCORD_TOKEN')
if not token: raise RuntimeError('DISCORD_TOKEN ontbreekt in .env')
asyncio.run(ProBot().start(token))
