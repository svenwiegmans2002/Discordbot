const { spawn } = require('node:child_process');
const {
  joinVoiceChannel,
  createAudioPlayer,
  createAudioResource,
  AudioPlayerStatus,
  VoiceConnectionStatus,
  entersState,
  StreamType,
  NoSubscriberBehavior,
} = require('@discordjs/voice');
const store = require('./store');

const states = new Map();
let spotifyToken = null;
let spotifyExpiresAt = 0;

function stateFor(guildId) {
  if (states.has(guildId)) return states.get(guildId);

  const player = createAudioPlayer({
    behaviors: { noSubscriber: NoSubscriberBehavior.Pause },
  });

  const state = {
    guildId,
    player,
    connection: null,
    queue: [],
    current: null,
    volume: 0.5,
    process: null,
    textChannelId: null,
    voiceChannelId: null,
    loop: 'off',
    autoplay: false,
    shuffle: false,
    equalizer: 'flat',
    startedAt: null,
    pausedAt: null,
    pausedTotal: 0,
    manuallyStopped: false,
  };

  player.on(AudioPlayerStatus.Idle, async () => {
    cleanupProcesses(state);

    const finished = state.current;
    state.current = null;

    if (state.manuallyStopped) {
      state.manuallyStopped = false;
      return;
    }

    if (finished) {
      store.mutate('musicHistory', all => {
        (all[guildId] ??= []).unshift({ ...finished, playedAt: Date.now() });
        all[guildId] = all[guildId].slice(0, 100);
      });

      if (state.loop === 'track') {
        state.queue.unshift(finished);
      } else if (state.loop === 'queue') {
        state.queue.push(finished);
      } else if (state.autoplay && state.queue.length === 0) {
        state.queue.push({
          ...finished,
          id: `auto-${Date.now()}`,
          query: `${finished.artist || ''} ${finished.title} similar official audio`,
          title: `Autoplay after ${finished.title}`,
          source: 'autoplay',
        });
      }
    }

    try {
      await playNext(state);
    } catch (error) {
      console.error('Music next-track error:', error);
      await notifyMusicError(state, error);
    }
  });

  player.on('error', async error => {
    console.error('Music player error:', error);
    cleanupProcesses(state);
    state.current = null;
    await notifyMusicError(state, error);

    try {
      await playNext(state);
    } catch (nextError) {
      console.error('Music recovery error:', nextError);
    }
  });

  states.set(guildId, state);
  return state;
}

function cleanupProcesses(state) {
  const processes = Array.isArray(state.process) ? state.process : state.process ? [state.process] : [];

  for (const process of processes) {
    try {
      if (process && !process.killed) process.kill('SIGKILL');
    } catch {}
  }

  state.process = null;
}

async function notifyMusicError(state, error) {
  if (!state.textChannelId || !global.__helixClient) return;

  const channel = await global.__helixClient.channels
    .fetch(state.textChannelId)
    .catch(() => null);

  if (channel?.isTextBased()) {
    await channel
      .send(`❌ Music error: ${String(error.message || error).slice(0, 1500)}`)
      .catch(() => {});
  }
}

function hasBinary(binary) {
  return new Promise(resolve => {
    const process = spawn('sh', ['-lc', `command -v ${binary}`]);
    process.once('close', code => resolve(code === 0));
    process.once('error', () => resolve(false));
  });
}

async function dependencyStatus() {
  const [ytdlp, ffmpeg] = await Promise.all([
    hasBinary('yt-dlp'),
    hasBinary('ffmpeg'),
  ]);

  return { ytdlp, ffmpeg };
}

function runJsonCommand(binary, args, timeoutMs = 45_000) {
  return new Promise((resolve, reject) => {
    const process = spawn(binary, args, {
      stdio: ['ignore', 'pipe', 'pipe'],
    });

    let stdout = '';
    let stderr = '';
    let finished = false;

    const timeout = setTimeout(() => {
      if (finished) return;
      finished = true;
      process.kill('SIGKILL');
      reject(new Error(`${binary} timed out after ${Math.round(timeoutMs / 1000)} seconds.`));
    }, timeoutMs);

    process.stdout.on('data', chunk => {
      stdout += chunk.toString();
    });

    process.stderr.on('data', chunk => {
      stderr += chunk.toString();
    });

    process.once('error', error => {
      if (finished) return;
      finished = true;
      clearTimeout(timeout);
      reject(error);
    });

    process.once('close', code => {
      if (finished) return;
      finished = true;
      clearTimeout(timeout);

      if (code !== 0) {
        return reject(
          new Error(
            stderr.trim() ||
              `${binary} exited with code ${code}.`
          )
        );
      }

      try {
        resolve(JSON.parse(stdout));
      } catch {
        reject(new Error(`Invalid JSON returned by ${binary}.`));
      }
    });
  });
}

async function resolveMediaTrack(query) {
  const normalized = String(query || '').trim();
  if (!normalized) throw new Error('Enter a URL or search query.');

  const source =
    /^https?:\/\//i.test(normalized) || normalized.startsWith('ytsearch')
      ? normalized
      : `ytsearch1:${normalized}`;

  const json = await runJsonCommand(
    'yt-dlp',
    ['--no-playlist', '--dump-single-json', '--skip-download', source],
    60_000
  );

  const track = Array.isArray(json.entries) ? json.entries[0] : json;
  if (!track) throw new Error('No playable result was found.');

  return {
    title: track.title || normalized,
    url: track.webpage_url || track.original_url || normalized,
    query: track.webpage_url || track.original_url || source,
    duration: Number(track.duration || 0),
    durationText: track.duration_string || 'unknown',
    thumbnail: track.thumbnail || null,
    artist: track.artist || track.uploader || '',
    source: 'media',
  };
}

function parseSpotifyUrl(input) {
  const value = String(input || '').trim();

  try {
    const url = new URL(value);
    if (!/(^|\.)spotify\.com$/i.test(url.hostname.replace(/^open\./i, 'spotify.com'))) {
      return null;
    }

    const parts = url.pathname
      .split('/')
      .filter(Boolean)
      .filter(part => !part.startsWith('intl-'));

    const typeIndex = parts.findIndex(part =>
      ['track', 'album', 'playlist'].includes(part)
    );

    if (typeIndex === -1 || !parts[typeIndex + 1]) return null;

    return {
      type: parts[typeIndex],
      id: parts[typeIndex + 1].split('?')[0],
    };
  } catch {
    const match = value.match(
      /(?:open\.)?spotify\.com\/(?:intl-[a-z-]+\/)?(track|album|playlist)\/([A-Za-z0-9]+)/
    );

    return match ? { type: match[1], id: match[2] } : null;
  }
}

async function spotifyAuth(force = false) {
  if (!force && spotifyToken && Date.now() < spotifyExpiresAt) {
    return spotifyToken;
  }

  const clientId = process.env.SPOTIFY_CLIENT_ID;
  const clientSecret = process.env.SPOTIFY_CLIENT_SECRET;

  if (!clientId || !clientSecret) {
    throw new Error(
      'Spotify is not configured. Add SPOTIFY_CLIENT_ID and SPOTIFY_CLIENT_SECRET to .env.'
    );
  }

  const authorization = Buffer.from(`${clientId}:${clientSecret}`).toString('base64');

  const response = await fetch('https://accounts.spotify.com/api/token', {
    method: 'POST',
    headers: {
      Authorization: `Basic ${authorization}`,
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: new URLSearchParams({ grant_type: 'client_credentials' }),
    signal: AbortSignal.timeout(20_000),
  });

  if (!response.ok) {
    const details = await response.text().catch(() => '');
    throw new Error(
      `Spotify authentication failed (${response.status}). ${details.slice(0, 300)}`
    );
  }

  const payload = await response.json();
  spotifyToken = payload.access_token;
  spotifyExpiresAt = Date.now() + Math.max(60, payload.expires_in - 60) * 1000;

  return spotifyToken;
}

async function spotifyRequest(url, retry = true) {
  const token = await spotifyAuth();

  const response = await fetch(url, {
    headers: { Authorization: `Bearer ${token}` },
    signal: AbortSignal.timeout(25_000),
  });

  if (response.status === 401 && retry) {
    spotifyToken = null;
    spotifyExpiresAt = 0;
    await spotifyAuth(true);
    return spotifyRequest(url, false);
  }

  if (!response.ok) {
    const details = await response.text().catch(() => '');

    if (response.status === 403) {
      throw new Error(
        'Spotify denied access to this playlist. Make sure the playlist is accessible to the Spotify app/user and that Web API is enabled.'
      );
    }

    if (response.status === 404) {
      throw new Error(
        'Spotify item not found. Check whether the link is valid and the playlist is public or accessible.'
      );
    }

    if (response.status === 429) {
      const retryAfter = response.headers.get('retry-after') || '?';
      throw new Error(`Spotify rate limit reached. Retry after ${retryAfter} seconds.`);
    }

    throw new Error(
      `Spotify API error ${response.status}. ${details.slice(0, 300)}`
    );
  }

  return response.json();
}

function spotifyTrackToQueueItem(track) {
  if (!track || !track.name) return null;

  const artists = Array.isArray(track.artists)
    ? track.artists.map(artist => artist.name).filter(Boolean)
    : [];

  const artistText = artists.join(', ');
  const image =
    track.album?.images?.[0]?.url ||
    track.images?.[0]?.url ||
    null;

  return {
    query: `${artistText} ${track.name} official audio`,
    title: track.name,
    artist: artistText,
    duration: Math.round(Number(track.duration_ms || 0) / 1000),
    durationText: track.duration_ms
      ? `${Math.floor(track.duration_ms / 60000)}:${String(
          Math.floor((track.duration_ms % 60000) / 1000)
        ).padStart(2, '0')}`
      : 'Spotify',
    thumbnail: image,
    spotifyUrl: track.external_urls?.spotify || null,
    source: 'spotify',
  };
}

async function fetchSpotifyPages(initialUrl, maxTracks = 300) {
  const results = [];
  let url = initialUrl;

  while (url && results.length < maxTracks) {
    const page = await spotifyRequest(url);
    const entries = Array.isArray(page.items) ? page.items : [];

    for (const entry of entries) {
      const track = entry?.item || entry?.track || entry;
      const converted = spotifyTrackToQueueItem(track);

      if (converted) {
        results.push(converted);
        if (results.length >= maxTracks) break;
      }
    }

    url = page.next || null;
  }

  return results;
}

async function spotifyTracks(input) {
  const parsed = parseSpotifyUrl(input);
  if (!parsed) return null;

  if (parsed.type === 'track') {
    const track = await spotifyRequest(
      `https://api.spotify.com/v1/tracks/${parsed.id}`
    );
    const converted = spotifyTrackToQueueItem(track);
    return converted ? [converted] : [];
  }

  if (parsed.type === 'album') {
    const album = await spotifyRequest(
      `https://api.spotify.com/v1/albums/${parsed.id}`
    );

    const albumImage = album.images?.[0]?.url || null;
    const tracks = [];
    let page = album.tracks;

    while (page && tracks.length < 300) {
      for (const track of page.items || []) {
        const converted = spotifyTrackToQueueItem({
          ...track,
          album: {
            images: album.images || [],
          },
        });

        if (converted) {
          converted.thumbnail = converted.thumbnail || albumImage;
          tracks.push(converted);
        }
      }

      page = page.next ? await spotifyRequest(page.next) : null;
    }

    return tracks;
  }

  const playlist = await spotifyRequest(
    `https://api.spotify.com/v1/playlists/${parsed.id}?fields=name,tracks(items(item(name,duration_ms,artists(name),album(images),external_urls),track(name,duration_ms,artists(name),album(images),external_urls)),next)`
  );

  const firstPage = playlist.tracks || { items: [], next: null };
  const tracks = [];

  for (const entry of firstPage.items || []) {
    const track = entry?.item || entry?.track || entry;
    const converted = spotifyTrackToQueueItem(track);
    if (converted) tracks.push(converted);
  }

  let nextUrl = firstPage.next || null;

  while (nextUrl && tracks.length < 300) {
    const pageTracks = await fetchSpotifyPages(nextUrl, 300 - tracks.length);
    tracks.push(...pageTracks);
    nextUrl = null;
  }

  if (!tracks.length) {
    throw new Error(
      'No playable tracks were found in this Spotify playlist. Local files, podcasts and unavailable tracks are skipped.'
    );
  }

  return tracks;
}

async function connect(guild, voiceChannel) {
  const state = stateFor(guild.id);

  if (
    state.connection &&
    state.voiceChannelId === voiceChannel.id &&
    state.connection.state.status !== VoiceConnectionStatus.Destroyed
  ) {
    return state;
  }

  if (state.connection) {
    try {
      state.connection.destroy();
    } catch {}
  }

  state.connection = joinVoiceChannel({
    channelId: voiceChannel.id,
    guildId: guild.id,
    adapterCreator: guild.voiceAdapterCreator,
    selfDeaf: true,
  });

  state.voiceChannelId = voiceChannel.id;
  state.connection.subscribe(state.player);

  try {
    await entersState(
      state.connection,
      VoiceConnectionStatus.Ready,
      25_000
    );
  } catch {
    try {
      state.connection.destroy();
    } catch {}
    state.connection = null;
    state.voiceChannelId = null;
    throw new Error(
      'Could not connect to the voice channel. Check the bot Connect and Speak permissions.'
    );
  }

  return state;
}

async function enqueue({
  guild,
  voiceChannel,
  textChannel,
  query,
  requestedBy,
}) {
  const dependencies = await dependencyStatus();

  if (!dependencies.ytdlp || !dependencies.ffmpeg) {
    const missing = [
      !dependencies.ytdlp ? 'yt-dlp' : null,
      !dependencies.ffmpeg ? 'ffmpeg' : null,
    ].filter(Boolean);

    throw new Error(
      `Missing CT dependencies: ${missing.join(', ')}.`
    );
  }

  const state = await connect(guild, voiceChannel);
  state.textChannelId = textChannel?.id || state.textChannelId;

  const isSpotify = Boolean(parseSpotifyUrl(query));
  const tracks = isSpotify
    ? await spotifyTracks(query)
    : [await resolveMediaTrack(query)];

  if (!tracks || tracks.length === 0) {
    throw new Error('No tracks could be added.');
  }

  const added = tracks.map(raw => ({
    ...raw,
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 9)}`,
    requestedBy,
    queuedAt: Date.now(),
  }));

  state.queue.push(...added);

  if (state.shuffle && state.queue.length > 1) {
    for (let index = state.queue.length - 1; index > 0; index -= 1) {
      const randomIndex = Math.floor(Math.random() * (index + 1));
      [state.queue[index], state.queue[randomIndex]] = [
        state.queue[randomIndex],
        state.queue[index],
      ];
    }
  }

  if (
    !state.current &&
    state.player.state.status === AudioPlayerStatus.Idle
  ) {
    await playNext(state);
  }

  return {
    track: added[0],
    count: added.length,
  };
}

function ffmpegFilter(equalizer) {
  return (
    {
      bass: 'bass=g=8',
      treble: 'treble=g=6',
      vocal: 'equalizer=f=1000:t=q:w=1:g=5',
      nightcore: 'asetrate=48000*1.15,aresample=48000,atempo=1.05',
      flat: 'anull',
    }[equalizer] || 'anull'
  );
}

async function playNext(state) {
  if (!state.connection) return;

  const track = state.queue.shift();
  if (!track) return;

  state.current = track;
  state.startedAt = Date.now();
  state.pausedAt = null;
  state.pausedTotal = 0;

  let sourceQuery = track.url || track.query;

  // Spotify items are metadata only. Resolve each item to a playable source just
  // before playback, which keeps playlist queueing fast.
  if (track.source === 'spotify' || track.source === 'autoplay') {
    const resolved = await resolveMediaTrack(track.query);
    sourceQuery = resolved.url || resolved.query;
    track.playbackUrl = sourceQuery;
    track.duration = track.duration || resolved.duration;
    track.durationText = track.durationText || resolved.durationText;
    track.thumbnail = track.thumbnail || resolved.thumbnail;
  }

  const ytdlp = spawn(
    'yt-dlp',
    [
      '--no-playlist',
      '--no-warnings',
      '--quiet',
      '--format',
      'bestaudio/best',
      '--output',
      '-',
      sourceQuery,
    ],
    { stdio: ['ignore', 'pipe', 'pipe'] }
  );

  const ffmpeg = spawn(
    'ffmpeg',
    [
      '-hide_banner',
      '-loglevel',
      'error',
      '-i',
      'pipe:0',
      '-af',
      ffmpegFilter(state.equalizer),
      '-f',
      's16le',
      '-ar',
      '48000',
      '-ac',
      '2',
      'pipe:1',
    ],
    { stdio: ['pipe', 'pipe', 'pipe'] }
  );

  const errors = [];

  ytdlp.stderr.on('data', chunk => errors.push(chunk.toString()));
  ffmpeg.stderr.on('data', chunk => errors.push(chunk.toString()));

  ytdlp.stdout.pipe(ffmpeg.stdin);

  state.process = [ytdlp, ffmpeg];

  const resource = createAudioResource(ffmpeg.stdout, {
    inputType: StreamType.Raw,
    inlineVolume: true,
    metadata: track,
  });

  resource.volume?.setVolume(state.volume);
  state.player.play(resource);

  ytdlp.once('close', code => {
    if (code !== 0 && state.current?.id === track.id) {
      console.error(
        `yt-dlp playback failed (${code}): ${errors.join('').slice(0, 1200)}`
      );
    }
  });
}

function pause(guildId) {
  const state = stateFor(guildId);
  const paused = state.player.pause();

  if (paused) state.pausedAt = Date.now();
  return paused;
}

function resume(guildId) {
  const state = stateFor(guildId);
  const resumed = state.player.unpause();

  if (resumed && state.pausedAt) {
    state.pausedTotal += Date.now() - state.pausedAt;
    state.pausedAt = null;
  }

  return resumed;
}

function skip(guildId) {
  const state = stateFor(guildId);
  cleanupProcesses(state);
  return state.player.stop(true);
}

function stop(guildId) {
  const state = stateFor(guildId);
  state.manuallyStopped = true;
  state.queue = [];
  state.current = null;
  cleanupProcesses(state);
  state.player.stop(true);

  if (state.connection) {
    try {
      state.connection.destroy();
    } catch {}
  }

  state.connection = null;
  state.voiceChannelId = null;
}

function setVolume(guildId, percentage) {
  const state = stateFor(guildId);
  state.volume = Math.max(0, Math.min(2, Number(percentage) / 100));
  state.player.state.resource?.volume?.setVolume(state.volume);
  return Math.round(state.volume * 100);
}

function setLoop(guildId, mode) {
  if (!['off', 'track', 'queue'].includes(mode)) {
    throw new Error('Invalid loop mode.');
  }

  stateFor(guildId).loop = mode;
  return mode;
}

function toggleShuffle(guildId, value) {
  const state = stateFor(guildId);
  state.shuffle = value ?? !state.shuffle;
  return state.shuffle;
}

function toggleAutoplay(guildId, value) {
  const state = stateFor(guildId);
  state.autoplay = value ?? !state.autoplay;
  return state.autoplay;
}

function setEqualizer(guildId, preset) {
  if (!['flat', 'bass', 'treble', 'vocal', 'nightcore'].includes(preset)) {
    throw new Error('Invalid equalizer preset.');
  }

  stateFor(guildId).equalizer = preset;
  return preset;
}

function snapshot(guildId) {
  const state = stateFor(guildId);
  const end = state.pausedAt || Date.now();

  const elapsed = state.current
    ? Math.max(
        0,
        Math.floor(
          (end - state.startedAt - state.pausedTotal) / 1000
        )
      )
    : 0;

  const settings = store.read('musicSettings')[guildId] || {};

  return {
    guildId,
    configuredVoiceChannelId: settings.voiceChannelId || null,
    configuredTextChannelId: settings.textChannelId || null,
    current: state.current,
    queue: [...state.queue],
    volume: Math.round(state.volume * 100),
    status: state.player.state.status,
    voiceChannelId: state.voiceChannelId,
    textChannelId: state.textChannelId,
    loop: state.loop,
    shuffle: state.shuffle,
    autoplay: state.autoplay,
    equalizer: state.equalizer,
    elapsed,
    duration: state.current?.duration || 0,
  };
}

async function lyrics(guildId) {
  const track = stateFor(guildId).current;
  if (!track) throw new Error('Nothing is playing.');

  const query = new URLSearchParams({
    track_name: track.title,
    artist_name: track.artist || '',
  });

  const response = await fetch(
    `https://lrclib.net/api/search?${query}`,
    {
      headers: { 'User-Agent': 'HelixcraftBot/5.0.1' },
      signal: AbortSignal.timeout(15_000),
    }
  );

  if (!response.ok) throw new Error('Lyrics service unavailable.');

  const results = await response.json();
  return (
    results[0]?.plainLyrics ||
    results[0]?.syncedLyrics ||
    'No lyrics found.'
  );
}

async function handleCommand(interaction) {
  const command = interaction.commandName;
  const guildId = interaction.guildId;

  if (command === 'play') {
    const settings = store.read('musicSettings')[guildId] || {};
    const configuredVoiceChannelId = settings.voiceChannelId;

    if (!configuredVoiceChannelId) {
      return interaction.reply({
        content: 'No fixed music voice channel is configured. Set one in Dashboard → Music Manager.',
        ephemeral: true,
      });
    }

    const voiceChannel = await interaction.guild.channels
      .fetch(configuredVoiceChannelId)
      .catch(() => null);

    if (!voiceChannel || voiceChannel.type !== 2) {
      return interaction.reply({
        content: 'The configured music voice channel no longer exists. Select a new channel in the dashboard.',
        ephemeral: true,
      });
    }

    const configuredTextChannel = settings.textChannelId
      ? await interaction.guild.channels.fetch(settings.textChannelId).catch(() => null)
      : interaction.channel;

    await interaction.deferReply();

    try {
      const result = await enqueue({
        guild: interaction.guild,
        voiceChannel,
        textChannel: configuredTextChannel?.isTextBased() ? configuredTextChannel : interaction.channel,
        query: interaction.options.getString('query'),
        requestedBy: interaction.user.id,
      });

      return interaction.editReply(
        `🎵 Queued **${result.track.title}**${
          result.count > 1 ? ` and ${result.count - 1} more track(s)` : ''
        }.`
      );
    } catch (error) {
      console.error('Play command failed:', error);
      return interaction.editReply(
        `❌ Could not play this item: ${String(error.message || error).slice(0, 1800)}`
      );
    }
  }

  if (command === 'pause') {
    return interaction.reply(
      pause(guildId) ? '⏸️ Paused.' : 'Nothing could be paused.'
    );
  }

  if (command === 'resume') {
    return interaction.reply(
      resume(guildId) ? '▶️ Resumed.' : 'Nothing could be resumed.'
    );
  }

  if (command === 'skip') {
    skip(guildId);
    return interaction.reply('⏭️ Skipped.');
  }

  if (command === 'stop') {
    stop(guildId);
    return interaction.reply('⏹️ Stopped and disconnected.');
  }

  if (command === 'volume') {
    return interaction.reply(
      `🔊 Volume: ${setVolume(
        guildId,
        interaction.options.getInteger('percent')
      )}%`
    );
  }

  if (command === 'loop') {
    return interaction.reply(
      `🔁 Loop: ${setLoop(
        guildId,
        interaction.options.getString('mode')
      )}`
    );
  }

  if (command === 'shuffle') {
    return interaction.reply(
      `🔀 Shuffle: ${toggleShuffle(guildId) ? 'on' : 'off'}`
    );
  }

  if (command === 'autoplay') {
    return interaction.reply(
      `♾️ Autoplay: ${toggleAutoplay(guildId) ? 'on' : 'off'}`
    );
  }

  if (command === 'equalizer') {
    return interaction.reply(
      `🎚️ Equalizer: ${setEqualizer(
        guildId,
        interaction.options.getString('preset')
      )}`
    );
  }

  if (command === 'lyrics') {
    const text = (await lyrics(guildId)).slice(0, 1900);
    return interaction.reply({
      content: `**Lyrics**\n${text}`,
      ephemeral: true,
    });
  }

  const state = snapshot(guildId);

  if (command === 'queue') {
    const lines = [
      state.current ? `**Now:** ${state.current.title}` : '',
      ...state.queue
        .slice(0, 20)
        .map((track, index) => `${index + 1}. ${track.title}`),
    ].filter(Boolean);

    return interaction.reply({
      content: lines.join('\n') || 'Queue empty.',
      ephemeral: true,
    });
  }

  if (command === 'nowplaying') {
    return interaction.reply(
      state.current
        ? `🎧 **${state.current.title}** — ${state.elapsed}s / ${
            state.duration || '?'
          }s`
        : 'Nothing is playing.'
    );
  }
}

module.exports = {
  enqueue,
  pause,
  resume,
  skip,
  stop,
  setVolume,
  setLoop,
  toggleShuffle,
  toggleAutoplay,
  setEqualizer,
  snapshot,
  lyrics,
  dependencyStatus,
  handleCommand,
};
