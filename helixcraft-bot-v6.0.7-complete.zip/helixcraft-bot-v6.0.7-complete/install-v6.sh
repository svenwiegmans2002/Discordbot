#!/usr/bin/env bash
set -Eeuo pipefail

SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ACTIVE_DIR="/root/helixcraft-bot"
STAMP="$(date +%Y%m%d-%H%M%S)"
BACKUP_DIR="/root/helixcraft-bot-backup-${STAMP}"

echo "[1/9] Node.js controleren"
NODE_MAJOR="$(node -p "Number(process.versions.node.split('.')[0])" 2>/dev/null || echo 0)"
if [ "$NODE_MAJOR" -lt 22 ]; then
  echo "Node.js 22.12 of hoger is vereist."
  exit 1
fi

echo "[2/9] Systeempakketten installeren"
apt-get update
DEBIAN_FRONTEND=noninteractive apt-get install -y \
  ffmpeg yt-dlp ca-certificates curl unzip openssl

echo "[3/9] Huidige installatie back-uppen"
if [ -d "$ACTIVE_DIR" ]; then
  cp -a "$ACTIVE_DIR" "$BACKUP_DIR"

  if [ -s "$ACTIVE_DIR/.env" ]; then
    cp "$ACTIVE_DIR/.env" "$SOURCE_DIR/.env"
  fi

  if [ -d "$ACTIVE_DIR/data" ]; then
    mkdir -p "$SOURCE_DIR/data"
    cp -a "$ACTIVE_DIR/data/." "$SOURCE_DIR/data/"
  fi

  if [ -d "$ACTIVE_DIR/transcripts" ]; then
    mkdir -p "$SOURCE_DIR/transcripts"
    cp -a "$ACTIVE_DIR/transcripts/." "$SOURCE_DIR/transcripts/"
  fi
fi

echo "[4/9] .env controleren"
if [ ! -s "$SOURCE_DIR/.env" ]; then
  cp "$SOURCE_DIR/.env.example" "$SOURCE_DIR/.env"

  if ! grep -q '^SESSION_SECRET=.\+' "$SOURCE_DIR/.env"; then
    sed -i "s/^SESSION_SECRET=.*/SESSION_SECRET=$(openssl rand -hex 32)/" "$SOURCE_DIR/.env"
  fi

  echo
  echo "Er was geen geldige bestaande .env."
  echo "Vul eerst de waarden in:"
  echo "nano $SOURCE_DIR/.env"
  echo
  exit 1
fi

if ! grep -q '^SESSION_SECRET=.\+' "$SOURCE_DIR/.env"; then
  echo "SESSION_SECRET=$(openssl rand -hex 32)" >> "$SOURCE_DIR/.env"
fi

echo "[5/9] npm registry herstellen"
npm config delete proxy >/dev/null 2>&1 || true
npm config delete https-proxy >/dev/null 2>&1 || true
npm config set registry https://registry.npmjs.org/
rm -rf "$SOURCE_DIR/node_modules" "$SOURCE_DIR/package-lock.json"

echo "[6/9] Dependencies installeren"
cd "$SOURCE_DIR"
for attempt in 1 2 3; do
  if npm install --no-audit --no-fund; then
    break
  fi

  if [ "$attempt" -eq 3 ]; then
    echo "npm install is na drie pogingen mislukt."
    exit 1
  fi

  npm cache clean --force || true
  sleep 5
done

echo "[7/9] Project controleren"
npm run check
npm run validate-env

echo "[8/9] Actieve map vervangen"
systemctl stop helixcraft-bot.service >/dev/null 2>&1 || true
pkill -f "/root/helixcraft-bot/index.js" >/dev/null 2>&1 || true

rm -rf "$ACTIVE_DIR"
mv "$SOURCE_DIR" "$ACTIVE_DIR"

echo "[9/9] systemd-service installeren en starten"
cat >/etc/systemd/system/helixcraft-bot.service <<'UNIT'
[Unit]
Description=Helixcraft Discord Bot v6
After=network-online.target
Wants=network-online.target

[Service]
Type=simple
WorkingDirectory=/root/helixcraft-bot
ExecStart=/usr/bin/env node /root/helixcraft-bot/index.js
Restart=always
RestartSec=5
Environment=NODE_ENV=production
LimitNOFILE=65536

[Install]
WantedBy=multi-user.target
UNIT

systemctl daemon-reload
systemctl enable helixcraft-bot.service
systemctl restart helixcraft-bot.service
sleep 3

systemctl --no-pager --full status helixcraft-bot.service || true

echo
echo "Helixcraft Bot v6 is geïnstalleerd."
echo "Backup: $BACKUP_DIR"
echo "Logs: journalctl -u helixcraft-bot -f"
