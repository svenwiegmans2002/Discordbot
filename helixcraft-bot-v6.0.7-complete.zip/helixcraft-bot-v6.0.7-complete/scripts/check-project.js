const { execFileSync } = require('node:child_process');
const fs = require('node:fs');
const path = require('node:path');

const root = path.join(__dirname, '..');
const files = [
  path.join(root, 'index.js'),
  ...fs.readdirSync(path.join(root, 'src'))
    .filter(file => file.endsWith('.js'))
    .map(file => path.join(root, 'src', file)),
  ...fs.readdirSync(path.join(root, 'scripts'))
    .filter(file => file.endsWith('.js'))
    .map(file => path.join(root, 'scripts', file)),
];

for (const file of files) {
  execFileSync(process.execPath, ['--check', file], {
    stdio: 'inherit',
  });
}

execFileSync(process.execPath, [
  path.join(root, 'scripts', 'validate-commands.js'),
], {
  stdio: 'inherit',
});

console.log(`Checked ${files.length} JavaScript files.`);
