const REQUIRED = [
  'BOT_TOKEN',
  'CLIENT_ID',
  'CLIENT_SECRET',
  'GUILD_ID',
  'SESSION_SECRET',
  'DASHBOARD_URL',
];

function missingEnvironmentVariables() {
  return REQUIRED.filter(name => !String(process.env[name] || '').trim());
}

function validateEnvironment() {
  const missing = missingEnvironmentVariables();

  if (missing.length) {
    throw new Error(
      `Missing required environment variables: ${missing.join(', ')}. ` +
      'Copy .env.example to .env and enter the real values.'
    );
  }

  if (!/^https:\/\//i.test(process.env.DASHBOARD_URL)) {
    console.warn(
      'Warning: DASHBOARD_URL does not use HTTPS. Discord and Spotify OAuth ' +
      'should use the public Cloudflare HTTPS hostname.'
    );
  }

  if (
    process.env.SPOTIFY_REDIRECT_URI &&
    !process.env.SPOTIFY_REDIRECT_URI.startsWith(
      process.env.DASHBOARD_URL.replace(/\/$/, '')
    )
  ) {
    console.warn(
      'Warning: SPOTIFY_REDIRECT_URI does not start with DASHBOARD_URL.'
    );
  }

  return true;
}

if (require.main === module) {
  require('dotenv').config();
  validateEnvironment();
  console.log('Environment validation passed.');
}

module.exports = {
  validateEnvironment,
  missingEnvironmentVariables,
};
