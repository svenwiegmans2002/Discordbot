#!/usr/bin/env bash
set -euo pipefail

cd /root/helixcraft-bot

echo "Node: $(node -v)"
echo "npm: $(npm -v)"
echo "FFmpeg: $(ffmpeg -version | head -n1)"
echo "yt-dlp: $(yt-dlp --version)"
echo

echo "Bestanden:"
for file in index.js package.json .env src/bot.js src/dashboard.js src/music.js; do
  if [ -e "$file" ]; then
    echo "OK   $file"
  else
    echo "MISS $file"
  fi
done

echo
echo "Environment:"
for key in BOT_TOKEN CLIENT_ID CLIENT_SECRET GUILD_ID SESSION_SECRET DASHBOARD_URL DISCORD_REDIRECT_URI SPOTIFY_CLIENT_ID SPOTIFY_CLIENT_SECRET SPOTIFY_REDIRECT_URI; do
  if grep -q "^${key}=.\+" .env 2>/dev/null; then
    echo "OK   $key"
  else
    echo "MISS $key"
  fi
done

echo
systemctl --no-pager --full status helixcraft-bot.service || true
