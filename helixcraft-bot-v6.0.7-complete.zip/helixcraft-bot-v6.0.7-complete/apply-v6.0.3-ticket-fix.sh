#!/usr/bin/env bash
set -Eeuo pipefail

SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ACTIVE_DIR="/root/helixcraft-bot"
STAMP="$(date +%Y%m%d-%H%M%S)"

if [ ! -f "$ACTIVE_DIR/src/v4.js" ]; then
  echo "Active bot not found at $ACTIVE_DIR"
  exit 1
fi

cp "$ACTIVE_DIR/src/v4.js" "/root/v4.js.backup-$STAMP"
cp "$SOURCE_DIR/src/v4.js" "$ACTIVE_DIR/src/v4.js"
cp "$SOURCE_DIR/package.json" "$ACTIVE_DIR/package.json"
cp "$SOURCE_DIR/index.js" "$ACTIVE_DIR/index.js"

cd "$ACTIVE_DIR"
node --check src/v4.js
node --check index.js

if systemctl list-unit-files | grep -q '^helixcraft-bot.service'; then
  systemctl restart helixcraft-bot
  sleep 3
  systemctl --no-pager --full status helixcraft-bot || true
else
  pkill -f "/root/helixcraft-bot/index.js" 2>/dev/null || true
  echo "Patch applied. Start with: cd /root/helixcraft-bot && npm start"
fi

echo
echo "v6.0.3 ticket category fix applied."
echo "IMPORTANT: delete the old Discord ticket panel and run /ticket-panel-v2 again."
