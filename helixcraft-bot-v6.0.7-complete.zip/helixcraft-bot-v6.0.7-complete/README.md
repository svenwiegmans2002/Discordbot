# Helixcraft Bot v6.0.7 Complete

Deze versie bevat alle Event- en Giveaway-uitbreidingen samen, inclusief de
slash-command deployment-fix.

## Event commands

```text
/event create
/event list
/event edit
/event start
/event cancel
/event delete
```

De verplichte opties van `/event create` staan nu vóór alle optionele opties,
waardoor Discord de commands correct accepteert.

## Event Manager dashboard

- events aanmaken;
- voice-, stage- en externe events;
- naam, beschrijving, start, einde en locatie aanpassen;
- events direct starten;
- annuleren;
- verwijderen;
- aantal geïnteresseerde deelnemers tonen;
- een eventbericht posten naar een gekozen tekstkanaal;
- eventbericht met naam, beschrijving, datum, locatie, deelnemersaantal en link.

## Giveaway Manager dashboard

- giveaway aanmaken;
- prijs, duur en aantal winnaars;
- vereist rol;
- bonus-entryrol;
- minimale accountleeftijd;
- minimale serverlidmaatschapsduur;
- aantal unieke deelnemers tonen;
- pauzeren;
- hervatten;
- direct beëindigen;
- opnieuw loten;
- verwijderen;
- giveawaybericht posten of vernieuwen;
- directe link naar het Discord-bericht.

## Installeren

```bash
cd /root/helixcraft-bot-v6.0.7-complete
chmod +x apply-v6.0.7-complete.sh
./apply-v6.0.7-complete.sh
```

Als uitvoeren met `./` niet lukt:

```bash
bash apply-v6.0.7-complete.sh
```

Controleer daarna:

```bash
journalctl -u helixcraft-bot -n 100 --no-pager
```

Je hoort te zien:

```text
Slash commands deployed.
```
