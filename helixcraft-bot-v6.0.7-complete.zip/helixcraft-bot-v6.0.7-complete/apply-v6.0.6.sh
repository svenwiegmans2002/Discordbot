#!/usr/bin/env bash
set -Eeuo pipefail

SOURCE_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
ACTIVE_DIR="/root/helixcraft-bot"
STAMP="$(date +%Y%m%d-%H%M%S)"

for file in src/commands.js src/dashboard.js src/store.js index.js package.json; do
  if [ -f "$ACTIVE_DIR/$file" ]; then
    cp "$ACTIVE_DIR/$file" "/root/$(basename "$file").backup-$STAMP"
  fi
  cp "$SOURCE_DIR/$file" "$ACTIVE_DIR/$file"
done

mkdir -p "$ACTIVE_DIR/data"
if [ ! -f "$ACTIVE_DIR/data/eventAnnouncements.json" ]; then
  echo '{}' > "$ACTIVE_DIR/data/eventAnnouncements.json"
fi

cd "$ACTIVE_DIR"
npm install --no-audit --no-fund
node --check src/commands.js
node --check src/dashboard.js
node --check src/store.js
node --check index.js
node scripts/validate-commands.js

if systemctl list-unit-files | grep -q '^helixcraft-bot.service'; then
  systemctl restart helixcraft-bot
  sleep 4
  systemctl --no-pager --full status helixcraft-bot || true
else
  pkill -f "/root/helixcraft-bot/index.js" 2>/dev/null || true
  echo "Patch applied. Start with: cd /root/helixcraft-bot && npm start"
fi

echo
echo "v6.0.6 installed."
echo "/event has been validated and will be deployed on startup."
