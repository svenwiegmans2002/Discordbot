const fs = require('fs');
const path = require('path');
const crypto = require('crypto');
const { EmbedBuilder, PermissionFlagsBits } = require('discord.js');
const { guildConfig } = require('./store');

const BRAND = { color: 0x5865f2, success: 0x57f287, warning: 0xfee75c, error: 0xed4245 };
function embed(title, description, color = BRAND.color) { return new EmbedBuilder().setTitle(title).setDescription(description).setColor(color).setFooter({text:'Helixcraft Management System'}).setTimestamp(); }
function parseDuration(v) { const m=/^(\d+)(s|m|h|d)$/i.exec(String(v).trim()); if(!m) throw new Error('Use 30s, 10m, 2h or 3d.'); return Number(m[1])*({s:1e3,m:6e4,h:36e5,d:864e5}[m[2].toLowerCase()]); }
function id(bytes=4){ return crypto.randomBytes(bytes).toString('hex'); }
function htmlEscape(v=''){ return String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c])); }
async function log(client,guild,title,description,color=BRAND.color){ const cfg=guildConfig(guild.id); const ch=cfg.logChannelId && guild.channels.cache.get(cfg.logChannelId); if(ch?.isTextBased()) await ch.send({embeds:[embed(title,description,color)]}).catch(()=>{}); }
function canManageRole(guild, role){ return role && guild.members.me && role.position < guild.members.me.roles.highest.position && !role.managed; }
async function transcript(channel){
 const rows=[];
 let before=null;
 let pages=0;

 while(rows.length<5000&&pages<50){
  const options={limit:100};
  if(before)options.before=before;

  const batch=await channel.messages.fetch(options);
  if(!batch.size)break;

  const list=[...batch.values()];
  rows.push(...list);
  before=list[list.length-1]?.id||null;
  pages+=1;

  if(batch.size<100)break;
 }

 rows.sort((a,b)=>a.createdTimestamp-b.createdTimestamp);

 const body=rows.map(message=>{
  const attachments=[...message.attachments.values()]
   .map(file=>`<a href="${htmlEscape(file.url)}">${htmlEscape(file.name||'attachment')}</a>`)
   .join('<br>');

  const embeds=(message.embeds||[])
   .map(item=>`<div class="embed"><b>${htmlEscape(item.title||'Embed')}</b><p>${htmlEscape(item.description||'')}</p></div>`)
   .join('');

  const content=message.content
   ? `<pre>${htmlEscape(message.content)}</pre>`
   : '<pre class="muted">[No text content]</pre>';

  return [
   '<article>',
   `<header><b>${htmlEscape(message.author?.tag||'Unknown user')}</b>`,
   `<small>${new Date(message.createdTimestamp).toISOString()}</small></header>`,
   content,
   attachments?`<div class="attachments">${attachments}</div>`:'',
   embeds,
   '</article>'
  ].join('');
 }).join('');

 return [
  '<!doctype html>',
  '<html><head><meta charset="utf-8">',
  `<title>${htmlEscape(channel.name)} transcript</title>`,
  '<style>',
  'body{font-family:Arial,sans-serif;background:#101218;color:#eee;padding:24px;max-width:1100px;margin:auto}',
  'article{padding:14px;border-bottom:1px solid #333;background:#181b22;margin:8px 0;border-radius:8px}',
  'header{display:flex;gap:10px;align-items:center}',
  'small{color:#999}',
  'pre{white-space:pre-wrap;word-break:break-word;font-family:inherit}',
  '.muted{color:#888}.attachments a{color:#7aa2ff}.embed{border-left:4px solid #5865f2;padding:8px 12px;background:#20232b;margin-top:8px}',
  '</style></head><body>',
  `<h1>${htmlEscape(channel.name)}</h1>`,
  `<p>Messages: ${rows.length}</p>`,
  body,
  '</body></html>'
 ].join('');
}
module.exports={BRAND,embed,parseDuration,id,htmlEscape,log,canManageRole,transcript};
