const crypto = require('node:crypto');
const express = require('express');
const session = require('express-session');
const { guildConfig, setGuildConfig, read } = require('./store');
const { embed, BRAND, parseDuration } = require('./utils');
const { ActionRowBuilder, ButtonBuilder, ButtonStyle, GuildScheduledEventEntityType, GuildScheduledEventPrivacyLevel, GuildScheduledEventStatus, ChannelType } = require('discord.js');
const music = require('./music');
const messageStudio = require('./messageStudio');
const store = require('./store');
const spotifyOAuth = require('./spotifyOAuth');
const stats = require('./stats');
const studioV5 = require('./messageStudioV5');
const os = require('node:os');

const API = 'https://discord.com/api/v10';

async function api(path, token, method = 'GET', body) {
  const response = await fetch(API + path, {
    method,
    headers: {
      Authorization: `Bearer ${token}`,
      'Content-Type': 'application/json',
    },
    body: body ? JSON.stringify(body) : undefined,
  });

  if (!response.ok) {
    const message = await response.text();
    const error = new Error(`Discord API ${response.status}: ${message}`);
    error.status = response.status;
    throw error;
  }

  return response.status === 204 ? null : response.json();
}

function escapeHtml(value = '') {
  return String(value)
    .replaceAll('&', '&amp;')
    .replaceAll('<', '&lt;')
    .replaceAll('>', '&gt;')
    .replaceAll('"', '&quot;')
    .replaceAll("'", '&#039;');
}

function selected(current, value) {
  return String(current ?? '') === String(value ?? '') ? ' selected' : '';
}

function checked(value) {
  return value ? ' checked' : '';
}

function optionList(items, current, label, includeNone = true) {
  const none = includeNone ? `<option value=""${selected(current, '')}>Not configured</option>` : '';
  return none + items.map(item => (
    `<option value="${item.id}"${selected(current, item.id)}>${escapeHtml(label(item))}</option>`
  )).join('');
}

function navItem(href, label, active, icon = '') {
  return `<a class="nav-item${active === href ? ' active' : ''}" href="${href}"><span>${icon}</span>${label}</a>`;
}

function layout({ title, body, user, guild, active = '', notice = '', error = '' }) {
  const guildId = guild?.id;
  const sidebar = guildId ? `
    <div class="guild-label">${escapeHtml(guild.name)}</div>
    ${navItem(`/g/${guildId}`, 'Overview', active, '⌂')}
    <div class="nav-heading">Settings</div>
    ${navItem(`/g/${guildId}/settings/general`, 'General & Welcome', active, '⚙')}
    ${navItem(`/g/${guildId}/settings/tickets`, 'Tickets', active, '🎫')}
    ${navItem(`/g/${guildId}/settings/moderation`, 'Moderation', active, '🛡')}
    ${navItem(`/g/${guildId}/settings/server`, 'Server features', active, '🧩')}

    ${navItem(`/g/${guildId}/settings/automod`, 'AutoMod', active, '🤖')}
    ${navItem(`/g/${guildId}/settings/levels`, 'Levels', active, '📈')}
    ${navItem(`/g/${guildId}/settings/economy`, 'Economy', active, '💰')}
    ${navItem(`/g/${guildId}/audit`, 'Audit logs', active, '📜')}

    <div class="nav-heading">Management</div>
    ${navItem(`/g/${guildId}/warnings`, 'Warnings', active, '⚠')}
    ${navItem(`/g/${guildId}/tickets`, 'Ticket records', active, '▣')}
    ${navItem(`/g/${guildId}/giveaways`, 'Giveaways', active, '🎉')}
    ${navItem(`/g/${guildId}/events`, 'Events', active, '📅')}
    ${navItem(`/g/${guildId}/embed`, 'Embed builder', active, '✎')}
    ${navItem(`/g/${guildId}/message-studio`, 'Message Studio', active, '✉')}
    ${navItem(`/g/${guildId}/music`, 'Music Manager', active, '♫')}
    ${navItem(`/g/${guildId}/v5`, 'V5 Control Center', active, '◆')}
    ${navItem(`/g/${guildId}/studio-v5`, 'Message Studio V5', active, '✦')}
    ${navItem(`/g/${guildId}/analytics-v5`, 'Live Analytics', active, '↗')}
    ${navItem(`/g/${guildId}/search-v5`, 'Global Search', active, '⌕')}
  ` : navItem('/servers', 'Servers', active, '▦');

  return `<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1">
  <title>${escapeHtml(title)} · Helixcraft</title>
  <style>
    :root{--bg:#080d18;--panel:#11192a;--panel2:#162138;--border:#273654;--text:#eef3ff;--muted:#9ba9c3;--brand:#5865f2;--green:#3ba55d;--red:#ed4245;--orange:#f0a202}
    *{box-sizing:border-box}body{margin:0;background:linear-gradient(135deg,#0b1222,#070b13 65%);color:var(--text);font-family:Inter,ui-sans-serif,system-ui,-apple-system,Segoe UI,sans-serif;min-height:100vh}
    a{color:inherit;text-decoration:none}.shell{display:grid;grid-template-columns:260px minmax(0,1fr);min-height:100vh}.sidebar{background:rgba(12,18,31,.97);border-right:1px solid var(--border);padding:22px 16px;position:sticky;top:0;height:100vh;overflow-y:auto}.brand{font-size:19px;font-weight:900;padding:0 10px 20px}.brand small{display:block;color:var(--muted);font-size:11px;margin-top:4px;font-weight:600}.guild-label{margin:6px 10px 14px;color:#fff;font-weight:800;overflow:hidden;text-overflow:ellipsis}.nav-heading{color:#71809b;text-transform:uppercase;letter-spacing:.09em;font-size:11px;font-weight:800;margin:20px 12px 7px}.nav-item{display:flex;gap:10px;align-items:center;padding:10px 12px;border-radius:10px;color:#c8d2e8;margin:3px 0;font-size:14px;font-weight:650}.nav-item:hover{background:#18233a}.nav-item.active{background:rgba(88,101,242,.2);color:#fff;border:1px solid rgba(88,101,242,.35)}
    .content-wrap{min-width:0}.topbar{height:64px;border-bottom:1px solid var(--border);background:rgba(8,13,24,.82);backdrop-filter:blur(14px);display:flex;align-items:center;justify-content:flex-end;padding:0 28px;position:sticky;top:0;z-index:5}.user{display:flex;gap:12px;align-items:center;color:var(--muted);font-size:14px}.logout{color:#dce4ff;font-weight:700}.main{max-width:1180px;margin:0 auto;padding:32px}.page-head{display:flex;align-items:flex-end;justify-content:space-between;gap:20px;margin-bottom:24px}.page-head h1{margin:0;font-size:30px}.page-head p{margin:7px 0 0;color:var(--muted)}
    .grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:16px}.stat,.card,.form-card{background:rgba(17,25,42,.95);border:1px solid var(--border);border-radius:16px;box-shadow:0 16px 40px rgba(0,0,0,.18)}.stat{padding:20px}.stat strong{font-size:32px;display:block}.stat span{color:var(--muted);font-size:13px}.card{padding:20px}.card h2,.form-card h2{margin:0 0 7px}.card p{color:var(--muted);line-height:1.6}.form-card{padding:22px;margin-bottom:18px}.section-title{display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid var(--border);padding-bottom:14px;margin-bottom:18px}.section-title p{margin:4px 0 0;color:var(--muted);font-size:13px}
    .fields{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:16px}.field.full{grid-column:1/-1}.field label{display:block;font-weight:750;font-size:13px;margin-bottom:7px}.hint{display:block;color:var(--muted);font-size:12px;margin-top:6px;line-height:1.45}input,select,textarea{width:100%;border:1px solid #334565;background:#090f1c;color:#fff;padding:11px 12px;border-radius:10px;font:inherit;outline:none}input:focus,select:focus,textarea:focus{border-color:var(--brand);box-shadow:0 0 0 3px rgba(88,101,242,.14)}textarea{min-height:120px;resize:vertical}.actions{display:flex;align-items:center;justify-content:flex-end;gap:12px;border-top:1px solid var(--border);padding-top:18px;margin-top:20px}.button,button{border:0;border-radius:10px;background:var(--brand);color:#fff;padding:11px 17px;font-weight:800;cursor:pointer;font:inherit}.button.secondary{background:#1a263e;border:1px solid var(--border)}button:hover,.button:hover{filter:brightness(1.08)}
    .notice,.error{border-radius:12px;padding:13px 15px;margin-bottom:18px;font-weight:650}.notice{background:rgba(59,165,93,.14);border:1px solid rgba(59,165,93,.45);color:#baf2ca}.error{background:rgba(237,66,69,.13);border:1px solid rgba(237,66,69,.45);color:#ffc2c3}.empty{color:var(--muted);padding:28px;text-align:center}.table-wrap{overflow:auto;border:1px solid var(--border);border-radius:14px;background:var(--panel)}table{width:100%;border-collapse:collapse;font-size:13px}th,td{padding:12px 13px;text-align:left;border-bottom:1px solid var(--border);white-space:nowrap}th{background:#121c30;color:#aebbd1;position:sticky;top:0}td{max-width:420px;overflow:hidden;text-overflow:ellipsis}.badge{display:inline-flex;border-radius:999px;padding:4px 9px;background:#1b2842;color:#cad7f1;font-size:11px;font-weight:800}.quick-links{display:grid;grid-template-columns:repeat(auto-fit,minmax(210px,1fr));gap:14px;margin-top:20px}.quick-link{padding:18px;background:var(--panel);border:1px solid var(--border);border-radius:14px}.quick-link b{display:block;margin-bottom:6px}.quick-link span{color:var(--muted);font-size:13px}.login{max-width:600px;margin:10vh auto;padding:42px;text-align:center}.login h1{font-size:40px;margin:0}.login p{color:var(--muted);font-size:17px;line-height:1.6}.checkbox-row{display:flex;align-items:flex-start;gap:10px;padding:12px;border:1px solid var(--border);border-radius:10px;background:#0c1322}.checkbox-row input{width:auto;margin-top:2px}.checkbox-row label{margin:0}.danger-note{color:#f6c45f;font-size:12px}
    .preview-shell{display:grid;grid-template-columns:minmax(0,1fr) minmax(300px,.8fr);gap:18px}.discord-preview{background:#313338;border-radius:14px;padding:18px;color:#dbdee1;min-height:260px}.discord-message{display:flex;gap:12px}.avatar{width:42px;height:42px;border-radius:50%;background:#5865f2;display:grid;place-items:center;font-weight:900}.message-body{min-width:0;flex:1}.message-author{font-weight:800;color:#fff}.message-text{white-space:pre-wrap;line-height:1.45;margin-top:4px}.embed-preview{border-left:4px solid #5865f2;background:#2b2d31;border-radius:4px;padding:13px;margin-top:8px}.embed-preview h3{margin:0 0 7px;color:#fff}.embed-preview p{white-space:pre-wrap;margin:0}.component-preview{display:flex;gap:8px;flex-wrap:wrap;margin-top:10px}.fake-button{background:#4e5058;color:#fff;padding:8px 12px;border-radius:4px;font-size:13px}.music-now{font-size:20px;font-weight:850}.queue-list{margin:12px 0 0;padding-left:22px}.two-col{display:grid;grid-template-columns:1fr 1fr;gap:16px}
    @media(max-width:1000px){.preview-shell{grid-template-columns:1fr}.two-col{grid-template-columns:1fr}}
    @media(max-width:800px){.shell{grid-template-columns:1fr}.sidebar{position:static;height:auto;border-right:0;border-bottom:1px solid var(--border)}.content-wrap{min-width:0}.main{padding:22px 15px}.fields{grid-template-columns:1fr}.topbar{position:static}.page-head{align-items:flex-start;flex-direction:column}}
  </style>
</head>
<body>
<div class="shell">
  <aside class="sidebar">
    <div class="brand">Helixcraft Dashboard<small>Bot administration</small></div>
    ${sidebar}
  </aside>
  <section class="content-wrap">
    <header class="topbar"><div class="user">${user ? `${escapeHtml(user.username)} <a class="logout" href="/logout">Log out</a>` : '<a class="logout" href="/login">Log in</a>'}</div></header>
    <main class="main">
      ${notice ? `<div class="notice">✓ ${escapeHtml(notice)}</div>` : ''}
      ${error ? `<div class="error">${escapeHtml(error)}</div>` : ''}
      ${body}
    </main>
  </section>
</div>
</body>
</html>`;
}

function pageHead(title, description, action = '') {
  return `<div class="page-head"><div><h1>${escapeHtml(title)}</h1><p>${escapeHtml(description)}</p></div>${action}</div>`;
}

function protect(req, res, next) {
  if (!req.session.token) return res.redirect('/login');
  next();
}

async function getManageableGuilds(req, client, force = false) {
  const now = Date.now();
  if (!force && req.session.guildCache && now - req.session.guildCacheTime < 120000) {
    return req.session.guildCache;
  }

  const discordToken =
    req.session.token ||
    req.session.accessToken ||
    req.session.discordAccessToken;

  if (!discordToken) {
    const error = new Error('Discord login token is missing from the session.');
    error.status = 401;
    throw error;
  }

  const userGuilds = await api('/users/@me/guilds', discordToken);
  const botGuilds = new Set(client.guilds.cache.keys());
  const manageable = userGuilds.filter(guild => {
    const permissions = BigInt(guild.permissions || '0');
    return botGuilds.has(guild.id) && ((permissions & 8n) !== 0n || (permissions & 32n) !== 0n);
  });

  req.session.guildCache = manageable;
  req.session.guildCacheTime = now;
  return manageable;
}

function parseNullableString(value) {
  const trimmed = String(value ?? '').trim();
  return trimmed === '' ? null : trimmed;
}

function parseInteger(value, fallback, min = 0, max = Number.MAX_SAFE_INTEGER) {
  const parsed = Number.parseInt(value, 10);
  if (!Number.isFinite(parsed)) return fallback;
  return Math.min(max, Math.max(min, parsed));
}

function table(rows, preferredColumns = null) {
  if (!rows.length) return '<div class="card empty">No records found.</div>';
  const keys = preferredColumns || Object.keys(rows[0]);
  return `<div class="table-wrap"><table><thead><tr>${keys.map(key => `<th>${escapeHtml(key)}</th>`).join('')}</tr></thead><tbody>${rows.map(row => `<tr>${keys.map(key => {
    const value = typeof row[key] === 'object' && row[key] !== null ? JSON.stringify(row[key]) : row[key] ?? '';
    return `<td title="${escapeHtml(value)}">${escapeHtml(value)}</td>`;
  }).join('')}</tr>`).join('')}</tbody></table></div>`;
}


function giveawayId() {
  return `${Date.now().toString(36)}${crypto.randomBytes(3).toString('hex')}`;
}

function giveawayComponents(giveawayIdValue, disabled = false) {
  return [
    new ActionRowBuilder().addComponents(
      new ButtonBuilder()
        .setCustomId(`gw:join:${giveawayIdValue}`)
        .setLabel('Enter / Leave')
        .setEmoji('🎉')
        .setStyle(ButtonStyle.Success)
        .setDisabled(disabled)
    ),
  ];
}

function giveawayDescription(giveaway) {
  const requirements = [
    giveaway.requiredRoleId ? `Required role: <@&${giveaway.requiredRoleId}>` : null,
    giveaway.bonusRoleId ? `Bonus role: <@&${giveaway.bonusRoleId}>` : null,
    giveaway.minAccountDays ? `Minimum account age: ${giveaway.minAccountDays} day(s)` : null,
    giveaway.minMemberDays ? `Minimum membership: ${giveaway.minMemberDays} day(s)` : null,
  ].filter(Boolean);

  return [
    `**Prize:** ${giveaway.prize}`,
    `**Winners:** ${giveaway.winners}`,
    giveaway.paused
      ? '**Status:** Paused'
      : giveaway.ended
        ? '**Status:** Ended'
        : `**Ends:** <t:${Math.floor(giveaway.endsAt / 1000)}:R>`,
    `**Entries:** ${new Set(giveaway.entries || []).size}`,
    requirements.length ? `\n**Requirements**\n${requirements.join('\n')}` : '',
    `\n**ID:** \`${giveaway.id}\``,
  ].join('\n');
}

async function dashboardFinishGiveaway(client, guild, giveawayIdValue, reroll = false) {
  const all = store.read('giveaways');
  const giveaway = all[giveawayIdValue];

  if (!giveaway || giveaway.guildId !== guild.id) {
    throw new Error('Giveaway not found.');
  }

  const channel = await guild.channels.fetch(giveaway.channelId).catch(() => null);
  if (!channel?.isTextBased()) throw new Error('Giveaway channel no longer exists.');

  const weightedPool = [];
  for (const userId of [...new Set(giveaway.entries || [])]) {
    weightedPool.push(userId);
    if ((giveaway.bonusEntries || []).includes(userId)) weightedPool.push(userId);
  }

  const winners = [];
  while (weightedPool.length && winners.length < giveaway.winners) {
    const index = crypto.randomInt(weightedPool.length);
    const userId = weightedPool.splice(index, 1)[0];
    if (!winners.includes(userId)) winners.push(userId);
  }

  if (!reroll) {
    giveaway.ended = true;
    giveaway.paused = false;
    giveaway.winnerIds = winners;
    giveaway.endedAt = Date.now();
    all[giveaway.id] = giveaway;
    store.write('giveaways', all);

    const message = await channel.messages.fetch(giveaway.messageId).catch(() => null);
    if (message) {
      await message.edit({
        embeds: [
          embed(
            '🎉 Giveaway ended',
            `**Prize:** ${giveaway.prize}\n**Winner(s):** ${winners.length ? winners.map(id => `<@${id}>`).join(', ') : 'No valid entries'}\n**ID:** \`${giveaway.id}\``,
            BRAND.warning
          ),
        ],
        components: [],
      }).catch(() => {});
    }
  }

  await channel.send({
    content: winners.length
      ? `🏆 ${winners.map(id => `<@${id}>`).join(', ')} won **${giveaway.prize}**!`
      : `No valid entries for **${giveaway.prize}**.`,
  });

  return winners;
}

function parseDashboardDate(value, label) {
  const timestamp = Date.parse(String(value || ''));
  if (!Number.isFinite(timestamp)) {
    throw new Error(`${label} is invalid.`);
  }
  return new Date(timestamp);
}

function eventStatusLabel(status) {
  return ({
    1: 'Scheduled',
    2: 'Active',
    3: 'Completed',
    4: 'Canceled',
  })[Number(status)] || String(status);
}

async function startDashboard(client) {
  const app = express();
  app.set('trust proxy', 1);
  app.disable('x-powered-by');
  app.use(express.urlencoded({ extended: true, limit: '200kb' }));
  app.use(express.json({ limit: '200kb' }));
  app.use(session({
    name: 'helixcraft.sid',
    secret: process.env.SESSION_SECRET || process.env.DASHBOARD_SECRET || 'change-this-secret',
    resave: false,
    saveUninitialized: false,
    proxy: true,
    cookie: {
      secure: true,
      httpOnly: true,
      sameSite: 'lax',
      maxAge: 24 * 60 * 60 * 1000,
    },
  }));

  app.get('/', (req, res) => {
    if (req.session.user) {
      return res.redirect('/servers');
    }

    const body = `<div class="card login"><h1>Helixcraft</h1><p>Manage your Discord server settings, tickets, moderation, giveaways and events from one clear dashboard.</p><a class="button" href="/login">Log in with Discord</a></div>`;
    return res.send(layout({ title: 'Dashboard', body, user: null, active: '/' }));
  });

  app.get('/login', (req, res) => {
    try {
      const dashboardUrl = String(process.env.DASHBOARD_URL || '').replace(/\/$/, '');
      if (!dashboardUrl) throw new Error('DASHBOARD_URL is missing.');

      const state = crypto.randomBytes(24).toString('hex');
      req.session.discordOAuthState = state;

      req.session.save(error => {
        if (error) {
          console.error('Discord OAuth state save failed:', error);
          return res.status(500).send('Could not start Discord login.');
        }

        const params = new URLSearchParams({
          client_id: process.env.CLIENT_ID,
          response_type: 'code',
          redirect_uri: `${dashboardUrl}/callback`,
          scope: 'identify guilds',
          state,
        });

        return res.redirect(`https://discord.com/oauth2/authorize?${params.toString()}`);
      });
    } catch (error) {
      console.error('Discord login start failed:', error);
      return res.status(500).send(`Discord login failed: ${error.message}`);
    }
  });

  app.get('/callback', async (req, res) => {
    try {
      const code = String(req.query.code || '');
      const returnedState = String(req.query.state || '');
      const expectedState = String(req.session.discordOAuthState || '');

      if (!code) throw new Error('Discord returned no authorization code.');
      if (!returnedState || !expectedState || returnedState !== expectedState) {
        throw new Error('Discord OAuth state validation failed.');
      }

      const dashboardUrl = String(process.env.DASHBOARD_URL || '').replace(/\/$/, '');
      if (!dashboardUrl) throw new Error('DASHBOARD_URL is missing.');

      const body = new URLSearchParams({
        client_id: process.env.CLIENT_ID,
        client_secret: process.env.CLIENT_SECRET,
        grant_type: 'authorization_code',
        code,
        redirect_uri: `${dashboardUrl}/callback`,
      });

      const tokenResponse = await fetch(`${API}/oauth2/token`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body,
        signal: AbortSignal.timeout(20000),
      });

      const tokenText = await tokenResponse.text();
      if (!tokenResponse.ok) {
        throw new Error(`Discord token exchange failed (${tokenResponse.status}): ${tokenText.slice(0, 1000)}`);
      }

      const token = JSON.parse(tokenText);

      const userResponse = await fetch(`${API}/users/@me`, {
        headers: { Authorization: `Bearer ${token.access_token}` },
        signal: AbortSignal.timeout(20000),
      });

      if (!userResponse.ok) {
        throw new Error(`Could not fetch Discord user (${userResponse.status}).`);
      }

      const user = await userResponse.json();

      req.session.discordAccessToken = token.access_token;
      req.session.discordRefreshToken = token.refresh_token || null;
      req.session.discordTokenExpiresAt = Date.now() + Number(token.expires_in || 3600) * 1000;
      req.session.accessToken = token.access_token;
      req.session.token = token.access_token;
      req.session.access_token = token.access_token;
      req.session.user = user;
      delete req.session.discordOAuthState;

      req.session.save(error => {
        if (error) {
          console.error('Discord session save failed:', error);
          return res.status(500).send('Could not save Discord login session.');
        }
        return res.redirect('/servers');
      });
    } catch (error) {
      console.error('Discord OAuth callback failed:', error);
      return res.status(500).send(`Discord login failed: ${error.message}`);
    }
  });

  app.get('/logout', (req, res) => req.session.destroy(() => res.redirect('/')));

  app.get('/servers', protect, async (req, res) => {
    try {
      const guilds = await getManageableGuilds(req, client);
      const cards = guilds.length
        ? guilds.map(guild => `<a class="card" href="/g/${guild.id}"><h2>${escapeHtml(guild.name)}</h2><p>Open settings and management tools.</p><span class="badge">Manage server</span></a>`).join('')
        : '<div class="card empty">No servers found where you have Manage Server or Administrator and the bot is installed.</div>';
      const body = `${pageHead('Your servers', 'Choose a server to configure Helixcraft.')}<div class="grid">${cards}</div>`;
      res.send(layout({ title: 'Servers', body, user: req.session.user, active: '/servers' }));
    } catch (error) {
      const status = error.status === 429 ? 429 : 500;
      const message = error.status === 429 ? 'Discord rate limit reached. Wait a moment and reload the page.' : error.message;
      res.status(status).send(layout({ title: 'Error', body: '', user: req.session.user, active: '/servers', error: message }));
    }
  });

  app.use('/g/:gid', protect, async (req, res, next) => {
    try {
      const manageable = await getManageableGuilds(req, client);
      if (!manageable.some(guild => guild.id === req.params.gid)) {
        return res.status(403).send(layout({ title: 'No access', body: '', user: req.session.user, error: 'You do not have permission to manage this server.' }));
      }
      const guild = client.guilds.cache.get(req.params.gid);
      if (!guild) return res.status(404).send('Guild unavailable');
      req.guild = guild;
      next();
    } catch (error) {
      res.status(500).send(layout({ title: 'Error', body: '', user: req.session.user, error: error.message }));
    }
  });

  app.get('/g/:gid', (req, res) => {
    const guild = req.guild;
    const warnings = read('warnings')[guild.id] || {};
    const tickets = Object.values(read('tickets')).filter(ticket => ticket.guildId === guild.id);
    const giveaways = Object.values(read('giveaways')).filter(giveaway => giveaway.guildId === guild.id);
    const openTickets = tickets.filter(ticket => ticket.status !== 'closed').length;
    const activeGiveaways = giveaways.filter(giveaway => !giveaway.ended).length;
    const warningCount = Object.values(warnings).flat().length;

    const body = `${pageHead(guild.name, 'Overview of your server and bot data.')}
      <div class="grid">
        <div class="stat"><strong>${guild.memberCount}</strong><span>Members</span></div>
        <div class="stat"><strong>${warningCount}</strong><span>Warnings</span></div>
        <div class="stat"><strong>${openTickets}</strong><span>Open tickets</span></div>
        <div class="stat"><strong>${activeGiveaways}</strong><span>Active giveaways</span></div>
      </div>
      <div class="quick-links">
        <a class="quick-link" href="/g/${guild.id}/settings/general"><b>General settings</b><span>Welcome, autorole and logging.</span></a>
        <a class="quick-link" href="/g/${guild.id}/settings/tickets"><b>Ticket settings</b><span>Category, support role and auto-close.</span></a>
        <a class="quick-link" href="/g/${guild.id}/settings/moderation"><b>Moderation settings</b><span>Warning thresholds and timeout rules.</span></a>
        <a class="quick-link" href="/g/${guild.id}/embed"><b>Embed builder</b><span>Send a styled message to any text channel.</span></a>
      </div>`;

    res.send(layout({ title: guild.name, body, user: req.session.user, guild, active: `/g/${guild.id}` }));
  });

  app.get('/g/:gid/config', (req, res) => res.redirect(`/g/${req.guild.id}/settings/general`));

  app.get('/g/:gid/settings/general', (req, res) => {
    const guild = req.guild;
    const config = guildConfig(guild.id);
    const textChannels = [...guild.channels.cache.values()].filter(channel => channel.isTextBased() && channel.type !== 4);
    const roles = [...guild.roles.cache.values()].filter(role => role.id !== guild.id).sort((a, b) => b.position - a.position);

    const body = `${pageHead('General & welcome', 'Configure welcome messages, autoroles and logging.')}
      <form class="form-card" method="post" action="/g/${guild.id}/settings/general">
        <div class="section-title"><div><h2>Welcome system</h2><p>Choose where and how new members are greeted.</p></div></div>
        <div class="fields">
          <div class="field"><label>Welcome channel</label><select name="welcomeChannelId">${optionList(textChannels, config.welcomeChannelId, channel => `#${channel.name}`)}</select></div>
          <div class="field"><label>Automatic role</label><select name="autoroleId">${optionList(roles, config.autoroleId, role => role.name)}</select><span class="hint">The bot role must be above the selected role.</span></div>
          <div class="field full"><label>Welcome message</label><textarea name="welcomeMessage">${escapeHtml(config.welcomeMessage || '')}</textarea><span class="hint">Available placeholders: {member}, {server}, {count}</span></div>
        </div>
        <div class="section-title"><div><h2>Logging</h2><p>Set the channel used for bot and server logs.</p></div></div>
        <div class="fields"><div class="field"><label>Log channel</label><select name="logChannelId">${optionList(textChannels, config.logChannelId, channel => `#${channel.name}`)}</select></div></div>
        <div class="actions"><a class="button secondary" href="/g/${guild.id}">Cancel</a><button type="submit">Save general settings</button></div>
      </form>`;

    res.send(layout({ title: 'General settings', body, user: req.session.user, guild, active: `/g/${guild.id}/settings/general`, notice: req.query.saved === '1' ? 'General settings saved successfully.' : '' }));
  });

  app.post('/g/:gid/settings/general', (req, res) => {
    const current = guildConfig(req.guild.id);
    setGuildConfig(req.guild.id, {
      welcomeChannelId: parseNullableString(req.body.welcomeChannelId),
      welcomeMessage: parseNullableString(req.body.welcomeMessage) || current.welcomeMessage,
      autoroleId: parseNullableString(req.body.autoroleId),
      logChannelId: parseNullableString(req.body.logChannelId),
    });
    res.redirect(`/g/${req.guild.id}/settings/general?saved=1`);
  });

  app.get('/g/:gid/settings/tickets', (req, res) => {
    const guild = req.guild;
    const config = guildConfig(guild.id);
    const textChannels = [...guild.channels.cache.values()].filter(channel => channel.isTextBased() && channel.type !== 4);
    const categories = [...guild.channels.cache.values()].filter(channel => channel.type === 4);
    const roles = [...guild.roles.cache.values()].filter(role => role.id !== guild.id).sort((a, b) => b.position - a.position);

    const body = `${pageHead('Ticket settings', 'Configure where tickets are created, who can access them and when inactive tickets close.')}
      <form class="form-card" method="post" action="/g/${guild.id}/settings/tickets">
        <div class="section-title"><div><h2>Ticket routing</h2><p>Keep support channels and transcripts organized.</p></div></div>
        <div class="fields">
          <div class="field"><label>Ticket category</label><select name="ticketCategoryId">${optionList(categories, config.ticketCategoryId, category => category.name)}</select></div>
          <div class="field"><label>Support role</label><select name="ticketSupportRoleId">${optionList(roles, config.ticketSupportRoleId, role => role.name)}</select></div>
          <div class="field"><label>Ticket log channel</label><select name="ticketLogChannelId">${optionList(textChannels, config.ticketLogChannelId, channel => `#${channel.name}`)}</select></div>
          <div class="field"><label>Auto-close after inactivity</label><input type="number" min="0" max="720" name="ticketAutoCloseHours" value="${escapeHtml(config.ticketAutoCloseHours ?? 72)}"><span class="hint">Hours. Use 0 to disable automatic closing.</span></div>
        </div>
        <div class="actions"><a class="button secondary" href="/g/${guild.id}">Cancel</a><button type="submit">Save ticket settings</button></div>
      </form>`;

    res.send(layout({ title: 'Ticket settings', body, user: req.session.user, guild, active: `/g/${guild.id}/settings/tickets`, notice: req.query.saved === '1' ? 'Ticket settings saved successfully.' : '' }));
  });

  app.post('/g/:gid/settings/tickets', (req, res) => {
    const current = guildConfig(req.guild.id);
    setGuildConfig(req.guild.id, {
      ticketCategoryId: parseNullableString(req.body.ticketCategoryId),
      ticketSupportRoleId: parseNullableString(req.body.ticketSupportRoleId),
      ticketLogChannelId: parseNullableString(req.body.ticketLogChannelId),
      ticketAutoCloseHours: parseInteger(req.body.ticketAutoCloseHours, current.ticketAutoCloseHours ?? 72, 0, 720),
    });
    res.redirect(`/g/${req.guild.id}/settings/tickets?saved=1`);
  });

  app.get('/g/:gid/settings/moderation', (req, res) => {
    const guild = req.guild;
    const config = guildConfig(guild.id);
    const body = `${pageHead('Moderation settings', 'Configure automatic actions after repeated warnings.')}
      <form class="form-card" method="post" action="/g/${guild.id}/settings/moderation">
        <div class="section-title"><div><h2>Warning escalation</h2><p>The bot can automatically timeout users after a warning threshold.</p></div></div>
        <div class="fields">
          <div class="field"><label>Warnings before timeout</label><input type="number" min="0" max="100" name="warnTimeoutThreshold" value="${escapeHtml(config.warnTimeoutThreshold ?? 3)}"><span class="hint">Use 0 to disable automatic escalation.</span></div>
          <div class="field"><label>Timeout duration in minutes</label><input type="number" min="1" max="40320" name="warnTimeoutMinutes" value="${escapeHtml(config.warnTimeoutMinutes ?? 60)}"></div>
        </div>
        <div class="actions"><a class="button secondary" href="/g/${guild.id}">Cancel</a><button type="submit">Save moderation settings</button></div>
      </form>`;
    res.send(layout({ title: 'Moderation settings', body, user: req.session.user, guild, active: `/g/${guild.id}/settings/moderation`, notice: req.query.saved === '1' ? 'Moderation settings saved successfully.' : '' }));
  });

  app.post('/g/:gid/settings/moderation', (req, res) => {
    const current = guildConfig(req.guild.id);
    setGuildConfig(req.guild.id, {
      warnTimeoutThreshold: parseInteger(req.body.warnTimeoutThreshold, current.warnTimeoutThreshold ?? 3, 0, 100),
      warnTimeoutMinutes: parseInteger(req.body.warnTimeoutMinutes, current.warnTimeoutMinutes ?? 60, 1, 40320),
    });
    res.redirect(`/g/${req.guild.id}/settings/moderation?saved=1`);
  });

  app.get('/g/:gid/settings/server', (req, res) => {
    const guild = req.guild;
    const config = guildConfig(guild.id);
    const textChannels = [...guild.channels.cache.values()]
      .filter(channel => channel.isTextBased() && channel.type !== 4);

    const body = `${pageHead('Server features', 'Configure general server features.')}
      <form class="form-card" method="post" action="/g/${guild.id}/settings/server">
        <div class="section-title">
          <div>
            <h2>Suggestions</h2>
            <p>Choose the destination for member suggestions.</p>
          </div>
        </div>
        <div class="fields">
          <div class="field">
            <label>Suggestion channel</label>
            <select name="suggestionChannelId">
              ${optionList(textChannels, config.suggestionChannelId, channel => `#${channel.name}`)}
            </select>
          </div>
        </div>

        <div class="section-title">
          <div>
            <h2>Temporary voice channels</h2>
            <p>This feature is disabled. Music always uses the fixed channel configured in Music Manager.</p>
          </div>
        </div>

        <div class="actions">
          <a class="button secondary" href="/g/${guild.id}">Cancel</a>
          <button type="submit">Save server features</button>
        </div>
      </form>`;

    res.send(layout({
      title: 'Server features',
      body,
      user: req.session.user,
      guild,
      active: `/g/${guild.id}/settings/server`,
      notice: req.query.saved === '1' ? 'Server features saved successfully.' : ''
    }));
  });

  app.post('/g/:gid/settings/server', (req, res) => {
    setGuildConfig(req.guild.id, {
      suggestionChannelId: parseNullableString(req.body.suggestionChannelId),
      tempVoiceLobbyId: null,
      tempVoiceCategoryId: null,
    });

    // Remove old tracked temporary rooms from bot storage.
    store.mutate('tempVoice', rooms => {
      for (const [channelId, room] of Object.entries(rooms)) {
        if (room.guildId === req.guild.id) delete rooms[channelId];
      }
    });

    res.redirect(`/g/${req.guild.id}/settings/server?saved=1`);
  });

  app.get('/g/:gid/warnings', (req, res) => {
    const all = read('warnings')[req.guild.id] || {};
    const rows = Object.entries(all).flatMap(([userId, entries]) => entries.map(item => ({ userId, ...item })));
    const body = `${pageHead('Warnings', 'Persistent warning history for this server.')}${table(rows)}`;
    res.send(layout({ title: 'Warnings', body, user: req.session.user, guild: req.guild, active: `/g/${req.guild.id}/warnings` }));
  });

  app.get('/g/:gid/tickets', (req, res) => {
    const rows = Object.entries(read('tickets')).filter(([, ticket]) => ticket.guildId === req.guild.id).map(([channelId, ticket]) => ({ channelId, ...ticket }));
    const body = `${pageHead('Ticket records', 'Review current and historical ticket metadata.')}${table(rows)}`;
    res.send(layout({ title: 'Tickets', body, user: req.session.user, guild: req.guild, active: `/g/${req.guild.id}/tickets` }));
  });

  app.get('/g/:gid/giveaways', (req, res) => {
    const guild = req.guild;
    const giveaways = Object.values(store.read('giveaways'))
      .filter(giveaway => giveaway.guildId === guild.id)
      .sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));

    const textChannels = [...guild.channels.cache.values()]
      .filter(channel => channel.isTextBased() && channel.type !== ChannelType.GuildCategory);
    const roles = [...guild.roles.cache.values()]
      .filter(role => role.id !== guild.id)
      .sort((a, b) => b.position - a.position);

    const cards = giveaways.map(giveaway => {
      const status = giveaway.ended ? 'Ended' : giveaway.paused ? 'Paused' : 'Active';
      const entryCount = new Set(giveaway.entries || []).size;

      return `<div class="form-card">
        <div class="section-title">
          <div>
            <h2>${escapeHtml(giveaway.prize)}</h2>
            <p>ID: ${escapeHtml(giveaway.id)} · ${status} · ${entryCount} entries</p>
          </div>
          <span class="badge">${status}</span>
        </div>
        <div class="grid">
          <div class="stat"><strong>${giveaway.winners}</strong><span>Winners</span></div>
          <div class="stat"><strong>${entryCount}</strong><span>Unique entries</span></div>
          <div class="stat"><strong>${giveaway.ended ? '—' : new Date(giveaway.endsAt).toLocaleString()}</strong><span>End time</span></div>
        </div>
        <div class="actions">
          ${!giveaway.ended && !giveaway.paused ? `<form method="post" action="/g/${guild.id}/giveaways/${giveaway.id}/pause"><button class="secondary">Pause</button></form>` : ''}
          ${!giveaway.ended && giveaway.paused ? `<form method="post" action="/g/${guild.id}/giveaways/${giveaway.id}/resume"><button>Resume</button></form>` : ''}
          ${!giveaway.ended ? `<form method="post" action="/g/${guild.id}/giveaways/${giveaway.id}/end"><button style="background:#f0a202">End now</button></form>` : ''}
          ${giveaway.ended ? `<form method="post" action="/g/${guild.id}/giveaways/${giveaway.id}/reroll"><button>Reroll</button></form>` : ''}
          <form method="post" action="/g/${guild.id}/giveaways/${giveaway.id}/delete" onsubmit="return confirm('Delete this giveaway record and message?')"><button style="background:#ed4245">Delete</button></form>
        </div>
      </div>`;
    }).join('');

    const body = `${pageHead('Giveaway Manager', 'Create and manage giveaways without leaving the dashboard.')}
      <form class="form-card" method="post" action="/g/${guild.id}/giveaways/create">
        <div class="section-title"><div><h2>Create giveaway</h2><p>The bot posts an interactive giveaway message in the selected channel.</p></div></div>
        <div class="fields">
          <div class="field full"><label>Prize</label><input name="prize" maxlength="250" required placeholder="One month of VIP"></div>
          <div class="field"><label>Duration</label><input name="duration" required placeholder="30m, 2h, 3d"></div>
          <div class="field"><label>Number of winners</label><input type="number" name="winners" min="1" max="20" value="1" required></div>
          <div class="field"><label>Channel</label><select name="channelId" required>${optionList(textChannels, '', channel => `#${channel.name}`, false)}</select></div>
          <div class="field"><label>Required role</label><select name="requiredRoleId">${optionList(roles, '', role => role.name)}</select></div>
          <div class="field"><label>Bonus-entry role</label><select name="bonusRoleId">${optionList(roles, '', role => role.name)}</select></div>
          <div class="field"><label>Minimum account age (days)</label><input type="number" name="minAccountDays" min="0" max="3650" value="0"></div>
          <div class="field"><label>Minimum membership (days)</label><input type="number" name="minMemberDays" min="0" max="3650" value="0"></div>
        </div>
        <div class="actions"><button type="submit">Create giveaway</button></div>
      </form>
      ${cards || '<div class="card empty">No giveaways have been created yet.</div>'}`;

    res.send(layout({
      title: 'Giveaways',
      body,
      user: req.session.user,
      guild,
      active: `/g/${guild.id}/giveaways`,
      notice: req.query.ok || '',
      error: req.query.error || '',
    }));
  });

  app.post('/g/:gid/giveaways/create', async (req, res) => {
    try {
      const duration = parseDuration(req.body.duration);
      if (!Number.isFinite(duration) || duration < 10000) throw new Error('Duration must be at least 10 seconds.');

      const channel = await req.guild.channels.fetch(req.body.channelId);
      if (!channel?.isTextBased()) throw new Error('Select a valid text channel.');

      const giveaway = {
        id: giveawayId(),
        guildId: req.guild.id,
        channelId: channel.id,
        messageId: null,
        prize: String(req.body.prize || '').trim(),
        winners: parseInteger(req.body.winners, 1, 1, 20),
        endsAt: Date.now() + duration,
        remainingMs: null,
        paused: false,
        ended: false,
        entries: [],
        bonusEntries: [],
        requiredRoleId: parseNullableString(req.body.requiredRoleId),
        bonusRoleId: parseNullableString(req.body.bonusRoleId),
        minAccountDays: parseInteger(req.body.minAccountDays, 0, 0, 3650),
        minMemberDays: parseInteger(req.body.minMemberDays, 0, 0, 3650),
        createdAt: Date.now(),
        createdBy: req.session.user.id,
      };

      if (!giveaway.prize) throw new Error('Prize is required.');

      const message = await channel.send({
        embeds: [embed('🎉 Giveaway', giveawayDescription(giveaway), BRAND.success)],
        components: giveawayComponents(giveaway.id),
      });

      giveaway.messageId = message.id;
      store.mutate('giveaways', all => {
        all[giveaway.id] = giveaway;
      });
      store.audit(req.guild.id, 'giveaway-create', req.session.user.id, giveaway.id, giveaway.prize);

      res.redirect(`/g/${req.guild.id}/giveaways?ok=${encodeURIComponent('Giveaway created successfully.')}`);
    } catch (error) {
      res.redirect(`/g/${req.guild.id}/giveaways?error=${encodeURIComponent(error.message)}`);
    }
  });

  app.post('/g/:gid/giveaways/:id/pause', async (req, res) => {
    try {
      const all = store.read('giveaways');
      const giveaway = all[req.params.id];
      if (!giveaway || giveaway.guildId !== req.guild.id || giveaway.ended) throw new Error('Active giveaway not found.');

      giveaway.remainingMs = Math.max(1000, giveaway.endsAt - Date.now());
      giveaway.paused = true;
      all[giveaway.id] = giveaway;
      store.write('giveaways', all);

      const channel = await req.guild.channels.fetch(giveaway.channelId).catch(() => null);
      const message = channel?.isTextBased() ? await channel.messages.fetch(giveaway.messageId).catch(() => null) : null;
      if (message) await message.edit({
        embeds: [embed('⏸️ Giveaway paused', giveawayDescription(giveaway), BRAND.warning)],
        components: giveawayComponents(giveaway.id, true),
      });

      store.audit(req.guild.id, 'giveaway-pause', req.session.user.id, giveaway.id, giveaway.prize);
      res.redirect(`/g/${req.guild.id}/giveaways?ok=${encodeURIComponent('Giveaway paused.')}`);
    } catch (error) {
      res.redirect(`/g/${req.guild.id}/giveaways?error=${encodeURIComponent(error.message)}`);
    }
  });

  app.post('/g/:gid/giveaways/:id/resume', async (req, res) => {
    try {
      const all = store.read('giveaways');
      const giveaway = all[req.params.id];
      if (!giveaway || giveaway.guildId !== req.guild.id || giveaway.ended) throw new Error('Paused giveaway not found.');

      giveaway.endsAt = Date.now() + Math.max(1000, Number(giveaway.remainingMs || 60000));
      giveaway.remainingMs = null;
      giveaway.paused = false;
      all[giveaway.id] = giveaway;
      store.write('giveaways', all);

      const channel = await req.guild.channels.fetch(giveaway.channelId).catch(() => null);
      const message = channel?.isTextBased() ? await channel.messages.fetch(giveaway.messageId).catch(() => null) : null;
      if (message) await message.edit({
        embeds: [embed('🎉 Giveaway', giveawayDescription(giveaway), BRAND.success)],
        components: giveawayComponents(giveaway.id),
      });

      store.audit(req.guild.id, 'giveaway-resume', req.session.user.id, giveaway.id, giveaway.prize);
      res.redirect(`/g/${req.guild.id}/giveaways?ok=${encodeURIComponent('Giveaway resumed.')}`);
    } catch (error) {
      res.redirect(`/g/${req.guild.id}/giveaways?error=${encodeURIComponent(error.message)}`);
    }
  });

  app.post('/g/:gid/giveaways/:id/end', async (req, res) => {
    try {
      await dashboardFinishGiveaway(client, req.guild, req.params.id, false);
      store.audit(req.guild.id, 'giveaway-end', req.session.user.id, req.params.id, 'Ended from dashboard');
      res.redirect(`/g/${req.guild.id}/giveaways?ok=${encodeURIComponent('Giveaway ended and winners selected.')}`);
    } catch (error) {
      res.redirect(`/g/${req.guild.id}/giveaways?error=${encodeURIComponent(error.message)}`);
    }
  });

  app.post('/g/:gid/giveaways/:id/reroll', async (req, res) => {
    try {
      await dashboardFinishGiveaway(client, req.guild, req.params.id, true);
      store.audit(req.guild.id, 'giveaway-reroll', req.session.user.id, req.params.id, 'Rerolled from dashboard');
      res.redirect(`/g/${req.guild.id}/giveaways?ok=${encodeURIComponent('Giveaway rerolled.')}`);
    } catch (error) {
      res.redirect(`/g/${req.guild.id}/giveaways?error=${encodeURIComponent(error.message)}`);
    }
  });

  app.post('/g/:gid/giveaways/:id/delete', async (req, res) => {
    try {
      const all = store.read('giveaways');
      const giveaway = all[req.params.id];
      if (!giveaway || giveaway.guildId !== req.guild.id) throw new Error('Giveaway not found.');

      const channel = await req.guild.channels.fetch(giveaway.channelId).catch(() => null);
      const message = channel?.isTextBased() ? await channel.messages.fetch(giveaway.messageId).catch(() => null) : null;
      if (message) await message.delete().catch(() => {});

      delete all[giveaway.id];
      store.write('giveaways', all);
      store.audit(req.guild.id, 'giveaway-delete', req.session.user.id, giveaway.id, giveaway.prize);

      res.redirect(`/g/${req.guild.id}/giveaways?ok=${encodeURIComponent('Giveaway deleted.')}`);
    } catch (error) {
      res.redirect(`/g/${req.guild.id}/giveaways?error=${encodeURIComponent(error.message)}`);
    }
  });

  app.get('/g/:gid/events', async (req, res) => {
    try {
      const events = await req.guild.scheduledEvents.fetch();
      const voiceChannels = [...req.guild.channels.cache.values()]
        .filter(channel => channel.type === ChannelType.GuildVoice || channel.type === ChannelType.GuildStageVoice);

      const cards = [...events.values()]
        .sort((a, b) => a.scheduledStartTimestamp - b.scheduledStartTimestamp)
        .map(event => `<div class="form-card">
          <div class="section-title">
            <div>
              <h2>${escapeHtml(event.name)}</h2>
              <p>${escapeHtml(event.description || 'No description')} · ID: ${event.id}</p>
            </div>
            <span class="badge">${escapeHtml(eventStatusLabel(event.status))}</span>
          </div>
          <div class="grid">
            <div class="stat"><strong>${new Date(event.scheduledStartTimestamp).toLocaleString()}</strong><span>Start</span></div>
            <div class="stat"><strong>${event.scheduledEndTimestamp ? new Date(event.scheduledEndTimestamp).toLocaleString() : '—'}</strong><span>End</span></div>
            <div class="stat"><strong>${event.channel?.name ? escapeHtml(event.channel.name) : escapeHtml(event.entityMetadata?.location || 'External')}</strong><span>Location</span></div>
            <div class="stat"><strong>${event.userCount || 0}</strong><span>Interested</span></div>
          </div>
          <form class="form-card" method="post" action="/g/${req.guild.id}/events/${event.id}/edit" style="margin-top:16px">
            <div class="fields">
              <div class="field"><label>Name</label><input name="name" maxlength="100" value="${escapeHtml(event.name)}"></div>
              <div class="field"><label>Description</label><input name="description" maxlength="1000" value="${escapeHtml(event.description || '')}"></div>
              <div class="field"><label>Start</label><input type="datetime-local" name="startTime" value="${new Date(event.scheduledStartTimestamp - new Date().getTimezoneOffset() * 60000).toISOString().slice(0,16)}"></div>
              <div class="field"><label>End</label><input type="datetime-local" name="endTime" value="${event.scheduledEndTimestamp ? new Date(event.scheduledEndTimestamp - new Date().getTimezoneOffset() * 60000).toISOString().slice(0,16) : ''}"></div>
              <div class="field"><label>Voice channel</label><select name="channelId">${optionList(voiceChannels, event.channelId, channel => channel.name)}</select></div>
              <div class="field"><label>External location</label><input name="location" maxlength="100" value="${escapeHtml(event.entityMetadata?.location || '')}"></div>
            </div>
            <div class="actions">
              <button type="submit">Save changes</button>
            </div>
          </form>
          <div class="actions">
            ${Number(event.status) === 1 ? `<form method="post" action="/g/${req.guild.id}/events/${event.id}/start"><button>Start now</button></form>` : ''}
            ${Number(event.status) === 1 || Number(event.status) === 2 ? `<form method="post" action="/g/${req.guild.id}/events/${event.id}/cancel"><button style="background:#f0a202">Cancel</button></form>` : ''}
            <form method="post" action="/g/${req.guild.id}/events/${event.id}/delete" onsubmit="return confirm('Delete this event?')"><button style="background:#ed4245">Delete</button></form>
            <a class="button secondary" href="${event.url}" target="_blank" rel="noopener">Open in Discord</a>
          </div>
        </div>`).join('');

      const body = `${pageHead('Event Manager', 'Create, edit, start, cancel and delete Discord scheduled events.')}
        <form class="form-card" method="post" action="/g/${req.guild.id}/events/create">
          <div class="section-title"><div><h2>Create event</h2><p>Create a Discord Scheduled Event directly from the dashboard.</p></div></div>
          <div class="fields">
            <div class="field"><label>Name</label><input name="name" maxlength="100" required placeholder="Community Game Night"></div>
            <div class="field"><label>Type</label><select name="type" required><option value="voice">Voice channel</option><option value="external">External location</option></select></div>
            <div class="field full"><label>Description</label><textarea name="description" maxlength="1000" required></textarea></div>
            <div class="field"><label>Start</label><input type="datetime-local" name="startTime" required></div>
            <div class="field"><label>End (required for external)</label><input type="datetime-local" name="endTime"></div>
            <div class="field"><label>Voice or stage channel</label><select name="channelId">${optionList(voiceChannels, '', channel => channel.name)}</select></div>
            <div class="field"><label>External location or URL</label><input name="location" maxlength="100" placeholder="https://example.com or Main Hall"></div>
          </div>
          <div class="actions"><button type="submit">Create event</button></div>
        </form>
        ${cards || '<div class="card empty">No scheduled events found.</div>'}`;

      res.send(layout({
        title: 'Events',
        body,
        user: req.session.user,
        guild: req.guild,
        active: `/g/${req.guild.id}/events`,
        notice: req.query.ok || '',
        error: req.query.error || '',
      }));
    } catch (error) {
      res.status(500).send(layout({
        title: 'Events',
        body: '',
        user: req.session.user,
        guild: req.guild,
        active: `/g/${req.guild.id}/events`,
        error: error.message,
      }));
    }
  });

  app.post('/g/:gid/events/create', async (req, res) => {
    try {
      const startTime = parseDashboardDate(req.body.startTime, 'Start time');
      if (startTime.getTime() <= Date.now() + 30000) throw new Error('Start time must be in the future.');

      const options = {
        name: String(req.body.name || '').trim(),
        description: String(req.body.description || '').trim(),
        scheduledStartTime: startTime,
        privacyLevel: GuildScheduledEventPrivacyLevel.GuildOnly,
        reason: `Created from dashboard by ${req.session.user.username}`,
      };

      if (!options.name || !options.description) throw new Error('Name and description are required.');

      if (req.body.type === 'external') {
        const endTime = parseDashboardDate(req.body.endTime, 'End time');
        if (endTime <= startTime) throw new Error('End time must be after start time.');
        const location = String(req.body.location || '').trim();
        if (!location) throw new Error('External events require a location or URL.');

        options.entityType = GuildScheduledEventEntityType.External;
        options.entityMetadata = { location };
        options.scheduledEndTime = endTime;
      } else {
        const channel = await req.guild.channels.fetch(req.body.channelId).catch(() => null);
        if (!channel || ![ChannelType.GuildVoice, ChannelType.GuildStageVoice].includes(channel.type)) {
          throw new Error('Select a valid voice or stage channel.');
        }

        options.entityType = channel.type === ChannelType.GuildStageVoice
          ? GuildScheduledEventEntityType.StageInstance
          : GuildScheduledEventEntityType.Voice;
        options.channel = channel.id;
      }

      const event = await req.guild.scheduledEvents.create(options);
      store.audit(req.guild.id, 'event-create', req.session.user.id, event.id, event.name);
      res.redirect(`/g/${req.guild.id}/events?ok=${encodeURIComponent('Event created successfully.')}`);
    } catch (error) {
      res.redirect(`/g/${req.guild.id}/events?error=${encodeURIComponent(error.message)}`);
    }
  });

  app.post('/g/:gid/events/:id/edit', async (req, res) => {
    try {
      const event = await req.guild.scheduledEvents.fetch(req.params.id).catch(() => null);
      if (!event) throw new Error('Event not found.');

      const patch = {
        name: String(req.body.name || event.name).trim(),
        description: String(req.body.description || event.description || '').trim(),
        scheduledStartTime: parseDashboardDate(req.body.startTime, 'Start time'),
        reason: `Edited from dashboard by ${req.session.user.username}`,
      };

      const location = String(req.body.location || '').trim();
      const channelId = String(req.body.channelId || '').trim();

      if (location) {
        const endTime = parseDashboardDate(req.body.endTime, 'End time');
        if (endTime <= patch.scheduledStartTime) throw new Error('End time must be after start time.');
        patch.entityType = GuildScheduledEventEntityType.External;
        patch.entityMetadata = { location };
        patch.channel = null;
        patch.scheduledEndTime = endTime;
      } else if (channelId) {
        const channel = await req.guild.channels.fetch(channelId).catch(() => null);
        if (!channel || ![ChannelType.GuildVoice, ChannelType.GuildStageVoice].includes(channel.type)) {
          throw new Error('Select a valid voice or stage channel.');
        }
        patch.entityType = channel.type === ChannelType.GuildStageVoice
          ? GuildScheduledEventEntityType.StageInstance
          : GuildScheduledEventEntityType.Voice;
        patch.channel = channel.id;
      }

      const updated = await req.guild.scheduledEvents.edit(event.id, patch);
      store.audit(req.guild.id, 'event-edit', req.session.user.id, event.id, updated.name);
      res.redirect(`/g/${req.guild.id}/events?ok=${encodeURIComponent('Event updated.')}`);
    } catch (error) {
      res.redirect(`/g/${req.guild.id}/events?error=${encodeURIComponent(error.message)}`);
    }
  });

  app.post('/g/:gid/events/:id/start', async (req, res) => {
    try {
      const event = await req.guild.scheduledEvents.fetch(req.params.id);
      await req.guild.scheduledEvents.edit(event.id, {
        status: GuildScheduledEventStatus.Active,
        reason: `Started from dashboard by ${req.session.user.username}`,
      });
      store.audit(req.guild.id, 'event-start', req.session.user.id, event.id, event.name);
      res.redirect(`/g/${req.guild.id}/events?ok=${encodeURIComponent('Event started.')}`);
    } catch (error) {
      res.redirect(`/g/${req.guild.id}/events?error=${encodeURIComponent(error.message)}`);
    }
  });

  app.post('/g/:gid/events/:id/cancel', async (req, res) => {
    try {
      const event = await req.guild.scheduledEvents.fetch(req.params.id);
      await req.guild.scheduledEvents.edit(event.id, {
        status: GuildScheduledEventStatus.Canceled,
        reason: `Canceled from dashboard by ${req.session.user.username}`,
      });
      store.audit(req.guild.id, 'event-cancel', req.session.user.id, event.id, event.name);
      res.redirect(`/g/${req.guild.id}/events?ok=${encodeURIComponent('Event canceled.')}`);
    } catch (error) {
      res.redirect(`/g/${req.guild.id}/events?error=${encodeURIComponent(error.message)}`);
    }
  });

  app.post('/g/:gid/events/:id/delete', async (req, res) => {
    try {
      const event = await req.guild.scheduledEvents.fetch(req.params.id);
      await req.guild.scheduledEvents.delete(event.id, `Deleted from dashboard by ${req.session.user.username}`);
      store.audit(req.guild.id, 'event-delete', req.session.user.id, event.id, event.name);
      res.redirect(`/g/${req.guild.id}/events?ok=${encodeURIComponent('Event deleted.')}`);
    } catch (error) {
      res.redirect(`/g/${req.guild.id}/events?error=${encodeURIComponent(error.message)}`);
    }
  });

  app.get('/g/:gid/embed', (req, res) => {
    const guild = req.guild;
    const channels = [...guild.channels.cache.values()].filter(channel => channel.isTextBased() && channel.type !== 4);
    const body = `${pageHead('Embed builder', 'Send a branded embed to a Discord channel.')}
      <form class="form-card" method="post" action="/g/${guild.id}/embed">
        <div class="fields">
          <div class="field"><label>Destination channel</label><select name="channelId" required>${optionList(channels, null, channel => `#${channel.name}`, false)}</select></div>
          <div class="field"><label>Color</label><input name="color" value="5865F2" pattern="^#?[0-9A-Fa-f]{6}$"><span class="hint">Six-digit hexadecimal value.</span></div>
          <div class="field full"><label>Title</label><input name="title" maxlength="256" required></div>
          <div class="field full"><label>Description</label><textarea name="description" maxlength="4096" required></textarea></div>
        </div>
        <div class="actions"><button type="submit">Send embed</button></div>
      </form>`;
    res.send(layout({ title: 'Embed builder', body, user: req.session.user, guild, active: `/g/${guild.id}/embed`, notice: req.query.sent === '1' ? 'Embed sent successfully.' : '', error: req.query.error ? decodeURIComponent(req.query.error) : '' }));
  });

  app.post('/g/:gid/embed', async (req, res) => {
    try {
      const channel = req.guild.channels.cache.get(req.body.channelId);
      if (!channel || !channel.isTextBased()) throw new Error('Selected channel is unavailable or not a text channel.');
      const normalized = String(req.body.color || '').replace('#', '');
      const color = /^[0-9a-f]{6}$/i.test(normalized) ? Number.parseInt(normalized, 16) : BRAND.color;
      const title = String(req.body.title || '').trim().slice(0, 256);
      const description = String(req.body.description || '').trim().slice(0, 4096);
      if (!title || !description) throw new Error('Title and description are required.');
      await channel.send({ embeds: [embed(title, description, color)] });
      res.redirect(`/g/${req.guild.id}/embed?sent=1`);
    } catch (error) {
      res.redirect(`/g/${req.guild.id}/embed?error=${encodeURIComponent(error.message)}`);
    }
  });

  app.use((error, req, res, next) => {
    console.error('Dashboard error:', error);
    if (res.headersSent) return next(error);
    res.status(500).send(layout({ title: 'Dashboard error', body: '', user: req.session?.user, guild: req.guild, error: error.message || 'Unknown error' }));
  });

  const port = Number(process.env.DASHBOARD_PORT || 3000);
  const host = process.env.DASHBOARD_HOST || '0.0.0.0';

  function boolField(body,name){return body[name]==='on'}
  app.get('/g/:gid/settings/automod',(req,res)=>{const g=req.guild,c=guildConfig(g.id);const toggles=['automodEnabled','antiLinks','antiInvites','antiSpam','antiCaps','antiMentions','antiZalgo','antiRaid','antiNuke'];const body=`${pageHead('AutoMod','Configure filters, raid protection and automatic timeout.')}<form method="post" class="form-card"><div class="fields">${toggles.map(k=>`<div class="checkbox-row"><input type="checkbox" name="${k}"${checked(c[k])}><label>${escapeHtml(k)}</label></div>`).join('')}<div class="field"><label>Max caps %</label><input name="maxCapsPercent" type="number" value="${c.maxCapsPercent}"></div><div class="field"><label>Max mentions</label><input name="maxMentions" type="number" value="${c.maxMentions}"></div><div class="field"><label>Spam messages</label><input name="spamMessages" type="number" value="${c.spamMessages}"></div><div class="field"><label>Spam window seconds</label><input name="spamWindowSeconds" type="number" value="${c.spamWindowSeconds}"></div><div class="field"><label>Raid joins</label><input name="raidJoins" type="number" value="${c.raidJoins}"></div><div class="field"><label>Raid window seconds</label><input name="raidWindowSeconds" type="number" value="${c.raidWindowSeconds}"></div><div class="field"><label>Timeout minutes</label><input name="timeoutMinutes" type="number" value="${c.timeoutMinutes}"></div></div><div class="actions"><button>Save AutoMod</button></div></form>`;res.send(layout({title:'AutoMod',body,user:req.session.user,guild:g,active:req.path,notice:req.query.saved?'AutoMod settings saved.':''}))});
  app.post('/g/:gid/settings/automod',(req,res)=>{const keys=['automodEnabled','antiLinks','antiInvites','antiSpam','antiCaps','antiMentions','antiZalgo','antiRaid','antiNuke'];const p={};for(const k of keys)p[k]=boolField(req.body,k);for(const k of ['maxCapsPercent','maxMentions','spamMessages','spamWindowSeconds','raidJoins','raidWindowSeconds','timeoutMinutes'])p[k]=parseInteger(req.body[k],guildConfig(req.guild.id)[k],1,1000);setGuildConfig(req.guild.id,p);res.redirect(`/g/${req.guild.id}/settings/automod?saved=1`)});
  app.get('/g/:gid/settings/levels',(req,res)=>{const g=req.guild,c=guildConfig(g.id);const body=`${pageHead('Levels','XP, voice XP, daily limits and level announcements.')}<form method="post" class="form-card"><div class="fields"><div class="checkbox-row"><input type="checkbox" name="levelsEnabled"${checked(c.levelsEnabled)}><label>Enable levels</label></div><div class="field"><label>XP min</label><input name="xpMin" type="number" value="${c.xpMin}"></div><div class="field"><label>XP max</label><input name="xpMax" type="number" value="${c.xpMax}"></div><div class="field"><label>Cooldown seconds</label><input name="xpCooldownSeconds" type="number" value="${c.xpCooldownSeconds}"></div><div class="field"><label>Daily XP limit</label><input name="dailyXpLimit" type="number" value="${c.dailyXpLimit}"></div><div class="field"><label>Voice XP/min</label><input name="voiceXpPerMinute" type="number" value="${c.voiceXpPerMinute}"></div></div><div class="actions"><button>Save levels</button></div></form>`;res.send(layout({title:'Levels',body,user:req.session.user,guild:g,active:req.path,notice:req.query.saved?'Level settings saved.':''}))});
  app.post('/g/:gid/settings/levels',(req,res)=>{setGuildConfig(req.guild.id,{levelsEnabled:boolField(req.body,'levelsEnabled'),xpMin:parseInteger(req.body.xpMin,8,1,100),xpMax:parseInteger(req.body.xpMax,15,1,100),xpCooldownSeconds:parseInteger(req.body.xpCooldownSeconds,60,5,3600),dailyXpLimit:parseInteger(req.body.dailyXpLimit,500,1,100000),voiceXpPerMinute:parseInteger(req.body.voiceXpPerMinute,3,0,100)});res.redirect(`/g/${req.guild.id}/settings/levels?saved=1`)});
  app.get('/g/:gid/settings/economy',(req,res)=>{const g=req.guild,c=guildConfig(g.id);const body=`${pageHead('Economy','Configure rewards and risk settings.')}<form method="post" class="form-card"><div class="fields"><div class="checkbox-row"><input type="checkbox" name="economyEnabled"${checked(c.economyEnabled)}><label>Enable economy</label></div><div class="field"><label>Daily amount</label><input name="dailyAmount" type="number" value="${c.dailyAmount}"></div><div class="field"><label>Work minimum</label><input name="workMin" type="number" value="${c.workMin}"></div><div class="field"><label>Work maximum</label><input name="workMax" type="number" value="${c.workMax}"></div><div class="field"><label>Crime minimum</label><input name="crimeMin" type="number" value="${c.crimeMin}"></div><div class="field"><label>Crime maximum</label><input name="crimeMax" type="number" value="${c.crimeMax}"></div><div class="field"><label>Crime fail chance %</label><input name="crimeFailChance" type="number" value="${c.crimeFailChance}"></div></div><div class="actions"><button>Save economy</button></div></form>`;res.send(layout({title:'Economy',body,user:req.session.user,guild:g,active:req.path,notice:req.query.saved?'Economy settings saved.':''}))});
  app.post('/g/:gid/settings/economy',(req,res)=>{setGuildConfig(req.guild.id,{economyEnabled:boolField(req.body,'economyEnabled'),dailyAmount:parseInteger(req.body.dailyAmount,250,0,1000000),workMin:parseInteger(req.body.workMin,50,0,1000000),workMax:parseInteger(req.body.workMax,180,0,1000000),crimeMin:parseInteger(req.body.crimeMin,40,0,1000000),crimeMax:parseInteger(req.body.crimeMax,350,0,1000000),crimeFailChance:parseInteger(req.body.crimeFailChance,35,0,100)});res.redirect(`/g/${req.guild.id}/settings/economy?saved=1`)});
  app.get('/g/:gid/audit',(req,res)=>{const rows=read('audit').filter(x=>x.guildId===req.guild.id).slice(0,500);res.send(layout({title:'Audit logs',body:`${pageHead('Audit logs','Recent bot, moderation and security actions.')}${table(rows)}`,user:req.session.user,guild:req.guild,active:req.path}))});

  app.get('/g/:gid/message-studio', (req, res) => {
    const guild = req.guild;
    const channels = [...guild.channels.cache.values()]
      .filter(channel => channel.isTextBased() && channel.type !== 4)
      .sort((a,b)=>a.rawPosition-b.rawPosition);

    const scheduled = store.read('scheduledMessages')
      .filter(job => job.guildId === guild.id)
      .slice(-30)
      .reverse();

    const body = `${pageHead('Message Studio', 'Build, preview, schedule and publish rich Discord messages.')}
      <div class="preview-shell">
        <form class="form-card" method="post" action="/g/${guild.id}/message-studio" id="studio-form">
          <div class="section-title"><div><h2>Message</h2><p>Everything is optional except a target channel and at least text or an embed.</p></div></div>
          <div class="fields">
            <div class="field"><label>Target channel</label><select name="channelId" required>${optionList(channels, '', c=>`#${c.name}`, false)}</select></div>
            <div class="field"><label>Send time</label><input type="datetime-local" name="sendAt"><span class="hint">Leave empty to send immediately.</span></div>
            <div class="field full"><label>Message text</label><textarea name="content" id="studio-content" placeholder="Hallo&#10;&#10;Dit is een test"></textarea></div>
          </div>

          <div class="section-title"><div><h2>Embed</h2><p>Add a styled card below the normal message.</p></div></div>
          <div class="fields">
            <div class="field"><label>Embed title</label><input name="embedTitle" id="studio-title"></div>
            <div class="field"><label>Color</label><input name="color" id="studio-color" value="5865F2" maxlength="7"></div>
            <div class="field full"><label>Embed description</label><textarea name="embedDescription" id="studio-description"></textarea></div>
            <div class="field"><label>Large image URL</label><input name="imageUrl"></div>
            <div class="field"><label>Thumbnail URL</label><input name="thumbnailUrl"></div>
          </div>

          <div class="section-title"><div><h2>Components</h2><p>Link buttons and dropdown options remain functional after restarts.</p></div></div>
          <div class="fields">
            <div class="field full"><label>Link buttons</label><textarea name="buttons" id="studio-buttons" placeholder="Website|https://example.com&#10;Vote|https://example.com/vote"></textarea><span class="hint">One per line: Label|URL. Maximum 5.</span></div>
            <div class="field"><label>Dropdown placeholder</label><input name="selectPlaceholder" value="Choose an option"></div>
            <div class="field full"><label>Dropdown options</label><textarea name="selectOptions" placeholder="Rules|Read the rules in #rules.&#10;Support|Open a ticket in #support."></textarea><span class="hint">One per line: Label|Ephemeral response.</span></div>
            <div class="field full"><div class="checkbox-row"><input type="checkbox" name="sticky" value="1"><label>Make this a sticky message in the target channel.</label></div></div>
          </div>
          <div class="actions"><button type="submit">Send or schedule message</button></div>
        </form>

        <div class="form-card">
          <div class="section-title"><div><h2>Live preview</h2><p>Approximation of how the Discord message will look.</p></div></div>
          <div class="discord-preview">
            <div class="discord-message">
              <div class="avatar">H</div>
              <div class="message-body">
                <div class="message-author">Helixcraft Bot <span class="badge">BOT</span></div>
                <div class="message-text" id="preview-content">Your message preview appears here.</div>
                <div class="embed-preview" id="preview-embed">
                  <h3 id="preview-title">Embed title</h3>
                  <p id="preview-description">Embed description</p>
                </div>
                <div class="component-preview" id="preview-buttons"></div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div class="form-card">
        <div class="section-title"><div><h2>Scheduled history</h2><p>Recent scheduled, sent and failed messages.</p></div></div>
        ${table(scheduled, ['id','channelId','sendAt','status','messageId','error'])}
      </div>

      <script>
        const $=id=>document.getElementById(id);
        function updatePreview(){
          $('preview-content').textContent=$('studio-content').value||'Your message preview appears here.';
          $('preview-title').textContent=$('studio-title').value||'Embed title';
          $('preview-description').textContent=$('studio-description').value||'Embed description';
          const color=$('studio-color').value.replace('#','');
          $('preview-embed').style.borderLeftColor=/^[0-9a-f]{6}$/i.test(color)?'#'+color:'#5865f2';
          const host=$('preview-buttons');host.innerHTML='';
          $('studio-buttons').value.split(/\\n/).filter(Boolean).slice(0,5).forEach(line=>{
            const button=document.createElement('span');button.className='fake-button';button.textContent=line.split('|')[0];host.appendChild(button);
          });
        }
        ['studio-content','studio-title','studio-description','studio-color','studio-buttons'].forEach(id=>$(id).addEventListener('input',updatePreview));
        updatePreview();
      </script>`;

    res.send(layout({
      title: 'Message Studio',
      body,
      user: req.session.user,
      guild,
      active: `/g/${guild.id}/message-studio`,
      notice: req.query.sent === '1' ? 'Message sent successfully.' : req.query.scheduled === '1' ? 'Message scheduled successfully.' : '',
      error: req.query.error || '',
    }));
  });

  app.post('/g/:gid/message-studio', async (req, res) => {
    const data = {
      id: `${Date.now()}-${Math.random().toString(36).slice(2,8)}`,
      guildId: req.guild.id,
      channelId: req.body.channelId,
      content: req.body.content || '',
      embedTitle: req.body.embedTitle || '',
      embedDescription: req.body.embedDescription || '',
      color: req.body.color || '5865F2',
      imageUrl: req.body.imageUrl || '',
      thumbnailUrl: req.body.thumbnailUrl || '',
      buttons: req.body.buttons || '',
      selectPlaceholder: req.body.selectPlaceholder || '',
      selectOptions: req.body.selectOptions || '',
      sticky: req.body.sticky === '1',
      createdAt: Date.now(),
      createdBy: req.session.user?.id,
    };

    try {
      if (req.body.sendAt) {
        const sendAt = new Date(req.body.sendAt).getTime();
        if (!Number.isFinite(sendAt) || sendAt <= Date.now()) throw new Error('Scheduled time must be in the future.');
        data.sendAt = sendAt;
        data.status = 'pending';
        store.mutate('scheduledMessages', jobs => jobs.push(data));
        return res.redirect(`/g/${req.guild.id}/message-studio?scheduled=1`);
      }

      await messageStudio.sendStudioMessage(client, data);
      res.redirect(`/g/${req.guild.id}/message-studio?sent=1`);
    } catch (error) {
      res.redirect(`/g/${req.guild.id}/message-studio?error=${encodeURIComponent(error.message)}`);
    }
  });

  app.get('/g/:gid/music', async (req, res) => {
    const guild = req.guild;
    const voiceChannels = [...guild.channels.cache.values()].filter(channel => channel.type === 2);
    const textChannels = [...guild.channels.cache.values()].filter(channel => channel.isTextBased() && channel.type !== 4);
    const state = music.snapshot(guild.id);
    const deps = await music.dependencyStatus();
    const voiceHealth = music.voiceHealth(guild.id);
    const spotifyStatus = spotifyOAuth.status(guild.id);
    const allMusicSettings = store.read('musicSettings');
    const musicSettings = allMusicSettings[guild.id] || {
      voiceChannelId: null,
      textChannelId: null,
    };

    const queue = state.queue.length
      ? `<ol class="queue-list">${state.queue.map(track=>`<li>${escapeHtml(track.title)} <span class="hint">${escapeHtml(track.duration)}</span></li>`).join('')}</ol>`
      : '<div class="empty">Queue is empty.</div>';

    const body = `${pageHead('Music Manager', 'Control the guild music player from the dashboard.')}
      ${!deps.ytdlp || !deps.ffmpeg ? `<div class="error">Missing CT dependencies: ${!deps.ytdlp?'yt-dlp ':''}${!deps.ffmpeg?'ffmpeg':''}</div>`:''}
      <div class="grid">
        <div class="stat"><strong>${escapeHtml(state.status)}</strong><span>Player status</span></div>
        <div class="stat"><strong>${escapeHtml(voiceHealth.connection.status)}</strong><span>Voice connection</span></div>
        <div class="stat"><strong>${state.volume}%</strong><span>Volume</span></div>
        <div class="stat"><strong>${state.queue.length}</strong><span>Queued tracks</span></div>
      </div>

      <div class="form-card" style="margin-top:18px">
        <div class="section-title">
          <div>
            <h2>Spotify account</h2>
            <p>Required for private, collaborative and very large playlists.</p>
          </div>
        </div>
        <div class="grid">
          <div class="stat">
            <strong>${spotifyStatus.connected ? 'Connected' : 'Not connected'}</strong>
            <span>Spotify status</span>
          </div>
          <div class="stat">
            <strong>${spotifyStatus.connectedAt ? new Date(spotifyStatus.connectedAt).toLocaleString() : '—'}</strong>
            <span>Connected at</span>
          </div>
        </div>
        <div class="actions">
          <a class="button" href="/g/${guild.id}/spotify/connect">${spotifyStatus.connected ? 'Reconnect Spotify' : 'Connect Spotify'}</a>
          ${spotifyStatus.connected ? `<form method="post" action="/g/${guild.id}/spotify/disconnect" style="display:inline"><button style="background:#ed4245">Disconnect</button></form>` : ''}
        </div>
      </div>

      <form class="form-card" method="post" action="/g/${guild.id}/music/settings" style="margin-top:18px">
        <div class="section-title">
          <div>
            <h2>Fixed music channels</h2>
            <p>The bot always joins this voice channel. It will never create a temporary voice channel.</p>
          </div>
        </div>
        <div class="fields">
          <div class="field">
            <label>Music voice channel</label>
            <select name="voiceChannelId" required>
              ${optionList(voiceChannels,musicSettings.voiceChannelId,c=>c.name,false)}
            </select>
          </div>
          <div class="field">
            <label>Status text channel</label>
            <select name="textChannelId">
              ${optionList(textChannels,musicSettings.textChannelId,c=>`#${c.name}`)}
            </select>
          </div>
          <div class="field full">
            <div class="checkbox-row">
              <input type="checkbox" name="shuffle" value="1" ${musicSettings.shuffle ? 'checked' : ''}>
              <label>Shuffle every newly loaded playlist automatically.</label>
            </div>
          </div>
        </div>
        <div class="actions"><button type="submit">Save fixed channels</button></div>
      </form>

      <div class="two-col" style="margin-top:18px">
        <form class="form-card" method="post" action="/g/${guild.id}/music/play">
          <div class="section-title"><div><h2>Play / queue</h2><p>Use a direct URL or a search query supported by yt-dlp.</p></div></div>
          <div class="fields">
            <div class="field full"><label>Query or URL</label><input name="query" required placeholder="Spotify playlist, track URL or search query"></div>
            <div class="field full">
              <span class="hint">
                Fixed voice channel:
                ${musicSettings.voiceChannelId ? `<#${musicSettings.voiceChannelId}>` : 'not configured'}
              </span>
            </div>
          </div>
          <div class="actions"><button>Play / add to queue</button></div>
        </form>

        <div class="form-card">
          <div class="section-title"><div><h2>Now playing</h2></div></div>
          <div class="music-now">${state.current ? escapeHtml(state.current.title) : 'Nothing playing'}</div>
          <p class="hint">${state.current ? `Duration: ${escapeHtml(state.current.duration)}` : 'Add a track to begin.'}</p>
          <form method="post" action="/g/${guild.id}/music/control">
            <div class="component-preview">
              <button name="action" value="pause">Pause</button>
              <button name="action" value="resume">Resume</button>
              <button name="action" value="skip">Skip</button>
              <button name="action" value="stop" style="background:#ed4245">Stop</button>
            </div>
            <div class="field" style="margin-top:18px"><label>Volume (0–200)</label><input type="number" name="volume" min="0" max="200" value="${state.volume}"></div>
            <div class="actions"><button name="action" value="volume">Set volume</button></div>
          </form>
        </div>
      </div>

      <div class="form-card">
        <div class="section-title"><div><h2>Queue</h2><p>Tracks waiting after the current item.</p></div></div>
        ${queue}
      </div>`;

    res.send(layout({
      title: 'Music Manager',
      body,
      user: req.session.user,
      guild,
      active: `/g/${guild.id}/music`,
      notice: req.query.ok || '',
      error: req.query.error || '',
    }));
  });

  app.get('/g/:gid/spotify/connect', (req, res) => {
    const state = spotifyOAuth.stateToken(req.guild.id);
    req.session.spotifyOAuthState = state;
    req.session.spotifyGuildId = req.guild.id;
    res.redirect(spotifyOAuth.authUrl(state));
  });

  app.get('/spotify/callback', async (req, res) => {
    try {
      const state = String(req.query.state || '');
      const expected = String(req.session.spotifyOAuthState || '');
      const guildId = String(req.session.spotifyGuildId || '');

      if (!state || !expected || state !== expected || !guildId) {
        throw new Error('Spotify OAuth state validation failed.');
      }

      if (req.query.error) {
        throw new Error(`Spotify authorization failed: ${req.query.error}`);
      }

      await spotifyOAuth.exchangeCode(guildId, String(req.query.code || ''));
      delete req.session.spotifyOAuthState;
      delete req.session.spotifyGuildId;

      res.redirect(`/g/${guildId}/music?ok=${encodeURIComponent('Spotify connected successfully.')}`);
    } catch (error) {
      res.status(400).send(`Spotify connection failed: ${escapeHtml(error.message)}`);
    }
  });

  app.post('/g/:gid/spotify/disconnect', (req, res) => {
    spotifyOAuth.disconnect(req.guild.id);
    res.redirect(`/g/${req.guild.id}/music?ok=${encodeURIComponent('Spotify disconnected.')}`);
  });

  app.post('/g/:gid/music/settings', async (req, res) => {
    try {
      const voiceChannel = await req.guild.channels.fetch(req.body.voiceChannelId);
      if (!voiceChannel || voiceChannel.type !== 2) {
        throw new Error('Select a normal Discord voice channel.');
      }

      const textChannelId = req.body.textChannelId || null;
      if (textChannelId) {
        const textChannel = await req.guild.channels.fetch(textChannelId);
        if (!textChannel?.isTextBased()) {
          throw new Error('Select a valid text channel.');
        }
      }

      store.mutate('musicSettings', all => {
        all[req.guild.id] = {
          voiceChannelId: voiceChannel.id,
          textChannelId,
          shuffle: req.body.shuffle === '1',
          updatedAt: Date.now(),
          updatedBy: req.session.user?.id || null,
        };
      });

      res.redirect(`/g/${req.guild.id}/music?ok=${encodeURIComponent('Fixed music channels saved.')}`);
    } catch (error) {
      res.redirect(`/g/${req.guild.id}/music?error=${encodeURIComponent(error.message)}`);
    }
  });

  app.get('/g/:gid/music/diagnostic', async (req, res) => {
    const guild = req.guild;
    const settings = store.read('musicSettings')[guild.id] || {};
    const channel = settings.voiceChannelId
      ? await guild.channels.fetch(settings.voiceChannelId).catch(() => null)
      : null;

    const botMember = guild.members.me || await guild.members.fetchMe();
    const permissions = channel?.permissionsFor(botMember)?.toArray() || [];

    res.json({
      guildId: guild.id,
      configuredVoiceChannelId: settings.voiceChannelId || null,
      configuredVoiceChannelName: channel?.name || null,
      permissions,
      dependencyStatus: await music.dependencyStatus(),
      voice: music.voiceHealth(guild.id),
    });
  });

  app.post('/g/:gid/music/play', async (req, res) => {
    try {
      const settings = store.read('musicSettings')[req.guild.id] || {};
      if (!settings.voiceChannelId) {
        throw new Error('Configure a fixed music voice channel first.');
      }

      const voice = await req.guild.channels.fetch(settings.voiceChannelId);
      if (!voice || voice.type !== 2) {
        throw new Error('The configured music voice channel no longer exists.');
      }

      const text = settings.textChannelId
        ? await req.guild.channels.fetch(settings.textChannelId).catch(() => null)
        : null;

      music.toggleShuffle(req.guild.id, Boolean(settings.shuffle));

      const result = await music.enqueue({
        guild: req.guild,
        voiceChannel: voice,
        textChannel: text,
        query: req.body.query,
        requestedBy: req.session.user?.id || 'dashboard',
      });

      res.redirect(`/g/${req.guild.id}/music?ok=${encodeURIComponent(
        `Queued ${result.track.title}${result.count > 1 ? ` and ${result.count - 1} more track(s)` : ''}`
      )}`);
    } catch (error) {
      res.redirect(`/g/${req.guild.id}/music?error=${encodeURIComponent(error.message)}`);
    }
  });

  app.post('/g/:gid/music/control', (req, res) => {
    try {
      const action = req.body.action;
      if (action === 'pause') music.pause(req.guild.id);
      if (action === 'resume') music.resume(req.guild.id);
      if (action === 'skip') music.skip(req.guild.id);
      if (action === 'stop') music.stop(req.guild.id);
      if (action === 'volume') music.setVolume(req.guild.id, Number(req.body.volume));
      res.redirect(`/g/${req.guild.id}/music?ok=${encodeURIComponent(`Music action: ${action}`)}`);
    } catch (error) {
      res.redirect(`/g/${req.guild.id}/music?error=${encodeURIComponent(error.message)}`);
    }
  });



  function svgChart(rows,key,width=900,height=240){if(!rows.length)return '<div class="empty">No metrics yet. Wait a minute.</div>';const vals=rows.map(r=>Number(r[key]||0)),max=Math.max(1,...vals),min=Math.min(0,...vals);const pts=vals.map((v,i)=>`${Math.round(i*(width/(Math.max(1,vals.length-1))))},${Math.round(height-20-((v-min)/(max-min||1))*(height-40))}`).join(' ');return `<svg viewBox="0 0 ${width} ${height}" style="width:100%;background:#0a1120;border-radius:12px"><polyline points="${pts}" fill="none" stroke="#5865f2" stroke-width="4"/><text x="12" y="22" fill="#9fb0ca">${escapeHtml(key)} max ${max}</text></svg>`}
  app.get('/g/:gid/v5',(req,res)=>{const body=`${pageHead('V5 Control Center','Realtime overview and direct access to the new modules.')}<div class="quick-links"><a class="quick-link" href="/g/${req.guild.id}/studio-v5"><b>Message Studio V5</b><span>Drafts, templates, edit, duplicate, variants and interactive components.</span></a><a class="quick-link" href="/g/${req.guild.id}/music"><b>Pro Music</b><span>Spotify metadata, lyrics, loop, shuffle, autoplay and equalizer.</span></a><a class="quick-link" href="/g/${req.guild.id}/analytics-v5"><b>Live Analytics</b><span>CPU, RAM, Discord activity and Minecraft players.</span></a><a class="quick-link" href="/g/${req.guild.id}/search-v5"><b>Global Search</b><span>Search settings, audits, tickets, giveaways and messages.</span></a></div>`;res.send(layout({title:'V5',body,user:req.session.user,guild:req.guild,active:req.path}))});
  app.get('/g/:gid/api/live',async(req,res)=>{res.setHeader('Content-Type','text/event-stream');res.setHeader('Cache-Control','no-cache');res.setHeader('Connection','keep-alive');let closed=false;req.on('close',()=>closed=true);const tick=async()=>{if(closed)return;const snap=await stats.snapshot(client,req.guild);const mus=music.snapshot(req.guild.id);res.write(`data: ${JSON.stringify({stats:snap,music:mus})}\n\n`)};await tick();const timer=setInterval(tick,3000);req.on('close',()=>clearInterval(timer))});
  app.get('/g/:gid/analytics-v5',async(req,res)=>{const rows=store.read('metrics').filter(x=>x.guildId===req.guild.id).slice(-300);const latest=rows.at(-1)||await stats.snapshot(client,req.guild);const body=`${pageHead('Live Analytics','Updates automatically every three seconds.')}<div class="grid"><div class="stat"><strong id="cpu">${latest.cpu}%</strong><span>Host CPU</span></div><div class="stat"><strong id="ram">${latest.ramUsedMb} MB</strong><span>RAM used</span></div><div class="stat"><strong id="members">${latest.members}</strong><span>Discord members</span></div><div class="stat"><strong id="players">${latest.minecraft?.players??'—'}</strong><span>Minecraft players</span></div></div><div class="form-card"><h2>Member activity</h2>${svgChart(rows,'members')}</div><div class="form-card"><h2>CPU history</h2>${svgChart(rows,'cpu')}</div><script>const e=new EventSource('/g/${req.guild.id}/api/live');e.onmessage=x=>{const d=JSON.parse(x.data).stats;document.getElementById('cpu').textContent=d.cpu+'%';document.getElementById('ram').textContent=d.ramUsedMb+' MB';document.getElementById('members').textContent=d.members;document.getElementById('players').textContent=d.minecraft?.players??'—'}</script>`;res.send(layout({title:'Analytics',body,user:req.session.user,guild:req.guild,active:req.path}))});
  app.get('/g/:gid/search-v5',(req,res)=>{const q=String(req.query.q||'').toLowerCase().trim();const sources=['config','audit','tickets','giveaways','warnings','studioDrafts','studioTemplates','studioMessages'];const found=[];if(q)for(const source of sources){const data=store.read(source);const entries=Array.isArray(data)?data:Object.entries(data).map(([id,v])=>({id,...(typeof v==='object'?v:{value:v})}));for(const row of entries){const text=JSON.stringify(row).toLowerCase();if(text.includes(q)&&(row.guildId===req.guild.id||source==='config'||source==='warnings'))found.push({source,...row});if(found.length>=200)break}}const body=`${pageHead('Global Search','Search all important bot data and settings.')}<form class="form-card"><div class="fields"><div class="field full"><label>Search</label><input name="q" value="${escapeHtml(req.query.q||'')}" placeholder="user ID, action, ticket, setting..."></div></div><div class="actions"><button>Search</button></div></form>${table(found)}`;res.send(layout({title:'Search',body,user:req.session.user,guild:req.guild,active:req.path}))});
  app.get('/g/:gid/studio-v5',(req,res)=>{const drafts=Object.values(store.read('studioDrafts')).filter(x=>x.guildId===req.guild.id),templates=Object.values(store.read('studioTemplates')).filter(x=>x.guildId===req.guild.id),messages=Object.values(store.read('studioMessages')).filter(x=>x.guildId===req.guild.id).slice(-100).reverse(),channels=[...req.guild.channels.cache.values()].filter(x=>x.isTextBased()&&x.type!==4);const edit=req.query.edit&&store.read('studioMessages')[req.query.edit]||req.query.draft&&store.read('studioDrafts')[req.query.draft]||req.query.template&&store.read('studioTemplates')[req.query.template]||{};const f=(k)=>escapeHtml(edit[k]||'');const body=`${pageHead('Message Studio V5','Create, draft, template, duplicate, edit and A/B test rich messages.')}<form class="form-card" method="post"><input type="hidden" name="id" value="${f('id')}"><div class="fields"><div class="field"><label>Name</label><input name="name" value="${f('name')}" placeholder="Announcement template"></div><div class="field"><label>Channel</label><select name="channelId" required>${optionList(channels,edit.channelId,c=>'#'+c.name,false)}</select></div><div class="field full"><label>Main text</label><textarea name="content">${f('content')}</textarea></div>${[1,2,3].map(n=>`<div class="field"><label>Embed ${n} title</label><input name="embed${n}Title" value="${f('embed'+n+'Title')}"></div><div class="field"><label>Embed ${n} color</label><input name="embed${n}Color" value="${f('embed'+n+'Color')||'5865F2'}"></div><div class="field full"><label>Embed ${n} description</label><textarea name="embed${n}Description">${f('embed'+n+'Description')}</textarea></div><div class="field"><label>Embed ${n} image</label><input name="embed${n}Image" value="${f('embed'+n+'Image')}"></div><div class="field"><label>Embed ${n} thumbnail</label><input name="embed${n}Thumbnail" value="${f('embed'+n+'Thumbnail')}"></div>`).join('')}<div class="field full"><label>Link buttons: Label|URL</label><textarea name="linkButtons">${f('linkButtons')}</textarea></div><div class="field full"><label>Action buttons: Label|role|ROLE_ID or Label|ticket|category</label><textarea name="actionButtons">${f('actionButtons')}</textarea></div><div class="field full"><label>Dropdown: Label|Private response</label><textarea name="selectOptions">${f('selectOptions')}</textarea></div><div class="field"><label>A/B variant</label><select name="variant"><option>A</option><option>B</option></select></div></div><div class="actions"><button name="action" value="draft">Save draft</button><button name="action" value="template">Save template</button><button name="action" value="send">Send</button><button name="action" value="update">Update sent message</button></div></form><div class="form-card"><h2>Drafts</h2>${table(drafts,['id','name','createdAt'])}</div><div class="form-card"><h2>Templates</h2>${table(templates,['id','name','createdAt'])}</div><div class="form-card"><h2>Sent messages</h2>${table(messages,['id','name','channelId','messageId','variant','sentAt'])}</div>`;res.send(layout({title:'Studio V5',body,user:req.session.user,guild:req.guild,active:req.path,notice:req.query.ok||'',error:req.query.error||''}))});
  app.post('/g/:gid/studio-v5',async(req,res)=>{const data={...req.body,guildId:req.guild.id,createdAt:Date.now(),createdBy:req.session.user.id,id:req.body.id||`${Date.now()}-${Math.random().toString(36).slice(2,7)}`};try{if(req.body.action==='draft'){store.mutate('studioDrafts',a=>a[data.id]=data);return res.redirect(`/g/${req.guild.id}/studio-v5?ok=Draft saved`)}if(req.body.action==='template'){store.mutate('studioTemplates',a=>a[data.id]=data);return res.redirect(`/g/${req.guild.id}/studio-v5?ok=Template saved`)}if(req.body.action==='update'){const old=store.read('studioMessages')[data.id];if(!old)throw new Error('Sent message not found');const ch=await req.guild.channels.fetch(old.channelId),msg=await ch.messages.fetch(old.messageId);await studioV5.send(client,{...old,...data},msg);return res.redirect(`/g/${req.guild.id}/studio-v5?ok=Message updated`)}await studioV5.send(client,data);res.redirect(`/g/${req.guild.id}/studio-v5?ok=Message sent`)}catch(e){res.redirect(`/g/${req.guild.id}/studio-v5?error=${encodeURIComponent(e.message)}`)}});
  app.get('/g/:gid/audit-v5',(req,res)=>{const q=String(req.query.q||'').toLowerCase();let rows=store.read('audit').filter(x=>x.guildId===req.guild.id);if(q)rows=rows.filter(x=>JSON.stringify(x).toLowerCase().includes(q));const body=`${pageHead('Audit Log V5','Filter and export bot/security activity.')}<form class="form-card"><input name="q" value="${escapeHtml(req.query.q||'')}" placeholder="Filter action, actor or details"><div class="actions"><button>Filter</button><a class="button secondary" href="/g/${req.guild.id}/audit-v5.json">Export JSON</a></div></form>${table(rows.slice(0,1000))}`;res.send(layout({title:'Audit V5',body,user:req.session.user,guild:req.guild,active:req.path}))});
  app.get('/g/:gid/audit-v5.json',(req,res)=>res.json(store.read('audit').filter(x=>x.guildId===req.guild.id)));

  app.listen(port, host, () => console.log(`Dashboard listening on http://${host}:${port}`));
}

module.exports = { startDashboard };
