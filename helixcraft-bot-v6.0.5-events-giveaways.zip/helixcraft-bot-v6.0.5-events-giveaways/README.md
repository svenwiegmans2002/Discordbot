# Helixcraft Bot v6.0.5 — Events and Giveaways

## Event commands

```text
/event create
/event list
/event edit
/event start
/event cancel
/event delete
```

Events are real Discord Scheduled Events. Voice/stage events and external
events are supported.

## Event Manager dashboard

The Events page now supports:

- creating events;
- voice, stage and external locations;
- editing name, description, dates and location;
- starting events immediately;
- canceling events;
- deleting events;
- opening the event directly in Discord.

## Giveaway Manager dashboard

The Giveaways page now supports:

- creating interactive giveaways;
- prize, duration and winner count;
- required roles;
- bonus-entry roles;
- minimum account age;
- minimum server membership;
- live entry count;
- pause and resume;
- end now;
- reroll;
- delete.

The existing `/giveaway` commands remain available.

## Install

```bash
cd /root/helixcraft-bot-v6.0.5-events-giveaways
chmod +x apply-v6.0.5.sh
./apply-v6.0.5.sh
```

Dashboard pages:

```text
https://bot.helixcraft-hosting.net/g/SERVER_ID/events
https://bot.helixcraft-hosting.net/g/SERVER_ID/giveaways
```
